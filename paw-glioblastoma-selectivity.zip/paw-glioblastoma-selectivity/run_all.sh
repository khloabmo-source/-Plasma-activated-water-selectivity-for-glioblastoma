#!/usr/bin/env bash
# Regenerate every manuscript figure that does not require the production trajectories.
#   bash run_all.sh                 manuscript figures only
#   RUN_LEGACY=1 bash run_all.sh    additionally run the exploratory/legacy scripts
#                                   (03, 05, 06, 07, 11, 12); their outputs go to figures/legacy/
# Per-script logs are written to logs/ so that a failure can be diagnosed.
set -u
export MPLBACKEND=Agg
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$ROOT/figures" "$ROOT/logs"
fail=0

run_py () {   # run_py <label> <log-name> <command...>
  local label="$1" log="$2"; shift 2
  printf '  %-42s' "$label"
  if "$@" >"$ROOT/logs/$log.log" 2>&1; then echo "ok"; else echo "FAILED (see logs/$log.log)"; fail=1; fi
}

# ---- manuscript scripts (all are listed in MANIFEST.md) ----
TRANSPORT_MAIN="01_transfer_function.py 02_sensitivity_robustness.py 02b_conditional_robustness.py \
03b_dose_survival_window_hill.py 04_causal_chain_schematic.py 08_normal_anchor_mcf10a.py \
09_clearance_grounding.py 10_bootstrap_uncertainty.py 13_model_comparison.py \
14_michaelis_menten_figS1.py 15_coupled_gating_fig3.py 16_selectivity_vs_hill.py \
17_attributed_clearance.py 18_depletion_fixed_law.py 19_plip_measured_range.py"
# ---- exploratory / legacy scripts: not manuscript figures ----
TRANSPORT_LEGACY="03_dose_survival_window.py 05_measured_plip_coupling.py 06_calibrate_dlethal.py \
07_survival_hill_kurake.py 11_depletion_selfconsistent.py 12_robustness_map.py"

echo "=== transport model (manuscript) ==="
cd "$ROOT/transport_model"
# 10 writes bootstrap_h_ci.txt, which 16 reads; keep the listed order.
for f in $TRANSPORT_MAIN; do run_py "$f" "${f%.py}" python3 "$f"; done
# the scripts write into their own directory; collect without editing them
find . -maxdepth 1 \( -name "*.png" -o -name "*.pdf" \) -exec mv -f {} "$ROOT/figures/" \;

if [ "${RUN_LEGACY:-0}" = "1" ]; then
  echo "=== transport model (legacy / exploratory; not manuscript figures) ==="
  mkdir -p "$ROOT/figures/legacy"
  for f in $TRANSPORT_LEGACY; do run_py "$f" "${f%.py}" python3 "$f"; done
  find . -maxdepth 1 \( -name "*.png" -o -name "*.pdf" \) -exec mv -f {} "$ROOT/figures/legacy/" \;
fi

echo "=== membrane analysis (derived data only) ==="
cd "$ROOT/membrane_analysis"
for f in plot_ws1_final.py tost_equivalence.py scd_definition_check.py plot_convergence_figS11.py; do
  run_py "$f" "${f%.py}" python3 "$f"
done
# the unit tests need MDAnalysis (requirements.txt); skip, do not fail, when it is absent
if python3 -c "import MDAnalysis" >/dev/null 2>&1; then
  for f in test_scd.py test_dlat.py; do run_py "$f" "${f%.py}" python3 "$f"; done
else
  printf '  %-42s%s\n' "test_scd.py, test_dlat.py" "SKIPPED (MDAnalysis not installed)"
fi
# Fig. S4 needs msd_S4.npz, which is produced by msd_S4.py from the trajectories.
# If a copy of msd_S4.npz is present, only the plotting step is run.
if [ -f msd_S4.npz ]; then run_py "plot_msd_S4.py" plot_msd_S4 python3 plot_msd_S4.py; fi
echo "  (Fig. S4 and ws1_convergence.py need the trajectories - see MANIFEST.md)"
find . -maxdepth 1 \( -name "*.png" -o -name "*.pdf" \) -exec mv -f {} "$ROOT/figures/" \;

echo "=== AQP8 structure ==="
cd "$ROOT/aqp8_structure"
run_py "pore_radius_ensemble.py" pore_radius_ensemble \
  python3 pore_radius_ensemble.py reference_oriented.pdb ensemble results/aqp8_ensemble_240.csv
for f in plot_ensemble_figS13.py plot_pore_methods_figS14.py; do run_py "$f" "${f%.py}" python3 "$f"; done
find . -maxdepth 1 \( -name "*.png" -o -name "*.pdf" \) -exec mv -f {} "$ROOT/figures/" \;
rm -rf "$ROOT/transport_model/__pycache__"

echo
echo "figure files in figures/ (png + pdf, excluding legacy/): $(find "$ROOT/figures" -maxdepth 1 -type f \( -name '*.png' -o -name '*.pdf' \) | wc -l)"
[ $fail -eq 0 ] && echo "All reproducible targets completed. Figures in $ROOT/figures" \
               || echo "Some targets failed - see logs/ for the error."
exit $fail
