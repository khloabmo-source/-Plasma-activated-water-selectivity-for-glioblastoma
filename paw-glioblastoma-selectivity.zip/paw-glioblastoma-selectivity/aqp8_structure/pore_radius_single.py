#!/usr/bin/env python3
"""AQP8 pore profile, HOLE-style with a path-continuity constraint.

The v2 script maximised the probe radius independently at each z, which lets the
probe centre jump into side cavities and overestimates the channel radius. HOLE
instead traces a CONNECTED path: the sphere centre may only move a limited
lateral distance between adjacent z slices. This script does that, marching
outward in both directions from the NPA plane, and reports the ar/R radius.
"""
import sys
import numpy as np

pdb, out_csv = sys.argv[1], sys.argv[2]
MAXSTEP = float(sys.argv[3]) if len(sys.argv) > 3 else 0.6   # A of lateral drift per 0.25 A in z
VDW = {"C": 1.70, "N": 1.55, "O": 1.52, "S": 1.80}

xyz, rv, lab = [], [], []
for ln in open(pdb):
    if not ln.startswith(("ATOM", "HETATM")):
        continue
    nm = ln[12:16].strip()
    e = (ln[76:78].strip() or nm[0]).upper()
    if e == "H" or nm.startswith("H"):
        continue
    rn, ri = ln[17:20].strip(), int(ln[22:26])
    if rn in ("TIP3", "HOH", "POT", "CLA", "SOD"):
        continue
    xyz.append([float(ln[30:38]), float(ln[38:46]), float(ln[46:54])])
    rv.append(VDW.get(e, 1.70)); lab.append((rn, ri, nm))
xyz, rv = np.array(xyz), np.array(rv)

res = {}
for (rn, ri, nm), c in zip(lab, xyz):
    res.setdefault((rn, ri), {})[nm] = c
npa = sorted(ri for (rn, ri) in res
             if rn == "ASN" and ("PRO", ri + 1) in res and ("ALA", ri + 2) in res)
nd2 = [res[("ASN", r)]["ND2"] for r in npa if "ND2" in res[("ASN", r)]]
start = np.mean(nd2, axis=0)
r213 = res.get(("ARG", 213), {})
z213 = r213.get("CZ", r213.get("CA", [0, 0, np.nan]))[2]
print(f"heavy atoms {len(xyz)} | NPA Asn {npa} | start (x,y,z) = {np.round(start,2)}")
print(f"Arg213 CZ z = {z213:+.2f} A | lateral drift limit {MAXSTEP} A per 0.25 A step in z\n")


def probe(p):
    return float((np.linalg.norm(xyz - p, axis=1) - rv).min())


def local_max(x, y, z, cap):
    """Best probe centre within `cap` of (x,y), by nested refinement."""
    bx, by, br, h = x, y, probe(np.array([x, y, z])), cap
    for _ in range(4):
        g = np.linspace(-h, h, 17)
        cx, cy = bx, by
        for a in g:
            for b in g:
                nx, ny = cx + a, cy + b
                if (nx - x) ** 2 + (ny - y) ** 2 > cap ** 2:
                    continue
                r = probe(np.array([nx, ny, z]))
                if r > br:
                    br, bx, by = r, nx, ny
        h = 2 * h / 16
    return br, bx, by


def march(direction, zmax=25.0, dz=0.25):
    x, y = start[0], start[1]
    zs, rs = [], []
    z = start[2]
    while abs(z - start[2]) <= zmax:
        r, x, y = local_max(x, y, z, MAXSTEP)
        zs.append(z); rs.append(r)
        z += direction * dz
    return zs, rs

zu, ru = march(+1)
zd, rd = march(-1)
zs = np.array(zd[::-1][:-1] + zu)
prof = np.array(rd[::-1][:-1] + ru)
order = np.argsort(zs); zs, prof = zs[order], prof[order]
np.savetxt(out_csv, np.c_[zs, prof], delimiter=",", header="z_A,probe_radius_A", comments="")

print(f"connected-path profile: global minimum {prof.min():.3f} A at z = {zs[prof.argmin()]:+.2f} A")
for thr in (1.15, 1.0, 0.8):
    m = prof < thr
    if m.any():
        print(f"  radius < {thr:.2f} A over z = {zs[m].min():+.1f} .. {zs[m].max():+.1f} A ({m.sum()} slices)")
    else:
        print(f"  radius never falls below {thr:.2f} A")

print("\n   z (A)   radius (A)")
for z in np.arange(-12, 12.01, 1.0):
    i = np.argmin(abs(zs - z))
    tag = "  <- Arg213 (ar/R)" if abs(z - z213) < 0.6 else ""
    for r_ in npa:
        if abs(z - res[("ASN", r_)]["ND2"][2]) < 0.6:
            tag += f"  <- NPA Asn{r_}"
    print(f"  {zs[i]:+6.2f}  {prof[i]:9.3f}{tag}")

rf = prof[np.argmin(abs(zs - z213))]
print(f"\nar/R plane (z = {z213:+.2f}): radius {rf:.3f} A")
print(f"manuscript Section 4.7 reports median 0.04 A, 95th pct 0.63 A, max 0.86 A across 240 models")
print(f"single-file conduction threshold ~1.0-1.1 A -> this model: "
      f"{'CLOSED' if prof.min() < 1.0 else 'marginally OPEN'}")
