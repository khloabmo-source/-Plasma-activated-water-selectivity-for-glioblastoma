#!/usr/bin/env python3
"""ar/R selectivity-filter radius across the 240-model AlphaFold ensemble.

Each model is superposed (Kabsch, CA atoms) onto the CHARMM-GUI membrane-oriented
reference, so z is the membrane normal for every model. The pore radius is then
traced with the same connected-path probe-sphere algorithm used for the single
model: the sphere centre may drift only a limited lateral distance between
adjacent z slices, which prevents it from jumping into side cavities.

Reports, per model: the probe radius at the ar/R plane (Arg213) and the global
minimum along the channel. Then the ensemble distribution.
"""
import glob, os, sys, json
import numpy as np
from scipy.spatial import cKDTree

ref_pdb, ens_root, out_csv = sys.argv[1], sys.argv[2], sys.argv[3]
MAXDRIFT = 0.6          # A lateral drift allowed per 0.25 A step in z
DZ = 0.25
ZSPAN = 20.0
VDW = {"C": 1.70, "N": 1.55, "O": 1.52, "S": 1.80}


def load(p, want_ca_only=False):
    xyz, rv, ca, res = [], [], {}, {}
    for ln in open(p):
        if not ln.startswith(("ATOM", "HETATM")):
            continue
        nm = ln[12:16].strip()
        rn, ri = ln[17:20].strip(), int(ln[22:26])
        if rn in ("TIP3", "HOH", "POT", "CLA", "SOD"):
            continue
        e = (ln[76:78].strip() or nm[0]).upper()
        if e == "H" or nm.startswith("H"):
            continue
        c = np.array([float(ln[30:38]), float(ln[38:46]), float(ln[46:54])])
        if nm == "CA":
            ca[ri] = c
        xyz.append(c); rv.append(VDW.get(e, 1.70))
        res.setdefault((rn, ri), {})[nm] = c
    return np.array(xyz), np.array(rv), ca, res


def kabsch(P, Q):
    """Rotation+translation taking P onto Q."""
    pc, qc = P.mean(0), Q.mean(0)
    H = (P - pc).T @ (Q - qc)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1, 1, d]) @ U.T
    return R, qc - R @ pc


ref_xyz, ref_rv, ref_ca, ref_res = load(ref_pdb)
print(f"reference: {ref_pdb}")
print(f"  {len(ref_xyz)} heavy atoms, {len(ref_ca)} CA, z {ref_xyz[:,2].min():.1f}..{ref_xyz[:,2].max():.1f}")
ref_npa = sorted(ri for (rn, ri) in ref_res
                 if rn == "ASN" and ("PRO", ri + 1) in ref_res and ("ALA", ri + 2) in ref_res)
ref_start = np.mean([ref_res[("ASN", r)]["ND2"] for r in ref_npa], axis=0)
print(f"  NPA Asn {ref_npa}, pore start {np.round(ref_start,2)}")


def profile(xyz, rv, start):
    tree = cKDTree(xyz)

    def best_plane(z, cx, cy, cap):
        bx, by = cx, cy
        br = -9e9
        h = cap
        for _ in range(4):
            g = np.linspace(-h, h, 21)
            gx, gy = np.meshgrid(g, g)
            m = gx**2 + gy**2 <= cap**2 + 1e-9
            pts = np.c_[(bx + gx[m]).ravel(), (by + gy[m]).ravel(),
                        np.full(m.sum(), z)]
            keep = (pts[:, 0] - cx)**2 + (pts[:, 1] - cy)**2 <= cap**2 + 1e-9
            pts = pts[keep]
            if not len(pts):
                break
            d, i = tree.query(pts, k=24)
            r = (d - rv[i]).min(axis=1)
            j = r.argmax()
            if r[j] > br:
                br, bx, by = r[j], pts[j, 0], pts[j, 1]
            h = 2 * h / 20
        return br, bx, by

    zs, rs = [], []
    for sgn in (+1, -1):
        x, y = start[0], start[1]
        z = start[2]
        n = 0
        while n * DZ <= ZSPAN:
            r, x, y = best_plane(z, x, y, MAXDRIFT)
            if sgn > 0 or n > 0:
                zs.append(z); rs.append(r)
            z += sgn * DZ
            n += 1
    o = np.argsort(zs)
    return np.array(zs)[o], np.array(rs)[o]


pdbs = sorted(glob.glob(os.path.join(ens_root, "**", "*.pdb"), recursive=True))
print(f"\nensemble: {len(pdbs)} models\n")
rows = []
for k, p in enumerate(pdbs, 1):
    xyz, rv, ca, res = load(p)
    common = sorted(set(ca) & set(ref_ca))
    R, t = kabsch(np.array([ca[i] for i in common]),
                  np.array([ref_ca[i] for i in common]))
    xyz = xyz @ R.T + t
    for key in res:
        res[key] = {k2: v @ R.T + t for k2, v in res[key].items()}
    npa = sorted(ri for (rn, ri) in res
                 if rn == "ASN" and ("PRO", ri + 1) in res and ("ALA", ri + 2) in res)
    nd2 = [res[("ASN", r)]["ND2"] for r in npa if "ND2" in res[("ASN", r)]]
    start = np.mean(nd2, axis=0) if nd2 else ref_start
    r213 = res.get(("ARG", 213), {})
    z213 = r213.get("CZ", r213.get("CA", [0, 0, np.nan]))[2]
    zs, rs = profile(xyz, rv, start)
    r_arr = rs[np.argmin(abs(zs - z213))]
    depth = os.path.basename(p).split("_")[1]
    tag = os.path.basename(p)
    seed = tag.split("seed_")[-1].split(".")[0] if "seed_" in tag else "?"
    model = tag.split("model_")[-1].split("_")[0] if "model_" in tag else "?"
    rows.append((depth, model, seed, z213, r_arr, rs.min(), zs[rs.argmin()]))
    if k % 20 == 0 or k == 1:
        print(f"  [{k:3d}/{len(pdbs)}] {depth} model{model} seed{seed}: "
              f"ar/R {r_arr:.3f} A, global min {rs.min():.3f} A")

import csv
with open(out_csv, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["depth", "model", "seed", "z_Arg213", "radius_arR_A", "radius_globalmin_A", "z_globalmin"])
    w.writerows([(d, m, s, f"{z:.3f}", f"{a:.4f}", f"{g:.4f}", f"{zg:.2f}")
                 for d, m, s, z, a, g, zg in rows])

arr = np.array([r[4] for r in rows])
gmin = np.array([r[5] for r in rows])
print("\n" + "=" * 68)
print(f"ENSEMBLE RESULT  (n = {len(arr)})")
print("=" * 68)
print(f"  ar/R radius   : min {arr.min():.3f}  median {np.median(arr):.3f}  "
      f"MAX {arr.max():.3f}  A")
print(f"  global minimum: min {gmin.min():.3f}  median {np.median(gmin):.3f}  "
      f"MAX {gmin.max():.3f}  A")
print(f"  models with ar/R >= 1.0 A (conductive) : {(arr >= 1.0).sum()} / {len(arr)}")
print(f"  models with ar/R >= 1.1 A              : {(arr >= 1.1).sum()} / {len(arr)}")
for d in sorted({r[0] for r in rows}):
    sub = np.array([r[4] for r in rows if r[0] == d])
    print(f"    depth {d:>4}: n={len(sub):3d}  median {np.median(sub):.3f}  max {sub.max():.3f} A")
print(f"\n  95th percentile ar/R radius: {np.percentile(arr, 95):.3f} A")
print(f"  computed maximum here: {arr.max():.3f} A")
