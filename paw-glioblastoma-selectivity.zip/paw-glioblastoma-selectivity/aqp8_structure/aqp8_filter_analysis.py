#!/usr/bin/env python3
# ======================================================================
# aqp8_filter_analysis.py
# on the AlphaFold model of human AQP8 (UniProt O94778).
#
# Locates the two NPA motifs and the aromatic/arginine (ar/R) region,
# reports the gating Cys53 geometry, and flags pore-occluding aromatic
# residues. In the model the filter is built in a closed, pore-occluding
# conformation (consistent with Kirscht et al., 2018): an absolute,
# first-principles single-channel permeability cannot be obtained from
# structure, which is why the manuscript uses an experiment-anchored
# transfer function.
#
# Full result in the paper: across a 240-model AlphaFold ensemble
# (input subsampling + inference dropout, three input depths) the ar/R
# filter never opens (median 0.04 A, 95th pct 0.63 A, max 0.86 A vs ~1.0-1.1 A needed for
# single-file conduction). This script analyses one model; rerun over the
# ensemble (loop the PDBs) to reproduce the distribution.
#
#   wget https://alphafold.ebi.ac.uk/files/AF-O94778-F1-model_v6.pdb
#   python3 aqp8_filter_analysis.py
# Deps: numpy, MDAnalysis
# ======================================================================
import numpy as np, MDAnalysis as mda

PDB = "AF-O94778-F1-model_v6.pdb"           # edit path if needed
u = mda.Universe(PDB); prot = u.select_atoms("protein"); res = prot.residues

t2o = {"ALA":"A","ARG":"R","ASN":"N","ASP":"D","CYS":"C","GLN":"Q","GLU":"E",
       "GLY":"G","HIS":"H","ILE":"I","LEU":"L","LYS":"K","MET":"M","PHE":"F",
       "PRO":"P","SER":"S","THR":"T","TRP":"W","TYR":"Y","VAL":"V"}
seq = "".join(t2o.get(r.resname, "X") for r in res)
print(f"length: {len(res)} residues | range: {res[0].resid}-{res[-1].resid}")

def pLDDT(rid):
    a = prot.select_atoms(f"resid {rid} and name CA")
    return float(a.tempfactors[0]) if len(a) else float("nan")

# --- 1) NPA motifs (Asn-Pro-Ala) ---
npa = [res[i].resid for i in range(len(res)-2)
       if (res[i].resname, res[i+1].resname, res[i+2].resname) == ("ASN","PRO","ALA")]
print(f"\nNPA Asn resids: {npa}")
for r in npa:
    print(f"   NPA Asn{r}: pLDDT {pLDDT(r):.1f}")

# --- 2) gating Cys53 ---
c53 = prot.select_atoms("resid 53")
print(f"\nresidue@53: {c53.residues[0].resname} (expected CYS) | pLDDT {pLDDT(53):.1f}")
print(f"sequence context 48-58: {seq[47:58]}")

# --- 3) pore center approx = centroid of NPA Asn ND2 atoms ---
nd2 = prot.select_atoms("resname ASN and name ND2 and resid " + " ".join(map(str, npa)))
center = (nd2.center_of_geometry() if len(nd2) >= 2
          else prot.select_atoms("resid " + " ".join(map(str, npa)) + " and name CA").center_of_geometry())
print(f"\npore-center estimate: {np.round(center,1)}")

# --- 4) Cys53 distance from pore center ---
sg = prot.select_atoms("resid 53 and name SG")
if len(sg):
    d = np.linalg.norm(sg.positions[0]-center)
    print(f"Cys53(SG) -> pore center: {d:.1f} A  => {'strong gating candidate (<6)' if d<6 else 'relatively distant'}")

# --- 5) critical check: aromatic residue occluding the pore ---
print("\nPhenylalanines near the pore center (occluding-gate candidates):")
hits = []
for r in prot.select_atoms("resname PHE").residues:
    ring = u.select_atoms(f"resid {r.resid} and name CG CD1 CD2 CE1 CE2 CZ")
    if len(ring) == 6:
        d = np.linalg.norm(ring.center_of_geometry()-center)
        if d < 8.0:
            hits.append((d, r.resid))
for d, rid in sorted(hits):
    print(f"   Phe{rid}: ring->center {d:.1f} A | pLDDT {pLDDT(rid):.1f}  {'<- occluding candidate (<4.5)' if d<4.5 else ''}")
