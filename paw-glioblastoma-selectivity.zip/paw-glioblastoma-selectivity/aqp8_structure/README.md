# AQP8 selectivity-filter geometry (Section 4.7)

## Contents

```
ensemble/d16, d32, d64   240 ColabFold models (80 each) + config.json + log.txt + MSA
reference_oriented.pdb   CHARMM-GUI membrane-oriented AQP8; z is the membrane normal
charmmgui_pore_profile.plo   CHARMM-GUI's own pore-radius profile (independent check)
charmmgui_build_config.json  CHARMM-GUI build settings
pore_radius_ensemble.py  the 240-model analysis
pore_radius_single.py    connected-path profile on one structure
plot_ensemble_figS13.py  Fig. S13 from results/aqp8_ensemble_240.csv
plot_pore_methods_figS14.py  Fig. S14, connected-path vs CHARMM-GUI profile
aqp8_filter_analysis.py  NPA / Cys53 / ar/R residue geometry
results/                 computed output
```

## Generation

ColabFold 1.6.1, `alphafold2_ptm`, no templates, 3 recycles, no relaxation,
inference dropout enabled, at three MSA depths:

| depth | `max_seq` : `max_extra_seq` | seeds | models | total |
|---|---|---|---|---|
| d16 | 16 : 32 | 16 | 5 | 80 |
| d32 | 32 : 64 | 16 | 5 | 80 |
| d64 | 64 : 128 | 16 | 5 | 80 |

240 models in total. The exact settings are in each depth's `config.json`;
per-model pLDDT and pTM are in `log.txt`.

## Measurement

```bash
python3 pore_radius_ensemble.py reference_oriented.pdb ensemble results/aqp8_ensemble_240.csv
```

Each model is superposed on `reference_oriented.pdb` (Kabsch, Cα) so that z is
the membrane normal for every model. The radius is then the largest probe sphere
that traverses the channel on a **connected path**: the sphere centre may drift at
most 0.6 Å laterally per 0.25 Å step in z. Element-specific van der Waals radii
(C 1.70, N 1.55, O 1.52, S 1.80 Å); heavy atoms only.

## Result

| statistic | ar/R radius |
|---|---|
| median | 0.041 Å |
| 95th percentile | 0.628 Å |
| maximum | 0.864 Å |
| sterically sealed (≤ 0) | 39.6% |
| **models reaching 1.0 Å** | **0 / 240** |

Per depth, the medians are 0.051, 0.015 and 0.089 Å. No model at any input depth
reaches the ≈ 1.0–1.1 Å required for single-file conduction.

## The measurement is strongly method-dependent

On the same structure the ar/R radius is:

| method | radius |
|---|---|
| CHARMM-GUI pore detection | 0.000 Å |
| probe sphere, connected path (used here) | 0.046 Å |
| probe sphere, maximised independently per z-slice | 1.199 Å |

Without the path-continuity constraint the probe enters lateral cavities that are
not the pore, inflating the radius by more than an order of magnitude. Any radius
reported for this channel must state the algorithm.

## Scope

This analysis shows that the *predicted* resting filter is closed, which is why an
absolute single-channel permeability cannot be obtained from structure and the
manuscript uses an experiment-anchored transfer function instead. It does **not**
establish the physiological gating state of the channel.
