#!/usr/bin/env python3
"""Fig. S14 - pore profile of the reference AQP8 structure under two methods.

Overlays the connected-path probe radius (results/pore_profile_reference.csv,
written by pore_radius_single.py) on the pore profile written by the CHARMM-GUI
Membrane Builder (charmmgui_pore_profile.plo, third column).
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ref = np.loadtxt(os.path.join(HERE, "results", "pore_profile_reference.csv"),
                 delimiter=",", skiprows=1)
cg = np.loadtxt(os.path.join(HERE, "charmmgui_pore_profile.plo"), comments="#")

fig, ax = plt.subplots(figsize=(6.5, 4))
ax.plot(ref[:, 0], np.clip(ref[:, 1], 0, None), color="#4c72b0", lw=1.8,
        label="connected-path probe radius")
ax.plot(cg[:, 0], cg[:, 2], color="#dd8452", lw=1.5, ls="--",
        label="CHARMM-GUI pore profile")
ax.axhline(1.0, color="#c44e52", lw=1, label="conduction threshold 1.0 $\\AA$")
ax.set_xlim(-20, 20); ax.set_ylim(0, 4)
ax.set_xlabel("z along the membrane normal ($\\AA$)")
ax.set_ylabel("pore radius ($\\AA$)")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
out = os.path.join(HERE, "figS14_aqp8_pore_methods.png")
fig.savefig(out, dpi=300)
m = (ref[:, 0] > -4) & (ref[:, 0] < 0)
print(f"connected-path minimum in the filter region: {ref[m,1].min():.3f} A "
      f"at z = {ref[m,0][ref[m,1].argmin()]:.2f} A")
print("Saved", out)
