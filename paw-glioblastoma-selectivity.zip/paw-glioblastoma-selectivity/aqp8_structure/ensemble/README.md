# AlphaFold ensemble — 240 models

`d16/`, `d32/` and `d64/` each hold 80 unrelaxed PDB models with the run's
`config.json` and `log.txt`.

`msa_bfd.mgnify30.metaeuk30.smag30.a3m` is the multiple sequence alignment. It is
stored once at this level because all three depths used the same query and the
same mmseqs2 search — the depths differ only in how that alignment is subsampled
at inference (`max_seq` / `max_extra_seq` in each `config.json`), not in the
alignment itself.
