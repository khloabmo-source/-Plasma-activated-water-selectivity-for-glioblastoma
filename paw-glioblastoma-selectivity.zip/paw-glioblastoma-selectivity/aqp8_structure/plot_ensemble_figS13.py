#!/usr/bin/env python3
"""Fig. S13 - ar/R constriction radius across the 240-model AQP8 ensemble.

Reads results/aqp8_ensemble_240.csv (written by pore_radius_ensemble.py).
Left: distribution of the connected-path radius over all models.
Right: the same radius grouped by MSA depth.
"""
import csv, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
rows = list(csv.DictReader(open(os.path.join(HERE, "results", "aqp8_ensemble_240.csv"))))
r = np.array([float(x["radius_arR_A"]) for x in rows])
depth = np.array([x["depth"] for x in rows])
THRESH = 1.0   # approximate radius required for single-file conduction (A)

fig, ax = plt.subplots(1, 2, figsize=(10, 4))
ax[0].hist(r, bins=30, color="#4c72b0", edgecolor="white")
ax[0].axvline(np.median(r), color="k", ls="--", lw=1, label=f"median {np.median(r):.3f} $\\AA$")
ax[0].axvline(THRESH, color="#c44e52", lw=1.5, label=f"conduction threshold {THRESH:.1f} $\\AA$")
ax[0].set_xlabel("ar/R radius, connected path ($\\AA$)"); ax[0].set_ylabel("models")
ax[0].set_title(f"n = {len(r)}; maximum {r.max():.3f} $\\AA$; "
                f"{100*np.mean(r <= 0):.1f}% sealed", fontsize=10)
ax[0].legend(frameon=False, fontsize=8)

labels = {"d16": "16:32", "d32": "32:64", "d64": "64:128"}
groups = [r[depth == d] for d in labels]
ax[1].boxplot(groups, tick_labels=[labels[d] for d in labels], showfliers=True)
ax[1].axhline(THRESH, color="#c44e52", lw=1.5)
ax[1].set_xlabel("MSA depth (max_seq : max_extra_seq)")
ax[1].set_ylabel("ar/R radius ($\\AA$)")
ax[1].set_title("by input depth (80 models each)", fontsize=10)
fig.tight_layout()
out = os.path.join(HERE, "figS13_aqp8_ensemble.png")
fig.savefig(out, dpi=300)
print(f"n={len(r)} median={np.median(r):.3f} p95={np.percentile(r,95):.3f} "
      f"max={r.max():.3f} sealed={100*np.mean(r<=0):.1f}% n>=1.0A={(r>=THRESH).sum()}")
for d in labels:
    print(f"  {labels[d]:7s} median {np.median(r[depth==d]):.3f}")
print("Saved", out)
