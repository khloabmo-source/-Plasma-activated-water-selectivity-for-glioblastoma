# Transport model (Figs. 1–9, S1, S6–S10)

Pure Python; no trajectories or external data beyond `killcurve.csv`.

```bash
python3 01_transfer_function.py     # Phi, C_in, S_dose; Figs 1, 2
python3 02_sensitivity_robustness.py # Sobol + Monte Carlo; Figs 4, 5, 6
python3 02b_conditional_robustness.py # Monte Carlo by clearance-ratio bin; Table S3
python3 19_plip_measured_range.py   # selectivity across the measured P_lip range (Sec. 4.4)
python3 03b_dose_survival_window_hill.py  # Figs 7, 8
python3 15_coupled_gating_fig3.py   # Fig 3 (coupled Eq. 2 + Eq. 6)
```

Script `02b` re-runs the Monte Carlo of `02` with the clearance-ratio prior
restricted bin by bin, 20 000 draws per bin, and writes
`conditional_robustness.txt` (Table S3). It separates the model's behaviour from
the uniform [1, 30] prior on that ratio, under which 86% of draws already exceed
five-fold. The gating exponent is sampled over 1–4 in every bin, so these figures
do not depend on the baseline n.

Script `19` evaluates the operating point at the lipid permeabilities actually
measured by Orrico et al. 2022 (the reference the baseline P_lip is anchored to):
4.1e-4 cm/s for a saturated and 5.5e-3 cm/s for a di-unsaturated
cholesterol-containing liposome, and 1.6e-3 cm/s for intact erythrocytes. The
baseline 5e-4 cm/s sits at the saturated end; across the full measured range the
dose selectivity runs 8.3 to 2.3 and normal-cell sparing fails above about
1.6e-3 cm/s. Writes `plip_measured_range.txt`.

`_model.py` holds the Table 1 baseline and the survival calibration in one place
and is imported by scripts 03b and 07–19. Scripts 01, 02, 02b, 03, 04, 05 and 06
define the model inline; with n = 1 they reproduce the values in `../MANIFEST.md`.
Run 10 before 16 (the order of `run_all.sh`): 16 reads the bootstrap interval on h
that 10 writes to `bootstrap_h_ci.txt`.

## Gating exponent

Every script uses **n = 1** as its baseline, the steady state of the kinetic scheme
in Eq. (6), which describes oxidation of a single cysteine (scripts 02 and 02b
sample n over 1–4 around it). `_model.N_GATE` holds the value; the scripts that
define the model inline set `n_gate = 1.0` to the same effect. The cooperative form of the
submitted version (n = 2) is kept only as a sensitivity case
(`n=_model.N_GATE_COOPERATIVE`): it gives S_dose 6.91 instead of 7.57 and a
survival selectivity of 23.4× instead of 25.4×. The Hill survival law is fitted
in one place, `_model.calibrate()`, and no script carries a copied D50 or h.

## Script index

| script | output |
|---|---|
| `01` | Φ, C_in, S_dose; Figs. 1, 2 |
| `02` | Sobol indices and Monte Carlo robustness; Figs. 4, 5, 6 |
| `03`, `03b` | single-hit (`03`, legacy) and Hill (`03b`) dose–survival; Figs. 7, 8 are written by `03b` |
| `04` | conceptual framework and causal chain, panels A–D; Fig. 9 (matplotlib, numpy) |
| `05` | propagation of a measured P_lip into S_dose |
| `06`, `07`, `08` | survival calibration and the non-malignant anchor |
| `09` | selectivity against the clearance-collapse ratio; Fig. S6 |
| `10` | bootstrap confidence intervals; Fig. S9 |
| `11`, `18` | extracellular depletion; Fig. S10 is written by `18` (`11` is the earlier version and writes `fig11_depletion.png`) |
| `12` | two-dimensional selectivity map |
| `13` | model selection by AICc/BIC; Fig. S7 |
| `14` | saturable clearance, both V_max conventions; Fig. S1 |
| `15` | coupled C_in / gate dynamics; Fig. 3 |
| `16` | selectivity against the Hill exponent |
| `17` | required clearance ratio by calibration attribution |

## Grid extents in `10_bootstrap_uncertainty.py`

The window search runs to 600 µM and the dose interpolation to 700 µM. Both
matter: `np.interp` clamps beyond its grid rather than extrapolating, so a window
search wider than the dose grid would freeze the astrocyte dose and return a
spurious upper bound. With both set as given, the 3 h window is
67–350 µM, with a 95% bootstrap interval of [288, 404] µM on the upper bound.

## Sampling

`sobol_bounds.csv` holds the ranges, distributions and estimator settings:
2048-point scrambled Sobol base sample, 20 480 total evaluations, Saltelli (2010)
for S₁ and Jansen (1999) for S_T, 300 bootstrap resamples, 20 000 Monte Carlo
draws. The implementation uses `scipy.stats.qmc`; SALib is not required.
