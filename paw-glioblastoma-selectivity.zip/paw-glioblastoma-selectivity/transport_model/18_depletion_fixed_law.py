#!/usr/bin/env python3
"""Fig. S10 - extracellular depletion, with the survival law HELD FIXED.

The shipped 11_depletion_selfconsistent.py refits the Hill law under the depletion
kinetics and then compares the result to the unrefitted constant-C_out case. That
comparison cannot demonstrate invariance. Here both are shown side by side.

Under depletion the total dose is C_out(0)/(phi*k_clear), so the membrane terms
cancel from the cumulative exposure and the dose ratio becomes exactly the
clearance ratio.
"""
import os, sys
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as m

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures")
os.makedirs(OUT, exist_ok=True)
PHI = 1.0e-4

def dep(cell, C0_uM, phi, tmax=8*3600):
    def rhs(t, y):
        Co, Ci, _ = y
        J = (m.P_LIP + m.P_AQP8[cell]*m.gate(Ci)) * m.AV * (Co - Ci)
        return [-phi*J, J - m.K_CLEAR[cell]*Ci, Ci*1e6]
    return solve_ivp(rhs, (0, tmax), [C0_uM*1e-6, 0, 0], method="LSODA",
                     rtol=1e-9, atol=1e-16, dense_output=True)

ts = np.linspace(0, 6*3600, 3000)
for cell in ("u87", "astro"):
    Co = dep(cell, 100, PHI).sol(ts)[0] / 100e-6
    print(f"  {cell:5s}: C_out half-life {ts[np.argmax(Co<.5)]/3600:.2f} h ; "
          f"10% at {ts[np.argmax(Co<.1)]/3600:.2f} h")
Da_d, Du_d = dep("astro", 100, PHI).y[2, -1], dep("u87", 100, PHI).y[2, -1]
D50_0, h_0, _ = m.calibrate()
Sa_f, Su_f = m.hill(Da_d, D50_0, h_0), m.hill(Du_d, D50_0, h_0)
Dk = np.array([dep("u87", c, PHI).y[2, -1] for c, _ in m.KURAKE])
(D50_d, h_d), _ = curve_fit(m.hill, Dk, m.S_KUR, p0=[Dk[1], 5],
                            bounds=([1, .5], [1e9, 20]), maxfev=40000)
Sa_r, Su_r = m.hill(Da_d, D50_d, h_d), m.hill(Du_d, D50_d, h_d)
Da_c = m.dose(m.P_AQP8["astro"], m.K_CLEAR["astro"])
Du_c = m.dose(m.P_AQP8["u87"],  m.K_CLEAR["u87"])
print(f"  dose ratio: depletion {Du_d/Da_d:.2f} (= clearance ratio)  vs constant C_out {Du_c/Da_c:.2f}")
print(f"  survival law FIXED      : astro {Sa_f*100:5.1f}%  U87 {Su_f*100:5.1f}%  sel {Sa_f/Su_f:6.2f}x")
print(f"  survival law REFITTED   : astro {Sa_r*100:5.1f}%  U87 {Su_r*100:5.1f}%  sel {Sa_r/Su_r:6.1f}x")

fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
for cell, col in (("astro", "tab:blue"), ("u87", "tab:red")):
    s = dep(cell, 100, PHI)
    ax[0].plot(ts/3600, s.sol(ts)[0]*1e6, col, lw=2, label=f"{cell} $C_{{out}}$")
    ax[0].plot(ts/3600, s.sol(ts)[1]*1e6, col, lw=2, ls="--", label=f"{cell} $C_{{in}}$")
ax[0].axhline(50, color="grey", ls=":", lw=.8)
ax[0].set(xlabel="time (h)", ylabel=r"H$_2$O$_2$ (µM)",
          title=f"Self-consistent depletion ($\\phi$={PHI:.1e}; $C_{{out}}$ half-life 0.70 h)")
ax[0].legend(fontsize=8)
lab = ["constant $C_{out}$\n(3 h window)", "depletion,\nsurvival law FIXED", "depletion,\nlaw REFITTED"]
val = [m.hill(Da_c, D50_0, h_0)/m.hill(Du_c, D50_0, h_0), Sa_f/Su_f, Sa_r/Su_r]
u87 = [m.hill(Du_c, D50_0, h_0)*100, Su_f*100, Su_r*100]
ax[1].bar(np.arange(3), val, color=["grey", "tab:orange", "tab:red"], alpha=.85)
for i, (v, u) in enumerate(zip(val, u87)):
    ax[1].text(i, v*1.05+1, f"{v:.1f}×\nU87 {u:.1f}%", ha="center", fontsize=8.5)
ax[1].set_xticks(np.arange(3)); ax[1].set_xticklabels(lab, fontsize=8.5)
ax[1].set_ylabel("kill selectivity (astro / U87 survival)")
ax[1].set_title("Selectivity under depletion depends on\nwhether the survival law is refitted", fontsize=10)
ax[1].set_ylim(0, max(val)*1.35)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figS10_depletion.png"), dpi=200)
print(f"Saved {OUT}/figS10_depletion.png")
