#!/usr/bin/env python3
# ======================================================================
# 02b_conditional_robustness.py
# Paper A — Monte-Carlo robustness of the dose selectivity CONDITIONAL on
# the clearance-ratio prior, i.e. the quantity the Monte-Carlo numbers of
# Sec. 3.6 actually report. The unconditional P(S_dose > thr) of script 02
# inherits the uniform prior k_astro/k_U87 ~ U[1, 30], under which 86% of
# the draws already exceed the 5-fold ratio that the selectivity needs;
# binning on that ratio separates the model's behaviour from the prior.
#
# Model, bounds and sampling are those of 02_sensitivity_robustness.py
# (P_AQP8 decoupled from P_lip). Only the k-ratio range is restricted,
# bin by bin, and each bin is sampled to its own 20,000 draws so that the
# narrow bins are as precise as the wide one.
#
# Deps:  numpy, scipy
# Run:   python3 02b_conditional_robustness.py
# ======================================================================
import numpy as np
from scipy.optimize import brentq

AoverV = 4000.0        # cm^-1 (fixed; geometry measurable)
NDRAW = 20000          # draws per bin
SEED = 2026


# ---- model: identical to 02_sensitivity_robustness.py ----
def model(p):
    rho_ratio, k_ratio, PA_astro, P_lip, k_astro, C_half, n, C_out = p
    PA_a = PA_astro; PA_u = rho_ratio * PA_astro; k_u = k_astro / k_ratio
    kin = lambda P, g: (P * g + P_lip) * AoverV
    gg = lambda C: 1.0 / (1.0 + (C / C_half) ** n)
    ss = lambda P, kcl: brentq(lambda C: kin(P, gg(C)) * (C_out - C) - kcl * C, 0.0, C_out)
    Cin_a, Cin_u = ss(PA_a, k_astro), ss(PA_u, k_u)
    Phi_a = (PA_a + P_lip) * AoverV / k_astro
    Phi_u = (PA_u + P_lip) * AoverV / k_u
    return Cin_u / max(Cin_a, 1e-15), bool(Phi_a < 1.0 < Phi_u)


names = ['rho ratio', 'k ratio', 'P_AQP8,astro', 'P_lip', 'k_astro', 'C_half', 'n', 'C_out']
bounds = np.array([[1, 15], [1, 30], [1e-4, 2e-3], [1e-4, 1e-3], [20., 100.],
                   [20e-6, 80e-6], [1., 4.], [50e-6, 300e-6]])
lo, hi = bounds.T.copy()
BINS = [(1, 2), (2, 5), (5, 10), (10, 30)]

print(f"Prior on k ratio: U[{bounds[1,0]:g}, {bounds[1,1]:g}]  ->  "
      f"P(ratio > 5) = {(bounds[1,1]-5)/(bounds[1,1]-bounds[1,0]):.3f}")
print(f"\n{NDRAW} draws per bin, n sampled over "
      f"[{bounds[6,0]:g}, {bounds[6,1]:g}] throughout (so the baseline gate order does not enter)\n")
print(f"{'k ratio':>9} | {'median S_dose':>13} | {'P(S>2)':>6} | {'P(S>5)':>6} | {'P(regime sep.)':>14}")
print("-" * 66)

rng = np.random.default_rng(SEED)
rows = []
for b_lo, b_hi in BINS:
    l, h = lo.copy(), hi.copy()
    l[1], h[1] = b_lo, b_hi
    X = rng.uniform(l, h, size=(NDRAW, len(names)))
    S = np.empty(NDRAW); sw = np.empty(NDRAW, bool)
    for i, x in enumerate(X):
        S[i], sw[i] = model(x)
    row = (f"{b_lo:g}-{b_hi:g}", np.median(S), (S > 2).mean(), (S > 5).mean(), sw.mean())
    rows.append(row)
    print(f"{row[0]:>9} | {row[1]:13.1f} | {row[2]:6.2f} | {row[3]:6.2f} | {row[4]:14.2f}")

# Monte-Carlo standard error on a probability p from NDRAW independent draws
print(f"\nStandard error on each probability <= {0.5/np.sqrt(NDRAW):.4f} "
      f"(binomial, {NDRAW} draws)")
with open('conditional_robustness.txt', 'w') as f:
    f.write("k_ratio_bin,median_S_dose,P_S_gt_2,P_S_gt_5,P_regime_separation\n")
    for r in rows:
        f.write(f"{r[0]},{r[1]:.2f},{r[2]:.3f},{r[3]:.3f},{r[4]:.3f}\n")
print("Saved: conditional_robustness.txt")
