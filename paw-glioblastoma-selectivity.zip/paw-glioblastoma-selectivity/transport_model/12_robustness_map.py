#!/usr/bin/env python3
# ======================================================================
# 12_robustness_map.py  
# Kill selectivity at 100 uM / 3 h over the full (k_astro, k_u87) plane,
# i.e. across literature-plausible normal AND tumour clearance constants.
# Shows the selectivity is not knife-edge: a broad region gives strong
# selectivity, bounded below by the no-asymmetry diagonal (k_astro=k_u87).
# Hill survival fixed at the Kurake calibration (computed by _model.calibrate()).
# Deps: numpy, scipy, matplotlib
# ======================================================================
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

AoverV=4000.0; P_lip=5e-4; C_half=40e-6; n_gate=1.0
P_AQP8={"astro":1.0*P_lip,"u87":4.0*P_lip}
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _model import calibrate
D50, H, _ = calibrate(); WIN_s=3*3600.0   # Hill law fitted to Kurake at n_gate (see 07)
g=lambda C:1.0/(1.0+(C/C_half)**n_gate)
def surv(P8,k,C_out_uM):
    rhs=lambda t,y:[(P8*g(y[0])+P_lip)*AoverV*(C_out_uM*1e-6-y[0])-k*y[0]]
    Cin=solve_ivp(rhs,(0,5.0),[0],method="LSODA",rtol=1e-10,atol=1e-16).y[0,-1]*1e6
    return 1.0/(1.0+((Cin*WIN_s)/D50)**H)

ka=np.linspace(10,100,46); ku=np.linspace(1,55,46)   # normal vs tumour clearance (s^-1)
Z=np.zeros((len(ka),len(ku)))
Sa_cache={}
for i,a in enumerate(ka):
    Sa=surv(P_AQP8["astro"],a,100.); Sa_cache[i]=Sa
    for j,u in enumerate(ku):
        Su=surv(P_AQP8["u87"],u,100.)
        Z[i,j]=Sa/max(Su,1e-9)
LZ=np.log10(np.clip(Z,1,1e3))
fig,ax=plt.subplots(figsize=(6.6,5.2))
pc=ax.pcolormesh(ku,ka,LZ,cmap="viridis",shading="auto")
cb=fig.colorbar(pc,ax=ax); cb.set_label("log$_{10}$ kill selectivity (astro/U87)")
cs=ax.contour(ku,ka,Z,levels=[2,5,20,50],colors="white",linewidths=1)
ax.clabel(cs,fmt="%d×",fontsize=8)
ax.plot([1,55],[1,55],"r--",lw=1.5,label="no asymmetry (k$_{astro}$=k$_{U87}$)")
ax.plot(5,50,"r*",ms=18,label="model (k$_{U87}$=5, k$_{astro}$=50)")
# Doskey average normal/tumour ~1.8x band
ax.plot(ku,1.8*ku,"w:",lw=1.3,label="Doskey avg (k$_{astro}$/k$_{U87}$=1.8)")
ax.set_xlabel("tumour clearance k$_{U87}$ (s$^{-1}$)")
ax.set_ylabel("normal clearance k$_{astro}$ (s$^{-1}$)")
ax.set_title("Selectivity robustness across the clearance plane\n(100 µM, 3 h)")
ax.legend(fontsize=7.5,loc="lower right"); ax.set_xlim(1,55); ax.set_ylim(10,100)
fig.tight_layout(); fig.savefig("fig12_robustness_map.png",dpi=200)
print("Saved fig12_robustness_map.png")
print(f"model point selectivity = {Z[np.argmin(abs(ka-50)),np.argmin(abs(ku-5))]:.0f}x")
frac=(Z>5).mean()*100
print(f"fraction of the explored plane with selectivity >5x: {frac:.0f}%")
