#!/usr/bin/env python3
"""Fig. 3 - cytoplasmic concentration and gate occupancy from the COUPLED system.

Replaces the earlier Fig. 3, which plotted a 0-2 s axis with the gate applied as
an instantaneous function of C_in. That contradicted Section 2.3, which states
that covalent gating is slow relative to transport. Here Eq. (2) and Eq. (6) are
integrated together, on a logarithmic time axis so both timescales are visible.

Eq. (6) steady state fixes k_red = k_ox * C_half, so the two rate constants are
not independent.
"""
import os, sys
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as m

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures")
os.makedirs(OUT, exist_ok=True)
K_OX = 100.0                 # M^-1 s^-1 (upper end of the 10-10^2 range)
K_RED = K_OX * m.C_HALF
TMAX = 1800.0

def run(cell, gated=True):
    P, k = m.P_AQP8[cell], m.K_CLEAR[cell]
    def rhs(t, y):
        C, g = y
        dg = (-K_OX * C * g + K_RED * (1 - g)) if gated else 0.0
        return [(P * g + m.P_LIP) * m.AV * (m.C_OUT - C) - k * C, dg]
    return solve_ivp(rhs, (0, TMAX), [0.0, 1.0], method="LSODA",
                     rtol=1e-10, atol=1e-14, dense_output=True)

t = np.concatenate([np.logspace(-3, 0, 400), np.linspace(1, TMAX, 4000)[1:]])
Cu, gu = run("u87").sol(t); Ca, ga = run("astro").sol(t); Cun, _ = run("u87", False).sol(t)
tau_g = 1.0 / (K_OX * Cu[-1] + K_RED)
tau_t = 1.0 / ((m.P_AQP8["u87"] + m.P_LIP) * m.AV + m.K_CLEAR["u87"])
print(f"k_ox={K_OX:g} /M/s -> k_red={K_RED:.2e} /s (C_half = k_red/k_ox = {K_RED/K_OX*1e6:.0f} uM)")
print(f"tau_transport = {tau_t*1e3:.0f} ms ; tau_gate = {tau_g:.0f} s ({tau_g/60:.1f} min)")
print(f"U87 C_in peak {Cu.max()*1e6:.1f} -> {Cu[-1]*1e6:.1f} uM ; g 1.00 -> {gu[-1]:.2f}")
print(f"astrocyte C_in {Ca[-1]*1e6:.2f} uM ; g {ga[-1]:.2f}")

dyn = solve_ivp(lambda tt, y: [(m.P_AQP8["u87"]*y[1]+m.P_LIP)*m.AV*(m.C_OUT-y[0])-m.K_CLEAR["u87"]*y[0],
                               -K_OX*y[0]*y[1]+K_RED*(1-y[1]), y[0]*1e6],
                (0, m.T_EXPOSURE), [0, 1, 0], method="LSODA", rtol=1e-9, atol=1e-14).y[2, -1]
qss = m.dose(m.P_AQP8["u87"], m.K_CLEAR["u87"])
print(f"3 h dose: coupled {dyn:.3e} vs quasi-steady-state {qss:.3e} uM*s "
      f"-> early-transient excess {100*(dyn/qss-1):.1f}%")

fig, ax = plt.subplots(1, 2, figsize=(11, 4.1))
ax[0].semilogx(t, Cun*1e6, "tab:red", ls="--", lw=2, label="U87 + PAW (no brake)")
ax[0].semilogx(t, Cu*1e6, "tab:red", lw=2, label="U87 + PAW (Cys53 brake, Eq. 6)")
ax[0].semilogx(t, Ca*1e6, "tab:blue", lw=2, label="astrocyte")
ax[0].axhline(m.C_OUT*1e6, color="grey", ls=":")
ax[0].text(TMAX*.9, m.C_OUT*1e6*.96, r"$C_{out}$", color="grey", fontsize=9, ha="right", va="top")
for x, lb in ((tau_t, rf"$\tau_{{transport}}$={tau_t*1e3:.0f} ms"), (tau_g, rf"$\tau_{{gate}}$={tau_g:.0f} s")):
    ax[0].axvline(x, color="k", ls=":", lw=.9)
    ax[0].text(x*1.15, 96, lb, fontsize=8, rotation=90, va="top")
ax[0].set(xlabel="time (s, log scale)", ylabel=r"intracellular $C_{in}$ (µM)",
          title="Two separated timescales: fast influx, slow gate", ylim=(0, 105))
ax[0].legend(fontsize=8.5, loc="center left")
ax[1].semilogx(t, gu, "tab:red", lw=2, label="U87 + PAW")
ax[1].semilogx(t, ga, "tab:blue", lw=2, label="astrocyte")
ax[1].axvline(tau_g, color="k", ls=":", lw=1)
ax[1].text(tau_g*1.2, .55, rf"$\tau_{{gate}}\approx${tau_g:.0f} s" "\n" rf"({tau_g/60:.1f} min)", fontsize=9)
ax[1].set(xlabel="time (s, log scale)", ylabel="open-channel fraction $g$",
          title="AQP8 Cys53 gate, integrated from Eq. (6)", ylim=(0, 1.05))
ax[1].legend(fontsize=9, loc="lower left")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig3_coupled_gating.png"), dpi=200)
print(f"Saved {OUT}/fig3_coupled_gating.png")
