#!/usr/bin/env python3
# ======================================================================
# 07_survival_hill_kurake.py  
# (c) Replace the single-hit survival exp(-D/D_lethal) with a COOPERATIVE
#     Hill survival  S(D) = 1 / (1 + (D/D50)^h)  fitted to the real
#     glioblastoma H2O2 kill curve (Kurake 2016, Fig 4b-iii, killing branch).
# (a) Use the physically-correct effective exposure window (3 h assumed effective window) instead of the illustrative 5 min,
#     and recompute astrocyte vs U87 survival / therapeutic window.
# Deps: numpy, scipy, matplotlib
# ======================================================================
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

AoverV=4000.0; P_lip=5e-4; C_half=40e-6; n_gate=1.0
PARAMS={"astro":dict(P_AQP8=1.0*P_lip,k=50.0), "u87":dict(P_AQP8=4.0*P_lip,k=5.0)}
g=lambda C:1.0/(1.0+(C/C_half)**n_gate)
def dose(cell,C_out_uM,time_min,gate=True):
    p=PARAMS[cell]; C_out=C_out_uM*1e-6; T=time_min*60.0
    rhs=lambda t,y:[(p["P_AQP8"]*(g(y[0]) if gate else 1)+P_lip)*AoverV*(C_out-y[0])-p["k"]*y[0], y[0]*1e6]
    return solve_ivp(rhs,(0,T),[0,0],method="LSODA",rtol=1e-9,atol=1e-14).y[1,-1]

# --- Kurake 2016 Fig 4b(iii): H2O2-only, U251SP, killing branch (read off figure) ---
WIN=180.0   # effective exposure window (min)
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as _m
kur=_m.KURAKE            # single source: killcurve.csv via _model.py
Dk=np.array([dose("u87",c,WIN) for c,_ in kur]); Sk=np.array([s for _,s in kur])

hill=lambda D,D50,h:1.0/(1.0+(D/D50)**h)
(p50,ph),_=curve_fit(hill,Dk,Sk,p0=[Dk[1],3.0],bounds=([1,0.5],[1e8,12]),maxfev=20000)
R2=1-np.sum((Sk-hill(Dk,p50,ph))**2)/np.sum((Sk-Sk.mean())**2)
print(f"Hill survival fit to Kurake:  D50={p50:.3e} uM*s   h={ph:.2f}   R^2={R2:.3f}")
for (c,s),d in zip(kur,Dk): print(f"  {c:5.1f}uM  D={d:.2e}  obs={s:.2f}  Hill={hill(d,p50,ph):.2f}")

# --- recompute astro vs U87 survival on the hours timescale ---
def surv(cell,C_out,T_min): return hill(dose(cell,C_out,T_min),p50,ph)
print(f"\n--- survival at 100 uM, window {WIN/60:.0f} h (Hill, calibrated) ---")
Sa,Su=surv("astro",100,WIN),surv("u87",100,WIN)
print(f"  astrocyte {Sa*100:4.1f}% | U87 {Su*100:4.1f}% | kill selectivity (astro/U87 survival) {Sa/Su:.1f}x")
print(f"  (compare OLD single-hit, 5 min, D_lethal=1e4:  astro ~80% / U87 ~22%)")

# survival vs C_out (3 h) and vs time (100 uM)
Cgrid=np.linspace(0,200,60)
fig,ax=plt.subplots(1,2,figsize=(11,4))
ax[0].plot(Cgrid,[surv("astro",c,WIN)*100 for c in Cgrid],'b-',lw=2,label="astrocyte")
ax[0].plot(Cgrid,[surv("u87",c,WIN)*100 for c in Cgrid],'r-',lw=2,label="U87-MG")
ax[0].scatter([c for c,_ in kur],[s*100 for _,s in kur],c='k',zorder=5,label="Kurake U251SP (H2O2)")
ax[0].axhline(50,ls=':',c='grey'); ax[0].set_xlabel("C_out H2O2 (uM)"); ax[0].set_ylabel("survival (%)")
ax[0].set_title(f"Dose-survival ({WIN/60:.0f} h, Hill-calibrated)"); ax[0].legend(fontsize=8)
Tg=np.linspace(0,300,60)
ax[1].plot(Tg,[surv("astro",100,t)*100 for t in Tg],'b-',lw=2,label="astrocyte")
ax[1].plot(Tg,[surv("u87",100,t)*100 for t in Tg],'r-',lw=2,label="U87-MG")
ax[1].set_xlabel("exposure (min)"); ax[1].set_ylabel("survival (%)")
ax[1].set_title("Survival vs exposure @100 uM"); ax[1].legend(fontsize=8)
fig.tight_layout(); fig.savefig("fig7b_survival_hill_kurake.png",dpi=200)
print("\nSaved fig7b_survival_hill_kurake.png")

# therapeutic window: C_out where U87<20% but astro>80% (3 h)
# NOTE: use an extended grid for the window search — the astrocyte-tolerance
# upper bound lies near ~350 uM, BEYOND the 0-200 uM plotting grid (Cgrid)
# used for fig7b; capping the search at 200 uM understates the upper bound.
wgrid=np.linspace(0,400,400)
ok=[c for c in wgrid if surv("u87",c,WIN)<0.20 and surv("astro",c,WIN)>0.80]
if ok: print(f"Therapeutic window (3 h): C_out in [{min(ok):.0f}, {max(ok):.0f}] uM -> U87<20%, astro>80%")
else:  print("No C_out gives U87<20% & astro>80% at 3 h (check params).")
