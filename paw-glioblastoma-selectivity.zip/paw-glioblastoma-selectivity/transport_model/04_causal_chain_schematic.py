#!/usr/bin/env python3
# ======================================================================
# 04_causal_chain_schematic.py
# Paper A — Fig 9: conceptual framework and causal chain, panels A–D.
#   A  PAW input and the two membrane influx pathways (lipid, AQP8),
#      with the Cys53 redox brake on the channel route
#   B  transport–clearance balance (Equations of Section 2.5)
#   C  the two cell-model operating points on C_in/C_out = Φ/(1+Φ)
#   D  cumulative dose -> Hill survival -> therapeutic window
#   banner: the three convergent nulls of Section 4.1
# Every element is a matplotlib vector primitive or a curve computed
# from the model equations below; no raster input is read.
# Deps:  matplotlib, numpy
# Run:   python3 04_causal_chain_schematic.py
# ======================================================================
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

# --- values shown in the figure (Table 1 and Sections 3.2-3.8) ---
PHI_ASTRO, PHI_U87 = 0.08, 2.0          # transport numbers
K_RATIO = 10                             # k_astro / k_U87
D50, H = 3.06e5, 5.21                    # Hill survival calibration (µM·s), n = 1
S_U87, SEL = 3.9, 25                     # U87 survival (%), selectivity (fold)
WINDOW = (67, 350)                       # 3 h therapeutic window (µM)

CA, CU = "#2A9D8F", "#E63946"            # astrocyte, U87-MG
CM, CL, CG = "#1982C4", "#E09F3E", "#9D0208"   # AQP8, lipid, Cys53 brake
INK, MUTE, FRAME = "#222222", "#666666", "#B8B8B8"

fig = plt.figure(figsize=(16, 9.6))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 160); ax.set_ylim(0, 96); ax.axis("off")


def panel(x, y, w, h, letter, title):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.2",
                                fc="#FAFAFA", ec=FRAME, lw=1.2, zorder=0))
    ax.add_patch(FancyBboxPatch((x + 1.2, y + h - 5.2), 4, 4, boxstyle="round,pad=0,rounding_size=0.6",
                                fc=INK, ec="none", zorder=2))
    ax.text(x + 3.2, y + h - 3.2, letter, ha="center", va="center", color="white",
            fontsize=13, fontweight="bold", zorder=3)
    ax.text(x + 6.5, y + h - 3.2, title, ha="left", va="center", fontsize=12.5,
            fontweight="bold", color=INK)


def box(x, y, w, h, text, fc, ec="none", tc="white", fs=10.5, bold=True, ls="-"):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0,rounding_size=0.8",
                                fc=fc, ec=ec, lw=1.3, ls=ls, zorder=2))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, color=tc,
            fontweight="bold" if bold else "normal", zorder=3, linespacing=1.4)


def arrow(p, q, c=INK, lw=2.2, rad=0.0, ls="-", head="-|>"):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle=head, mutation_scale=18, lw=lw, color=c,
                                 linestyle=ls, connectionstyle=f"arc3,rad={rad}", zorder=4))


fig.text(0.5, 0.975, "The H$_2$O$_2$ selectivity chain:  PAW → membrane transport → dose → therapeutic window",
         ha="center", va="center", fontsize=15, fontweight="bold", color=INK)

# ---------------------------------------------------------------- panel A
panel(1, 39, 50, 52, "A", "PAW input and membrane transport")
box(26, 78, 30, 7, "PAW: extracellular H$_2$O$_2$,  $C_{out}(t)$", "#6A4C93", fs=10.5)
ax.text(38, 64.5, "extracellular", fontsize=9.5, color=MUTE, style="italic")
ax.text(38, 52.6, "intracellular", fontsize=9.5, color=MUTE, style="italic")
ax.add_patch(Rectangle((3, 56), 46, 7, fc="#EDE6D6", ec="#C9BFA6", lw=1, zorder=1))   # bilayer
ax.text(47.5, 59.5, "lipid\nbilayer", fontsize=8.5, color="#8A7F66", ha="right", va="center")
# AQP8 channel: two subunits flanking a pore
ax.add_patch(Rectangle((14.2, 54.5), 2.6, 10, fc=CM, ec="none", zorder=2))
ax.add_patch(Rectangle((19.2, 54.5), 2.6, 10, fc=CM, ec="none", zorder=2))
arrow((18, 74), (18, 51.5), c=CM, lw=3.0)
ax.text(18, 48.5, "AQP8 pathway\n$P_{AQP8}\\cdot g$", ha="center", va="top", fontsize=10, color=CM,
        fontweight="bold")
arrow((34, 74), (34, 51.5), c=CL, lw=2.4, ls=(0, (4, 2)))
ax.text(34, 48.5, "lipid pathway\n$P_{lip}$", ha="center", va="top", fontsize=10, color=CL,
        fontweight="bold")
# Cys53 redox brake on the channel
box(8.2, 69.0, 11.5, 6.5, "Cys53 oxidation\n→ $g$ < 1 (brake)", "white", ec=CG, tc=CG, fs=8.6, ls="--")
arrow((9.5, 65.6), (13.9, 62.0), c=CG, lw=1.6)
ax.text(26, 41.2, "passive, bidirectional transport across the membrane", ha="center",
        fontsize=8.8, color=MUTE, style="italic")
arrow((51.5, 65), (55.5, 65), lw=2.6)

# ---------------------------------------------------------------- panel B
panel(56, 39, 48, 52, "B", "Transport–clearance balance")
eqs = [(80, "$k_m=\\dfrac{(P_{AQP8}\\,g+P_{lip})\\,A}{V}$"),
       (70, "$\\dfrac{dC_{in}}{dt}=k_m\\,(C_{out}-C_{in})-k_{clear}\\,C_{in}$"),
       (61, "$\\Phi=\\dfrac{k_m}{k_{clear}}$"),
       (51, "$\\dfrac{C_{in,ss}}{C_{out}}=\\dfrac{\\Phi}{1+\\Phi}$")]
for y, s in eqs:
    ax.text(80, y, s, ha="center", va="center", fontsize=14, color=INK)
ax.text(80, 43.0, "A: membrane area  ·  V: cell volume  ·  first-order intracellular clearance",
        ha="center", fontsize=8.8, color=MUTE, style="italic")
arrow((104.5, 65), (108.5, 65), lw=2.6)

# ---------------------------------------------------------------- panel C
panel(109, 39, 50, 52, "C", "Cell-model scenarios")
ax.text(134, 82.3, f"Dominant lever: clearance asymmetry  $k_{{astro}}/k_{{U87}}={K_RATIO}$",
        ha="center", fontsize=10.5, fontweight="bold", color=INK)
axc = fig.add_axes([0.725, 0.545, 0.235, 0.28])
phi = np.logspace(-2, 2, 400)
axc.plot(phi, phi / (1 + phi), color=INK, lw=1.8)
axc.axvline(1, color=MUTE, ls=":", lw=1.2)
axc.axvspan(1e-2, 1, color=CA, alpha=0.08, lw=0)
axc.axvspan(1, 1e2, color=CU, alpha=0.08, lw=0)
for p_, c_, lab, xy in [(PHI_ASTRO, CA, "astrocyte, catalase intact", (0.075, 0.50)),
                        (PHI_U87, CU, "U87-MG, catalase\ncollapsed by PAW", (11.0, 0.40))]:
    ps = f"{p_:.2f}" if p_ < 1 else f"{p_:.1f}"
    r = p_ / (1 + p_)
    axc.plot(p_, r, "o", ms=10, mfc=c_, mec="white", mew=1.5, zorder=5)
    axc.annotate(f"{lab}\n$\\Phi={ps}$  →  $C_{{in}}/C_{{out}}={r:.2g}$", (p_, r),
                 xytext=xy, ha="center", va="center", fontsize=8.4, color=c_, fontweight="bold",
                 arrowprops=dict(arrowstyle="-", color=c_, lw=1, shrinkA=8, shrinkB=6))
axc.set_xscale("log"); axc.set_xlim(1e-2, 1e2); axc.set_ylim(0, 1.05)
axc.set_xlabel("transport number  $\\Phi$", fontsize=9.5)
axc.set_ylabel("$C_{in,ss}/C_{out}$", fontsize=9.5)
axc.text(0.11, 0.97, "clearance-\ndominated", transform=axc.transAxes, fontsize=8, color=CA, va="top")
axc.text(0.97, 0.06, "influx-\ndominated", transform=axc.transAxes, fontsize=8, color=CU, ha="right")
axc.tick_params(labelsize=8.5)
for s in ("top", "right"):
    axc.spines[s].set_visible(False)
axc.set_facecolor("none")
ax.text(134, 41.4, "AQP8 fold-change: amplifying but not gating ($S_T\\approx0.08$)\n"
        "$P_{lip}$ sets the selectivity ceiling", ha="center", fontsize=9.3, color=MUTE,
        style="italic", linespacing=1.4)
arrow((134, 38.6), (134, 34.4), lw=2.6)

# ---------------------------------------------------------------- panel D
panel(1, 9, 158, 25, "D", "Intracellular exposure and therapeutic window")
box(24, 19.5, 34, 11, "cumulative intracellular dose\n$D=\\int_0^T C_{in}(t)\\,dt$", "#4D4D4D", fs=10.5)
arrow((41.5, 19.5), (47, 19.5), lw=2.4)
box(63, 19.5, 30, 11, "Hill survival calibration\n$D_{50}=3.06\\times10^{5}$ µM·s,  $h=5.21$",
    "#4D4D4D", fs=10.5)
axd = fig.add_axes([0.57, 0.125, 0.11, 0.16])
dd = np.logspace(-1, 1, 300)
axd.plot(dd, 1 / (1 + dd ** H), color=INK, lw=1.6)
axd.axvline(1, color=MUTE, ls=":", lw=1)
axd.set_xscale("log"); axd.set_xlim(0.1, 10); axd.set_ylim(0, 1.05)
axd.set_xlabel("$D/D_{50}$", fontsize=8.5, labelpad=1); axd.set_ylabel("survival", fontsize=8.5, labelpad=1)
axd.tick_params(labelsize=7.5)
for s in ("top", "right"):
    axd.spines[s].set_visible(False)
axd.set_facecolor("none")
arrow((110, 19.5), (114.5, 19.5), lw=2.4)
box(136, 19.5, 42, 11, f"exposure contrast → therapeutic window\n"
    f"U87-MG ≈ {S_U87}% survival, ≈ {SEL}-fold selectivity (Fig. 7)\n"
    f"window {WINDOW[0]}–{WINDOW[1]} µM over 3 h (Fig. 8)", "#E9A23B", tc=INK, fs=9.8)

# ---------------------------------------------------------------- nulls banner
ax.add_patch(FancyBboxPatch((1, 1.2), 158, 5.6, boxstyle="round,pad=0,rounding_size=0.8",
                            fc="#F0F0F0", ec=FRAME, lw=1, zorder=0))
ax.text(80, 4.0, "Excluded by three convergent nulls (Section 4.1):   ✗ pristine-bilayer structure and order"
        "     ✗ a selective lipid permeation barrier     ✗ bulk clearance acting as a linear scalar",
        ha="center", va="center", fontsize=10, color="#555555")

plt.savefig("fig9_unified_chain.png", dpi=220)
plt.savefig("fig9_unified_chain.pdf")
print("Saved: fig9_unified_chain.png, fig9_unified_chain.pdf")
