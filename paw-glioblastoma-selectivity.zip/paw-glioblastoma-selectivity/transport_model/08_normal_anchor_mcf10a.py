#!/usr/bin/env python3
# ======================================================================
# 08_normal_anchor_mcf10a.py  
# Overlays the Kurake 2016 normal-cell (MCF10A) survival anchor on the
# model's astrocyte (normal) dose-survival curve, converting the
# astro~100% prediction from extrapolation into a data-supported claim.
# NOTE: Kurake has NO H2O2-only dose-response for MCF10A. The anchor is a
# single point: Fig 6, 64 uM H2O2 (+1740 uM nitrite) -> MCF10A ~93%.
# Because nitrite alone is non-lethal (Fig 4-ii), MCF10A H2O2-only >= 93%,
# so 93% is a CONSERVATIVE lower bound at 64 uM. MCF10A is mammary
# epithelium (a generic normal-cell proxy, not astrocyte-specific).
# ======================================================================
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

AoverV=4000.0; P_lip=5e-4; C_half=40e-6; n_gate=1.0
PARAMS={"astro":dict(P_AQP8=1.0*P_lip,k=50.0),"u87":dict(P_AQP8=4.0*P_lip,k=5.0)}
g=lambda C:1.0/(1.0+(C/C_half)**n_gate)
def dose(cell,C_out_uM,time_min):
    p=PARAMS[cell]; C_out=C_out_uM*1e-6; T=time_min*60.0
    rhs=lambda t,y:[(p["P_AQP8"]*g(y[0])+P_lip)*AoverV*(C_out-y[0])-p["k"]*y[0], y[0]*1e6]
    return solve_ivp(rhs,(0,T),[0,0],method="LSODA",rtol=1e-9,atol=1e-14).y[1,-1]

WIN=180.0
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as _m
kur=_m.KURAKE            # U251SP H2O2-only (Fig 4b-iii); single source: killcurve.csv via _model.py
Dk=np.array([dose("u87",c,WIN) for c,_ in kur]); Sk=np.array([s for _,s in kur])
hill=lambda D,D50,h:1.0/(1.0+(D/D50)**h)
(p50,ph),_=curve_fit(hill,Dk,Sk,p0=[Dk[1],3.0],bounds=([1,0.5],[1e8,12]),maxfev=20000)
surv=lambda cell,C,T: hill(dose(cell,C,T),p50,ph)

# --- Kurake normal-cell anchor (MCF10A), Fig 6: 64 uM H2O2(+nitrite) ---
MCF=dict(C=64.0, S=0.93, err=0.15)   # lower bound for H2O2-only
print(f"Model prediction at {MCF['C']:.0f} uM, 3 h:")
print(f"  astrocyte (model)         = {surv('astro',MCF['C'],WIN)*100:5.1f}%")
print(f"  U87-MG    (model)         = {surv('u87',MCF['C'],WIN)*100:5.1f}%")
print(f"  MCF10A normal (Kurake Fig6)= {MCF['S']*100:5.0f} +/- {MCF['err']*100:.0f}%  (>= this for H2O2-only)")
print(f"  U251SP    (Kurake Fig6,+NO2)= ~25%")

Cgrid=np.linspace(0,200,80)
fig,ax=plt.subplots(figsize=(6.2,5.3))
ax.plot(Cgrid,[surv("astro",c,WIN)*100 for c in Cgrid],'b-',lw=2,label="astrocyte (model)")
ax.plot(Cgrid,[surv("u87",c,WIN)*100 for c in Cgrid],'r-',lw=2,label="U87-MG (model)")
ax.scatter([c for c,_ in kur],[s*100 for _,s in kur],c='r',marker='o',zorder=5,
           label="Kurake U251SP H$_2$O$_2$ (glioblastoma)")
# The anchor is a LOWER BOUND for H2O2-only exposure (nitrite alone is non-lethal,
# Kurake Fig. 4-ii), so it is drawn as a bound: the reading uncertainty is shown
# downwards only and an arrow marks the open side. A symmetric bar would place
# survival above 100%, which is not a possible value.
ax.errorbar(MCF['C'],MCF['S']*100,yerr=[[MCF['err']*100],[0.0]],fmt='^',c='b',ms=11,
            capsize=4,zorder=6,
            label=f"Kurake MCF10A normal (Fig 6, $\\approx$ {MCF['S']*100:.0f}%)")
ax.annotate("",(MCF['C'],100.0),xytext=(MCF['C'],MCF['S']*100),
            arrowprops=dict(arrowstyle="->",color='b',lw=1.2),zorder=6)
ax.annotate("normal cell spared\nat glioblastoma-lethal dose",(MCF['C'],MCF['S']*100),
            xytext=(96,62),fontsize=8,color='b',
            arrowprops=dict(arrowstyle="->",color='b'))
ax.axhline(50,ls=':',c='grey'); ax.set_xlabel("C$_{out}$ H$_2$O$_2$ ($\\mu$M)")
ax.set_ylabel("survival (%)"); ax.set_ylim(-3,108); ax.set_xlim(-4,204)
ax.set_title("Dose-survival (3 h) with normal-cell anchor")
# legend placed outside the axes, so that nothing is drawn over the curves
ax.legend(fontsize=8,loc="upper center",bbox_to_anchor=(0.5,-0.13),
          ncol=2,frameon=False,handletextpad=0.5,columnspacing=1.4)
fig.tight_layout(); fig.savefig("figS8_normal_anchor.png",dpi=200,bbox_inches="tight")
print("\nSaved figS8_normal_anchor.png")
