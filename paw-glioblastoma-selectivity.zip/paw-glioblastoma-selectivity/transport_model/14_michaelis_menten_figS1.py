#!/usr/bin/env python3
# ======================================================================
# 14_michaelis_menten_figS1.py   ->  Fig. S1
#
# Sensitivity of the model to replacing first-order clearance with saturable
# (Michaelis-Menten) kinetics. The conclusion depends on how Vmax is chosen as
# Km is swept, so both self-consistent conventions are evaluated and shown.
#
# First-order clearance in the main model:      v = k_clear * C_in
# Saturable (Michaelis-Menten) replacement:     v = Vmax * C_in / (Km + C_in)
#
# Two self-consistent ways to choose Vmax as Km is swept:
#
#   (A) SLOPE-MATCHED   Vmax = k_clear * Km
#       The low-concentration (first-order) clearance rate constant is HELD
#       FIXED at k_clear, because v -> (Vmax/Km)*C_in = k_clear*C_in as
#       C_in << Km. The two cell types keep their 50 / 5 s^-1 asymmetry at
#       low concentration, and MM -> first-order as Km -> infinity. This is
#       the convention used in the manuscript ("removal remains strictly in
#       its linear regime") and is stated in the caption.
#
#   (B) VMAX-FIXED      Vmax = k_clear * Km_ref,  Km_ref = 100 uM
#       The maximal turnover is held fixed and only the affinity varies, so
#       the low-concentration rate constant Vmax/Km CHANGES with Km. Under
#       this convention selectivity collapses at large Km, because clearance
#       capacity itself has been removed from both cells - the sweep no longer
#       isolates saturation.
#
# (A) and (B) answer different questions. The robustness statement in the
# manuscript refers to (A).
# Deps: numpy, scipy, matplotlib
# ======================================================================
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import brentq
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as m

OUT = (sys.argv[1].rstrip("/") if len(sys.argv) > 1 else ".")

# ---- Table 1 parameters ----
AV, Plip, Ch, Cout = 4000.0, 5e-4, 40e-6, 100e-6
PA = {"astro": 1.0 * Plip, "u87": 4.0 * Plip}
K = {"astro": 50.0, "u87": 5.0}
D50, h, _ = m.calibrate()          # Hill survival, Kurake-calibrated (see 07)
T3 = 180 * 60.0
KM_REF = 100e-6

gate = lambda C: 1.0 / (1.0 + (C / Ch) ** m.N_GATE)
hill = lambda D: 1.0 / (1.0 + (D / D50) ** h)


def css_first_order(cell):
    f = lambda C: (PA[cell] * gate(C) + Plip) * AV * (Cout - C) - K[cell] * C
    return brentq(f, 0, Cout)


def css_mm(cell, Km, conv):
    Vmax = K[cell] * Km if conv == "A" else K[cell] * KM_REF
    f = lambda C: (PA[cell] * gate(C) + Plip) * AV * (Cout - C) - Vmax * C / (Km + C)
    return brentq(f, 0, Cout)


surv = lambda C: hill(C * 1e6 * T3)

Kms = np.logspace(-7, -1, 220)          # 0.1 uM .. 100 mM
res = {}
for conv in ("A", "B"):
    Ca = np.array([css_mm("astro", km, conv) for km in Kms])
    Cu = np.array([css_mm("u87", km, conv) for km in Kms])
    res[conv] = (Ca, Cu, surv(Ca), surv(Cu), surv(Ca) / np.clip(surv(Cu), 1e-12, None))

Ca0, Cu0 = css_first_order("astro"), css_first_order("u87")
S0 = surv(Ca0) / surv(Cu0)
print(f"first-order reference: C_in astro {Ca0*1e6:.2f} uM  U87 {Cu0*1e6:.2f} uM  "
      f"astro surv {surv(Ca0)*100:.1f}%  U87 surv {surv(Cu0)*100:.1f}%  selectivity {S0:.1f}x")
print(f"\n{'Km (uM)':>10}  |  {'(A) slope-matched':^34}  |  {'(B) Vmax-fixed':^34}")
print(f"{'':>10}  |  {'C_in a':>7}{'C_in u':>8}{'astro%':>8}{'U87%':>7}{'sel':>9}  |"
      f"  {'C_in a':>7}{'C_in u':>8}{'astro%':>8}{'U87%':>7}{'sel':>9}")
for km in (1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1):
    i = np.argmin(abs(Kms - km)); row = f"{Kms[i]*1e6:10.2f}  |"
    for conv in ("A", "B"):
        Ca, Cu, Sa, Su, Sl = res[conv]
        row += f"  {Ca[i]*1e6:7.2f}{Cu[i]*1e6:8.2f}{Sa[i]*100:8.1f}{Su[i]*100:7.1f}{Sl[i]:9.1f}  |"
    print(row)

# catalase / GPx reference Km values (orders of magnitude, for the shaded guide)
ENZ = [(1.1e-1, "catalase\n(tens-hundreds mM)"), (2e-5, "GPx1\n(~20 µM)")]

fig, ax = plt.subplots(1, 2, figsize=(11.6, 4.4))
titles = ["(A) slope-matched:  $V_{max}=k_{clear}K_m$\n(low-concentration rate constant held fixed)",
          "(B) $V_{max}$ fixed at $K_m^{ref}$ = 100 µM\n(low-concentration rate constant varies with $K_m$)"]
for a, conv, ttl in zip(ax, ("A", "B"), titles):
    Ca, Cu, Sa, Su, Sl = res[conv]
    a.semilogx(Kms * 1e6, Sa * 100, "tab:blue", lw=2, label="astrocyte survival")
    a.semilogx(Kms * 1e6, Su * 100, "tab:red", lw=2, label="U87-MG survival")
    a.axhline(surv(Ca0) * 100, color="tab:blue", ls=":", lw=1)
    a.axhline(surv(Cu0) * 100, color="tab:red", ls=":", lw=1)
    a.axvspan(10, Kms.max() * 1e6, color="green", alpha=.08)
    for km, lab in ENZ:
        a.axvline(km * 1e6, color="dimgrey", ls="--", lw=.9)
        a.text(km * 1e6 * 1.25, 52, lab, fontsize=7.2, color="dimgrey", rotation=90, va="center")
    a.set(xlabel=r"clearance-enzyme $K_m$ (µM)", ylabel="survival at 100 µM / 3 h (%)",
          title=ttl, ylim=(-3, 105))
    a.legend(fontsize=8, loc="center left")
    a2 = a.twinx()
    a2.semilogx(Kms * 1e6, Sl, color="k", lw=1.2, alpha=.65)
    a2.set_yscale("log"); a2.set_ylabel("kill selectivity (astro/U87)", fontsize=9)
    a2.axhline(S0, color="k", ls=":", lw=.9)
fig.suptitle("Fig. S1 — saturable clearance: the robustness claim depends on how $V_{max}$ is chosen",
             fontsize=11)
fig.tight_layout(rect=(0, 0, 1, .94))
fig.savefig(f"{OUT}/figS1_michaelis_menten.png", dpi=200)
print(f"\nSaved {OUT}/figS1_michaelis_menten.png")

# --- where does the manuscript's ">10 uM" statement hold? ---
for conv in ("A", "B"):
    Ca, Cu, Sa, Su, Sl = res[conv]
    ok = (Sa > .90) & (Sl > 5)
    rng = f"[{Kms[ok].min()*1e6:.2g}, {Kms[ok].max()*1e6:.3g}] uM" if ok.any() else "nowhere"
    print(f"convention ({conv}): astrocyte>90% AND selectivity>5x holds for Km in {rng}")
