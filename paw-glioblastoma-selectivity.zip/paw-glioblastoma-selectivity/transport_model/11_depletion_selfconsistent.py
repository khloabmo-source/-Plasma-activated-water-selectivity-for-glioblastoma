#!/usr/bin/env python3
# ======================================================================
# 11_depletion_selfconsistent.py   [LEGACY / exploratory - not a manuscript figure]
# Self-consistent extracellular-depletion model. The medium is a finite
# pool: cells consume H2O2 so C_out(t) declines. The cumulative
# intracellular dose is D = int C_in dt with a DECAYING C_out.
#
#   dC_out/dt = -phi*(A/V)*P_eff*(C_out - C_in)        (medium depletion)
#   dC_in /dt =      (A/V)*P_eff*(C_out - C_in) - k*C_in
#   P_eff = P_lip + P_AQP8*g(C_in)  ;  phi = cellular volume fraction
#
# WHAT THIS SCRIPT DOES AND DOES NOT SHOW (corrected for the revision):
#   * Under depletion the cumulative dose tends to C_out(0)/(phi*k_clear), so
#     the membrane terms cancel and the dose ratio between the two cells is the
#     clearance ratio itself (10.0, against 7.57 at constant C_out).
#   * With the survival law HELD at its constant-C_out calibration, depletion
#     lowers the absolute doses ~3-fold and U87 survival rises to ~90%
#     (selectivity ~1.1x).
#   * Re-calibrating the Hill law to Kurake with the SAME depletion model
#     restores ~3.8% survival and ~26x selectivity. That only shows that a
#     re-fitted law absorbs the dose-scale change. It does NOT demonstrate
#     invariance of selectivity to bath consumption; the claim was withdrawn
#     (Response to Reviewers, R1-8; Section 4.8).
#   * phi = 1.0e-4 is an ASSUMED value (C_out falls to 10% in ~2.2 h in the
#     U87 system; half-life 0.70 h). It is not tied to a literature timescale.
# The manuscript Fig. S10 is produced by 18_depletion_fixed_law.py.
# Deps: numpy, scipy, matplotlib
# ======================================================================
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit

AoverV=4000.0; P_lip=5e-4; C_half=40e-6; n_gate=1.0
P_AQP8={"astro":1.0*P_lip,"u87":4.0*P_lip}; K={"astro":50.0,"u87":5.0}
g=lambda C:1.0/(1.0+(C/C_half)**n_gate)
TMAX=8*3600.0   # integrate until medium depletes

def run(cell,Cout0_uM,phi):
    P8=P_AQP8[cell]; k=K[cell]; Co0=Cout0_uM*1e-6
    def rhs(t,y):
        Cout,Cin,_=y; Peff=(P_lip+P8*g(Cin))*AoverV; J=Peff*(Cout-Cin)
        return [-phi*J, J-k*Cin, Cin*1e6]      # 3rd state accumulates dose (uM*s)
    s=solve_ivp(rhs,(0,TMAX),[Co0,0,0],method="LSODA",rtol=1e-9,atol=1e-16,dense_output=True)
    return s
def dose(cell,Cout0_uM,phi): return run(cell,Cout0_uM,phi).y[2,-1]
hill=lambda D,D50,h:1.0/(1.0+(D/D50)**h)

# ---- assumed reference volume fraction (same value as 18_depletion_fixed_law.py) ----
PHI_REF = 1.0e-4
def depletion_time(phi,frac,cell="u87",Cout0=100.):   # time for C_out to fall to `frac` of initial
    s=run(cell,Cout0,phi); ts=np.linspace(0,TMAX,4000); Co=s.sol(ts)[0]
    below=np.where(Co< frac*Cout0*1e-6)[0]
    return ts[below[0]]/3600.0 if len(below) else np.inf
phi_ref=PHI_REF
print(f"assumed phi = {phi_ref:.1e}: U87 C_out half-life {depletion_time(phi_ref,0.5):.2f} h, "
      f"10% at {depletion_time(phi_ref,0.10):.2f} h (assumption, not a literature value)\n")

import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as _m

# ---- (1) survival law HELD FIXED at its constant-C_out calibration ----
_D50c, _hc, _ = _m.calibrate()
_Sac = _m.hill(_m.dose(_m.P_AQP8["astro"], _m.K_CLEAR["astro"]), _D50c, _hc)
_Suc = _m.hill(_m.dose(_m.P_AQP8["u87"], _m.K_CLEAR["u87"]), _D50c, _hc)
Da, Du = dose("astro",100.,phi_ref), dose("u87",100.,phi_ref)
Saf, Suf = hill(Da,_D50c,_hc), hill(Du,_D50c,_hc)
print(f"constant-C_out / 3h fit: D50={_D50c:.3e}, h={_hc:.2f}")
print(f"--- depletion, C_out(0)=100 uM ---")
print(f"  doses: astro {Da:.3e}  U87 {Du:.3e} uM*s  ratio {Du/Da:.2f} "
      f"(= clearance ratio {K['astro']/K['u87']:.1f}; analytic C0/(phi*k): astro {100/(phi_ref*K['astro']):.3e}, "
      f"U87 {100/(phi_ref*K['u87']):.3e})")
print(f"  survival law FIXED (constant-C_out calibration): astro {Saf*100:5.1f}%  U87 {Suf*100:5.1f}%  "
      f"selectivity {Saf/max(Suf,1e-9):4.2f}x")
print(f"  (constant C_out, 3 h:                            astro {_Sac*100:5.1f}%  U87 {_Suc*100:5.1f}%  "
      f"selectivity {_Sac/_Suc:4.1f}x)\n")

# ---- (2) survival law RE-CALIBRATED to Kurake with the depletion dose model ----
kur=_m.KURAKE            # single source: killcurve.csv via _model.py
Dk=np.array([dose("u87",c,phi_ref) for c,_ in kur]); Sk=np.array([s for _,s in kur])
(D50,h),_=curve_fit(hill,Dk,Sk,p0=[Dk[1],5.],bounds=([1,0.5],[1e8,20]),maxfev=20000)
R2=1-np.sum((Sk-hill(Dk,D50,h))**2)/np.sum((Sk-Sk.mean())**2)
print(f"re-calibrated Hill fit (depletion): D50={D50:.3e} uM*s  h={h:.2f}  R^2={R2:.3f}")
Sa=hill(Da,D50,h); Su=hill(Du,D50,h)
print(f"  survival law RE-CALIBRATED: astro {Sa*100:5.1f}%  U87 {Su*100:5.1f}%  selectivity {Sa/max(Su,1e-9):4.1f}x")
print("  -> a re-fitted law absorbs the dose-scale change; this is NOT evidence of invariance.\n")

# ---- (3) scan of depletion strength, each case re-calibrated (descriptive only) ----
print("--- depletion strength scan (each case re-calibrated; descriptive only) ---")
sels=[_Sac/_Suc, Saf/max(Suf,1e-9), Sa/max(Su,1e-9)]; us=[_Suc*100, Suf*100, Su*100]
scan=[]
for fac,lab in [(0.3,"slow (0.3x)"),(3.0,"fast (3x)")]:
    p=phi_ref*fac
    Dk2=np.array([dose("u87",c,p) for c,_ in kur])
    (d2,h2),_=curve_fit(hill,Dk2,Sk,p0=[Dk2[1],5.],bounds=([1,0.5],[1e8,20]),maxfev=20000)
    sa=hill(dose("astro",100.,p),d2,h2); su=hill(dose("u87",100.,p),d2,h2)
    scan.append((lab,sa/max(su,1e-9),su*100))
    print(f"  {lab:12s} phi={p:.1e}: astro {sa*100:5.1f}% U87 {su*100:5.1f}% sel {sa/max(su,1e-9):5.1f}x  (D50={d2:.2e},h={h2:.1f})")
sels += [scan[0][1], scan[1][1]]; us += [scan[0][2], scan[1][2]]

np.savez("depletion_traj.npz",phi=phi_ref,D50=D50,h=h)

# ---- figure (self-contained) ----
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tt=np.linspace(0,6*3600,500); th=tt/3600.0
fig,ax=plt.subplots(1,2,figsize=(11.5,4.3))
for cell,col in [("astro","tab:blue"),("u87","tab:red")]:
    s=run(cell,100.,phi_ref); Cout,Cin=s.sol(tt)[0]*1e6,s.sol(tt)[1]*1e6
    ax[0].plot(th,Cout,col,lw=2,ls='-',label=f"{cell} C_out")
    ax[0].plot(th,Cin,col,lw=2,ls='--',label=f"{cell} C_in")
ax[0].set_xlabel("time (h)"); ax[0].set_ylabel("H$_2$O$_2$ (µM)")
ax[0].set_title(f"Self-consistent depletion (C_out(0)=100 µM, assumed φ={phi_ref:.0e})"); ax[0].legend(fontsize=7.5)
ax[0].annotate("U87: C_in rises\n(clearance collapsed)",(1.3,42),fontsize=7.5,color='tab:red')
ax[0].annotate("astro: C_in stays low\n(high clearance)",(2.0,12),fontsize=7.5,color='tab:blue')
labels=["constant\nC_out (3h)","depletion,\nlaw FIXED","depletion,\nre-fit (ref.)","re-fit,\nslow","re-fit,\nfast"]
x=np.arange(len(labels)); cols=['grey','tab:orange','tab:red','tab:red','tab:red']
ax[1].bar(x,sels,color=cols,alpha=0.8)
for xi,s,u in zip(x,sels,us): ax[1].text(xi,s+0.8,f"{s:.1f}×\nU87 {u:.1f}%",ha='center',fontsize=8)
ax[1].set_xticks(x); ax[1].set_xticklabels(labels,fontsize=8); ax[1].set_ylabel("kill selectivity (astro/U87)")
ax[1].set_ylim(0,35); ax[1].set_title("Re-calibration absorbs the dose-scale change;\nthe fixed law does not (not evidence of invariance)",fontsize=10)
fig.tight_layout(); fig.savefig("fig11_depletion.png",dpi=200); print("Saved fig11_depletion.png")
