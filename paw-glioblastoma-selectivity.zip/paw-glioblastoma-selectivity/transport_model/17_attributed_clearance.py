#!/usr/bin/env python3
"""Section 3.5 - the required clearance asymmetry is ATTRIBUTED, not absolute.

The Kurake kill curve was measured on cells exposed to H2O2 alone, without plasma.
The clearance rate assigned to those cells when converting concentration to dose
changes the fitted (D50, h) and therefore changes what clearance ratio the model
says is required. Both attributions fit the five calibration points equally well.
"""
import os, sys
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as m

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures")
os.makedirs(OUT, exist_ok=True)
ratios = np.logspace(0, np.log10(30), 120)
CASES = [(m.K_CLEAR["u87"], "collapsed  ($k_{cal}$ = 5 s$^{-1}$)", "tab:red"),
         (m.K_CLEAR["astro"]/1.8, "basal  ($k_{cal}$ = 27.8 s$^{-1}$)", "tab:green")]

fig, ax = plt.subplots(figsize=(6.6, 4.3))
for kcal, lab, col in CASES:
    D50, h, r2 = m.calibrate(k_calibration=kcal)
    sv = np.array([m.hill(m.dose(m.P_AQP8["u87"], m.K_CLEAR["astro"]/r), D50, h) for r in ratios])
    need = ratios[np.argmax(sv < .10)] if (sv < .10).any() else float("nan")
    print(f"calibration at k={kcal:5.1f} s^-1: D50={D50:.3e} h={h:.2f} R2={r2:.3f}"
          f"  -> ratio required for >90% kill = {need:.2f}")
    ax.semilogx(ratios, sv*100, lw=2, color=col, label=f"calibration cells {lab}")
ax.axhline(10, color="k", ls=":", lw=1); ax.text(20, 12.5, "90% kill", fontsize=8.5, ha="right")
for x, lb in ((1.8, "Doskey mean 1.8×"), (10, "model baseline 10×")):
    ax.axvline(x, color="grey", ls="--", lw=1)
    ax.text(x*0.96, 46, lb, fontsize=8, color="dimgrey", rotation=90, ha="right", va="center")
ax.set(xlabel=r"clearance ratio $k_{astro}/k_{U87}$", ylabel="U87-MG survival (%)",
       title="The required clearance asymmetry is attributed,\nnot absolute (100 µM, 3 h)", ylim=(-2, 102))
ax.legend(fontsize=8.5); ax.grid(alpha=.25, which="both")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figS12_attributed_clearance.png"), dpi=200)
print(f"Saved {OUT}/figS12_attributed_clearance.png")
