#!/usr/bin/env python3
# ======================================================================
# 03_dose_survival_window.py   [LEGACY single-hit comparator; not a manuscript figure]
# Paper A — cumulative intracellular dose D=int C_in dt -> single-hit
# survival -> therapeutic window. D_lethal is the single free parameter.
#
# NOTE: the single-hit law exp(-D/D_lethal) is statistically REJECTED
# (13_model_comparison.py: single-hit dAICc = +15.1 against Hill, +14.8 against Weibull).
# The MANUSCRIPT Fig. 7 / Fig. 8 are produced by 03b_dose_survival_window_hill.py
# (cooperative Hill survival, 3 h, calibrated to Kurake 2016). This script is kept only
# to render the single-hit comparator; its outputs are suffixed *_singlehit.png so they
# do NOT overwrite the canonical Hill figures. D_lethal below is an ILLUSTRATIVE value
# (1e4 uM*s), not a calibrated one, and the 20 min horizon is illustrative too.
# Not run by default: use  RUN_LEGACY=1 bash run_all.sh  (outputs go to figures/legacy/).
# Produces:  fig7_dose_survival_singlehit.png, fig8_therapeutic_window_singlehit.png
# Deps:  numpy, scipy, matplotlib
# Run:   python3 03_dose_survival_window.py
# ======================================================================
import numpy as np
import matplotlib; matplotlib.use("Agg")
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
import matplotlib.pyplot as plt

# operating-point parameters (Table 1 baseline; same values as _model.py)
AoverV=4000.0; C_out0=100e-6; P_lip=5e-4
PA_astro=1.0*P_lip; PA_u87=4.0*P_lip
k_astro=50.0; k_u87=5.0; C_half=40e-6; n_gate=1.0
k_in=lambda P,g:(P*g+P_lip)*AoverV
g_gate=lambda C:1.0/(1.0+(C/C_half)**n_gate)

# dose-response (single-hit Poisson); D in µM·s. D_lethal = dose for 63% kill — ILLUSTRATIVE, not calibrated here.
D_lethal=1.0e4
surv=lambda D: np.exp(-D/D_lethal)

# --- dynamic run tracking cumulative dose ---
def run(P,kcl,T,C_out=C_out0,gate=True):
    def rhs(t,y):
        Cin,_=y; g=g_gate(Cin) if gate else 1.0
        return [k_in(P,g)*(C_out-Cin)-kcl*Cin, Cin*1e6]      # dD/dt=Cin(µM) -> D in µM·s
    s=solve_ivp(rhs,(0,T),[0,0],t_eval=np.linspace(0,T,500),method='LSODA',rtol=1e-9,atol=1e-14)
    return s.t/60, s.y[0]*1e6, s.y[1]
T=20*60.0
ta,Cina,Da=run(PA_astro,k_astro,T); tu,Cinu,Du=run(PA_u87,k_u87,T)

# --- single-hit comparator for Fig 7: cumulative dose + survival vs treatment time ---
fig,(a1,a2)=plt.subplots(1,2,figsize=(11,4))
a1.plot(ta,Da,'tab:blue',lw=2,label="astrocyte"); a1.plot(tu,Du,'tab:red',lw=2,label="U87 + PAW")
a1.axhline(D_lethal,color='k',ls=':'); a1.text(0.3,D_lethal*1.04,r"$D_{lethal}$ (illustrative)",fontsize=9)
a1.set(xlabel="treatment time (min)",ylabel=r"cumulative dose $D=\int C_{in}dt$ (µM·s)",title="Accumulated intracellular dose")
a1.legend(fontsize=9)
a2.plot(ta,surv(Da)*100,'tab:blue',lw=2,label="astrocyte"); a2.plot(tu,surv(Du)*100,'tab:red',lw=2,label="U87 + PAW")
a2.set(xlabel="treatment time (min)",ylabel="survival (%)",title="Viability (single-hit; rejected law)",ylim=(0,105)); a2.legend(fontsize=9)
fig.tight_layout(); fig.savefig("fig7_dose_survival_singlehit.png",dpi=200)

# --- single-hit comparator for Fig 8: window over (PAW dose, treatment time) ---
def Dend(P,kcl,C_out,Tmin):                                  # C_in→ss in <1s ⟹ D≈C_in,ss·T
    Css=brentq(lambda C:k_in(P,g_gate(C))*(C_out-C)-kcl*C,0,C_out)
    return Css*1e6*(Tmin*60)
Couts=np.linspace(20e-6,300e-6,70); Ts=np.linspace(0.5,20,70)
gap=np.array([[surv(Dend(PA_astro,k_astro,Co,Tm))-surv(Dend(PA_u87,k_u87,Co,Tm)) for Co in Couts] for Tm in Ts])
f2,ax=plt.subplots(figsize=(6.4,4.6))
cs=ax.contourf(Couts*1e6,Ts,gap,levels=np.linspace(0,1,11),cmap='RdYlGn')
f2.colorbar(cs,label="therapeutic gap (astro − U87 survival)")
ax.contour(Couts*1e6,Ts,gap,levels=[0.5],colors='k',linewidths=1.5)
ax.set(xlabel=r"PAW dose $C_{out}$ (µM)",ylabel="treatment time (min)",title="Single-hit comparator window (rejected law)")
f2.tight_layout(); f2.savefig("fig8_therapeutic_window_singlehit.png",dpi=200)

print(f"Dose selectivity D_U87/D_astro = {Du[-1]/Da[-1]:.1f}x  (= C_in,ss ratio)")
print(f"e.g. 5 min @100µM: survival astro={surv(Dend(PA_astro,k_astro,100e-6,5))*100:.0f}%  U87={surv(Dend(PA_u87,k_u87,100e-6,5))*100:.0f}%")
print("Saved: fig7_dose_survival_singlehit.png, fig8_therapeutic_window_singlehit.png")
