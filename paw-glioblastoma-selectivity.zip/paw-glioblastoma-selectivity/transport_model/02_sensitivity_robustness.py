#!/usr/bin/env python3
# ======================================================================
# 02_sensitivity_robustness.py
# Paper A — Global variance-based sensitivity (Sobol) + Monte-Carlo
# robustness of the dose selectivity, with P_AQP8 DECOUPLED from P_lip
# (the design used in the manuscript, Sec. 2.6). Saltelli sampling via
# scipy.stats.qmc.Sobol; S1 (Saltelli 2010) + ST (Jansen 1999); no SALib.
# Produces:  Fig 4 (Sobol tornado), Fig 5 (robustness histogram),
#            Fig 6 (robustness map). Prints S_T ranking and P(S>thr).
# Deps:  numpy, scipy, matplotlib
# Run:   python3 02_sensitivity_robustness.py
# ======================================================================
import numpy as np
from scipy.stats import qmc
from scipy.optimize import brentq
import matplotlib.pyplot as plt

AoverV=4000.0    # cm^-1 (fixed; geometry measurable)

# ---- model: P_AQP8 independent of P_lip (decoupled) ----
def model(p):
    rho_ratio,k_ratio,PA_astro,P_lip,k_astro,C_half,n,C_out=p
    PA_a=PA_astro; PA_u=rho_ratio*PA_astro; k_u=k_astro/k_ratio
    kin=lambda P,g:(P*g+P_lip)*AoverV
    gg =lambda C:1.0/(1.0+(C/C_half)**n)
    ss =lambda P,kcl:brentq(lambda C:kin(P,gg(C))*(C_out-C)-kcl*C,0.0,C_out)
    Cin_a,Cin_u=ss(PA_a,k_astro),ss(PA_u,k_u)
    Phi_a=(PA_a+P_lip)*AoverV/k_astro; Phi_u=(PA_u+P_lip)*AoverV/k_u
    return Cin_u/max(Cin_a,1e-15), bool(Phi_a<1.0<Phi_u)

names=['ρ ratio','k ratio','P_AQP8,astro','P_lip','k_astro','C_half','n','C_out']
bounds=np.array([[1,15],[1,30],[1e-4,2e-3],[1e-4,1e-3],[20.,100.],[20e-6,80e-6],[1.,4.],[50e-6,300e-6]])
D=len(names); lo,hi=bounds.T
scale=lambda U: lo+(hi-lo)*U
evalY=lambda M: np.array([model(r)[0] for r in M])

# ===== A. hand-rolled Saltelli + Sobol =====
print("Sobol (decoupled, ~1-2 min)...")
m=11                                                  # 2^11 = 2048 base points
q=qmc.Sobol(d=2*D,scramble=True,seed=0).random_base2(m)
A,B=scale(q[:,:D]),scale(q[:,D:])
yA,yB=evalY(A),evalY(B); Var=yA.var(); n=len(A)
S1,ST=np.zeros(D),np.zeros(D); yABall=np.zeros((n,D))
for i in range(D):
    AB=A.copy(); AB[:,i]=B[:,i]; yABall[:,i]=evalY(AB)
    S1[i]=np.mean(yB*(yABall[:,i]-yA))/Var              # Saltelli 2010
    ST[i]=0.5*np.mean((yA-yABall[:,i])**2)/Var           # Jansen 1999
rng=np.random.default_rng(1)                           # bootstrap CI for ST (no re-eval)
STci=np.array([np.std([0.5*np.mean((yA[ix]-yABall[ix,i])**2)/Var
        for ix in (rng.integers(0,n,n) for _ in range(300))]) for i in range(D)])

o=np.argsort(ST); yp=np.arange(D)
f1,ax=plt.subplots(figsize=(6.2,4))
ax.barh(yp,ST[o],xerr=STci[o],color='tab:purple',alpha=.85,label=r'total $S_T$')
ax.barh(yp,np.clip(S1,0,None)[o],color='tab:orange',alpha=.9,height=.5,label=r'first $S_1$')
ax.set_yticks(yp); ax.set_yticklabels([names[i] for i in o])
ax.set_xlabel(r'variance share of $S_{dose}$'); ax.set_title('What drives selectivity? (Sobol, decoupled)')
ax.legend(loc='lower right'); f1.tight_layout(); f1.savefig('fig4_tornado_decoupled.png',dpi=200)
print("\n S_T (dominant first):")
for i in o[::-1]: print(f"  {names[i]:12s} S_T={ST[i]:.3f}  S_1={max(S1[i],0):.3f}")

# ===== B. Monte-Carlo robustness =====
Xr=rng.uniform(lo,hi,size=(20000,D)); Sd=np.empty(20000); sw=np.empty(20000,bool)
for i,x in enumerate(Xr): Sd[i],sw[i]=model(x)
f2,ax=plt.subplots(figsize=(6.2,4))
ax.hist(np.log10(Sd),bins=60,color='tab:blue',alpha=.8)
for thr,c in [(1,'grey'),(2,'tab:green'),(5,'tab:red')]: ax.axvline(np.log10(thr),color=c,ls='--')
ax.set_xlabel(r'$\log_{10}S_{dose}$'); ax.set_ylabel('count'); ax.set_title('Robustness across parameter uncertainty')
f2.tight_layout(); f2.savefig('fig5_robustness_hist_decoupled.png',dpi=200)
print("\n Robustness:")
for thr in [1,2,5]: print(f"  P(S_dose>{thr}) = {(Sd>thr).mean():.2f}")
print(f"  P(regime separation) = {sw.mean():.2f}   median S_dose={np.median(Sd):.1f} "
      f"IQR=[{np.percentile(Sd,25):.1f},{np.percentile(Sd,75):.1f}]")

# ===== C. robustness map over the two load-bearing ratios =====
nr=18; rr=np.linspace(1,15,nr); kr=np.linspace(1,30,nr); Mn=120; nlo,nhi=lo[2:],hi[2:]
Pm=np.zeros((nr,nr))
for i,kk in enumerate(kr):
    for j,rrho in enumerate(rr):
        nz=rng.uniform(nlo,nhi,size=(Mn,6))
        Pm[i,j]=(np.array([model([rrho,kk,*z])[0] for z in nz])>2).mean()
f3,ax=plt.subplots(figsize=(6.2,4.6))
cs=ax.contourf(rr,kr,Pm,levels=np.linspace(0,1,11),cmap='viridis')
f3.colorbar(cs,label=r'P($S_{dose}>2$ | other params)')
ax.plot(4,10,'o',ms=11,color='red',mec='white',zorder=5)
ax.annotate('operating point',(4,10),textcoords='offset points',xytext=(8,6),color='white',fontweight='bold',fontsize=9)
ax.set_xlabel(r'$\rho_{U87}/\rho_{astro}$'); ax.set_ylabel(r'$k_{astro}/k_{U87}$')
ax.set_title('Where selectivity is robust to all other uncertainties')
f3.tight_layout(); f3.savefig('fig6_robustness_map_decoupled.png',dpi=200)
print("\nSaved: fig4_tornado_decoupled.png, fig5_robustness_hist_decoupled.png, fig6_robustness_map_decoupled.png")