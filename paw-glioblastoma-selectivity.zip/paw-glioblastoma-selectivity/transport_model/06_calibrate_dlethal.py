#!/usr/bin/env python3
# ======================================================================
# 06_calibrate_dlethal.py   
# Calibrate D_lethal (the single free survival parameter) to a PUBLISHED
# PAW/H2O2 kill curve. For each measured (C_out, exposure
# time, survival) point the model computes the cumulative intracellular
# dose D = int C_in dt (gated), then D_lethal is fitted by least squares to
#   survival = exp(-D / D_lethal).
# This turns Figs 7-8 from illustrative into literature-calibrated.
#
#   python3 06_calibrate_dlethal.py killcurve.csv
# CSV columns:  cell,C_out_uM,time_min,survival     (cell in {astro,u87})
# Deps: numpy, scipy
# ======================================================================
import sys, csv, numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit

AoverV=4000.0; P_lip=5e-4; C_half=40e-6; n_gate=1.0
PARAMS={"astro":dict(P_AQP8=1.0*P_lip, k=50.0),
        "u87":  dict(P_AQP8=4.0*P_lip, k=5.0)}
g_gate=lambda C:1.0/(1.0+(C/C_half)**n_gate)
def dose(cell, C_out_uM, time_min, gate=True):
    p=PARAMS[cell]; C_out=C_out_uM*1e-6; T=time_min*60.0
    def rhs(t,y):
        Cin=y[0]; g=g_gate(Cin) if gate else 1.0
        return [ (p["P_AQP8"]*g+P_lip)*AoverV*(C_out-Cin) - p["k"]*Cin , Cin*1e6 ]
    s=solve_ivp(rhs,(0,T),[0,0],method="LSODA",rtol=1e-9,atol=1e-14)
    return s.y[1,-1]    # cumulative dose D in uM*s

def load(path):
    rows=[]
    lines=[l for l in open(path) if l.strip() and not l.lstrip().startswith("#")]
    for r in csv.DictReader(lines):
        rows.append((r["cell"].strip().lower(), float(r["C_out_uM"]),
                     float(r["time_min"]), float(r["survival"])))
    return rows

def fit_dlethal(rows):
    D=np.array([dose(c,co,tm) for c,co,tm,_ in rows])
    S=np.array([s for *_,s in rows])
    model=lambda D,Dl: np.exp(-D/Dl)
    popt,pcov=curve_fit(model,D,S,p0=[1e4],bounds=(1,1e7),maxfev=10000)
    Dl=popt[0]; sd=float(np.sqrt(pcov[0,0]))
    ss_res=np.sum((S-model(D,Dl))**2); ss_tot=np.sum((S-S.mean())**2)
    R2=1-ss_res/ss_tot if ss_tot>0 else float("nan")
    return Dl, sd, R2, D, S

if __name__=="__main__":
    if len(sys.argv)>1:
        rows=load(sys.argv[1])
        Dl,sd,R2,D,S=fit_dlethal(rows)
        print(f"Calibrated D_lethal = {Dl:.3e} +/- {sd:.1e} uM*s   (R^2={R2:.3f}, n={len(rows)})")
        print(" dose D (uM*s) | survival_obs | survival_fit")
        for (c,co,tm,s),d in zip(rows,D):
            print(f"  {c:5s} {co:5.0f}uM {tm:4.1f}min  D={d:9.1f}  obs={s:.2f}  fit={np.exp(-d/Dl):.2f}")
    else:
        # ---- SELF-TEST: synthetic recovery (no data file) ----
        print("No CSV given -> self-test: generate survival from a known D_lethal and recover it.")
        true=1.0e4; rng=np.random.default_rng(0)
        grid=[("u87",co,tm) for co in (50,100,200) for tm in (1,2,5,10)]
        rows=[(c,co,tm, float(np.clip(np.exp(-dose(c,co,tm)/true)+rng.normal(0,0.02),0,1)))
              for c,co,tm in grid]
        Dl,sd,R2,_,_=fit_dlethal(rows)
        print(f"  true D_lethal = {true:.3e}")
        print(f"  fitted        = {Dl:.3e} +/- {sd:.1e}   (R^2={R2:.3f})  -> recovered within {abs(Dl-true)/true*100:.1f}%")
        print("\nReplace the self-test with: python3 06_calibrate_dlethal.py killcurve_template.csv")
