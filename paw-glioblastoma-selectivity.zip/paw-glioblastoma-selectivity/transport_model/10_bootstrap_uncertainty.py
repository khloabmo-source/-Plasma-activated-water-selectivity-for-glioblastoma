#!/usr/bin/env python3
# Grid extents: the dose interpolation runs to 700 uM and the window search to
# 600 uM. np.interp clamps beyond its grid rather than extrapolating, so the dose
# grid must exceed the window search or the astrocyte dose is frozen at the edge
# and the reported upper bound becomes the grid limit.
# ======================================================================
# 10_bootstrap_uncertainty.py  
# Parametric bootstrap on the 5 digitised Kurake points: each replicate
# perturbs every point on BOTH axes within its read error, refits the
# Hill survival, and recomputes downstream predictions. Reports median +
# 95% CI for D50, h, astro/U87 survival, kill selectivity, and window.
# (Transport C_in(C_out) is precomputed once and interpolated -> fast.)
# Deps: numpy, scipy
# ======================================================================
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit

rng=np.random.default_rng(20260619)
AoverV=4000.0; P_lip=5e-4; C_half=40e-6; n_gate=1.0
P_AQP8={"astro":1.0*P_lip,"u87":4.0*P_lip}; K={"astro":50.0,"u87":5.0}
WIN_s=3*3600.0
g=lambda C:1.0/(1.0+(C/C_half)**n_gate)
def _cin(cell,C_out_uM):
    rhs=lambda t,y:[(P_AQP8[cell]*g(y[0])+P_lip)*AoverV*(C_out_uM*1e-6-y[0])-K[cell]*y[0]]
    return solve_ivp(rhs,(0,5.0),[0],method="LSODA",rtol=1e-10,atol=1e-16).y[0,-1]*1e6
# precompute C_in on a grid, then interpolate (transport is independent of Hill params)
GC=np.linspace(0,700,1401)
CIN={c:np.array([_cin(c,x) for x in GC]) for c in ("astro","u87")}
cin=lambda cell,x:np.interp(x,GC,CIN[cell])
dose=lambda cell,x:cin(cell,x)*WIN_s            # uM*s
hill=lambda D,D50,h:1.0/(1.0+(D/D50)**h)

import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as _m
Cx=np.array([c for c,_ in _m.KURAKE]); Sy=np.array([s for _,s in _m.KURAKE])   # single source: killcurve.csv via _model.py
SIG_S=0.05; SIG_X=0.05
def fit(Cv,Sv):
    D=dose("u87",Cv)
    (d50,h),_=curve_fit(hill,D,np.clip(Sv,1e-4,1.2),p0=[3e5,5.],
                        bounds=([1,0.5],[1e8,20]),maxfev=20000)
    return d50,h
d50_0,h_0=fit(Cx,Sy)

Da=dose("astro",100.); Du=dose("u87",100.)
Cg=np.linspace(20,600,1161); Du_g=dose("u87",Cg); Da_g=dose("astro",Cg)
def metrics(d50,h):
    Sa=hill(Da,d50,h); Su=hill(Du,d50,h)
    ok=(hill(Du_g,d50,h)<0.2)&(hill(Da_g,d50,h)>0.8)
    lo,hi=(Cg[ok].min(),Cg[ok].max()) if ok.any() else (np.nan,np.nan)
    return Sa*100,Su*100,Sa/max(Su,1e-9),lo,hi

N=3000; rec=[]
for _ in range(N):
    Cv=Cx*(1+SIG_X*rng.standard_normal(5))
    Sv=np.clip(Sy+SIG_S*rng.standard_normal(5),1e-3,1.15)
    try: d50,h=fit(Cv,Sv); rec.append((d50,h,*metrics(d50,h)))
    except Exception: pass
rec=np.array(rec); print(f"converged: {len(rec)}/{N}\n")
ci=lambda x:(np.percentile(x[np.isfinite(x)],2.5),np.median(x[np.isfinite(x)]),np.percentile(x[np.isfinite(x)],97.5))
names=["D50 (uM*s)","h (cooperativity)","astro surv %","U87 surv %","kill selectivity x","window lo uM","window hi uM"]
pts=[d50_0,h_0,*metrics(d50_0,h_0)]
print(f"{'metric':24s}{'point':>11s}{'2.5%':>11s}{'median':>11s}{'97.5%':>11s}")
for i,nm in enumerate(names):
    lo,md,hi=ci(rec[:,i]); f=lambda v:f"{v:11.3g}"
    print(f"{nm:24s}{f(pts[i])}{f(lo)}{f(md)}{f(hi)}")

# ---- figure (self-contained) ----
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
Cg2=np.linspace(0,200,120); Du2=dose("u87",Cg2); Da2=dose("astro",Cg2)
SU=np.array([hill(Du2,r[0],r[1]) for r in rec])*100
SA=np.array([hill(Da2,r[0],r[1]) for r in rec])*100
fig,ax=plt.subplots(1,2,figsize=(11,4.3))
for arr,col,lab in [(SU,'red','U87-MG'),(SA,'blue','astrocyte')]:
    lo,md,hi=np.percentile(arr,[2.5,50,97.5],axis=0)
    ax[0].fill_between(Cg2,lo,hi,color=col,alpha=0.22); ax[0].plot(Cg2,md,color=col,lw=2,label=f"{lab} (median+95%)")
ax[0].scatter(Cx,Sy*100,c='k',zorder=5,label="Kurake U251SP"); ax[0].axhline(50,ls=':',c='grey')
ax[0].set_xlabel("C_out H2O2 (uM)"); ax[0].set_ylabel("survival (%)")
ax[0].set_title("Dose-survival 95% bootstrap band (3 h)"); ax[0].legend(fontsize=8)
ax[1].hist(rec[:,1],bins=45,color='teal',alpha=0.8); ax[1].axvline(h_0,color='k',lw=2,label=f"h={h_0:.1f}")
for q in (2.5,97.5): ax[1].axvline(np.percentile(rec[:,1],q),color='k',ls='--',lw=1)
ax[1].set_xlabel("Hill cooperativity h"); ax[1].set_ylabel("bootstrap count")
ax[1].set_title(f"h posterior: 95pct CI [{np.percentile(rec[:,1],2.5):.1f}, {np.percentile(rec[:,1],97.5):.1f}]"); ax[1].legend(fontsize=8)
np.savetxt("bootstrap_h_ci.txt", [np.percentile(rec[:,1],2.5), np.percentile(rec[:,1],97.5)], fmt="%.4f")   # read by 16
fig.tight_layout(); fig.savefig("figS9_bootstrap_uncertainty.png",dpi=200); print("Saved figS9_bootstrap_uncertainty.png")
