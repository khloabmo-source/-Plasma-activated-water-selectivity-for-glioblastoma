#!/usr/bin/env python3
# ======================================================================
# 13_model_comparison.py                 -> manuscript Fig. S7
# Compares three survival laws fitted to the Kurake kill curve:
#   single-hit  S = exp(-D/Dl)            (1 param)
#   Hill        S = 1/(1+(D/D50)^h)       (2 param)
#   Weibull     S = exp(-(D/Dc)^h)        (2 param)
# via R^2, RSS, AIC, AICc (small-n corrected, n=5), BIC. Shows the
# cooperative (2-param) laws are decisively preferred -> the Hill choice
# is data-driven, not arbitrary, despite the extra parameter.
#
# Parameters and calibration points come from _model.py (Table 1 baseline);
# the calibration points are loaded from killcurve.csv through _model.py.
# Output file renamed fig13_model_comparison.png -> figS7_model_selection.png
# (the old name collided with main-figure numbering).
# Deps: numpy, scipy, matplotlib
# ======================================================================
import os, sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import _model as _m

AoverV=_m.AV; P_lip=_m.P_LIP; C_half=_m.C_HALF; n_gate=_m.N_GATE
P_AQP8_u87=_m.P_AQP8["u87"]; k_u87=_m.K_CLEAR["u87"]; WIN_s=_m.T_EXPOSURE
g=lambda C:1.0/(1.0+(C/C_half)**n_gate)
def dose_u87(C_out_uM):
    rhs=lambda t,y:[(P_AQP8_u87*g(y[0])+P_lip)*AoverV*(C_out_uM*1e-6-y[0])-k_u87*y[0]]
    return solve_ivp(rhs,(0,5.0),[0],method="LSODA",rtol=1e-10,atol=1e-16).y[0,-1]*1e6*WIN_s

# calibration points: single source killcurve.csv, loaded by _model.py
kur=_m.KURAKE
D=np.array([dose_u87(c) for c,_ in kur]); S=np.array([s for _,s in kur]); n=len(S)

models={
 "single-hit": (lambda D,Dl:np.exp(-D/Dl), [2e5], ([1],[1e8]), 1),
 "Hill":       (lambda D,D50,h:1/(1+(D/D50)**h), [3e5,5.], ([1,.5],[1e8,20]), 2),
 "Weibull":    (lambda D,Dc,h:np.exp(-(D/Dc)**h), [3e5,3.], ([1,.5],[1e8,20]), 2),
}
print(f"{'model':12s}{'R^2':>8s}{'RSS':>10s}{'k':>3s}{'AIC':>9s}{'AICc':>9s}{'BIC':>9s}")
res={}
for nm,(f,p0,bnds,k) in models.items():
    par,_=curve_fit(f,D,S,p0=p0,bounds=bnds,maxfev=40000)
    rss=float(np.sum((S-f(D,*par))**2)); r2=1-rss/np.sum((S-S.mean())**2)
    aic=n*np.log(rss/n)+2*k
    aicc=aic+(2*k*(k+1))/(n-k-1) if n-k-1>0 else np.inf
    bic=n*np.log(rss/n)+k*np.log(n)
    res[nm]=dict(r2=r2,rss=rss,k=k,aic=aic,aicc=aicc,bic=bic,par=par)
    print(f"{nm:12s}{r2:8.3f}{rss:10.4f}{k:3d}{aic:9.2f}{aicc:9.2f}{bic:9.2f}")
best=min(res,key=lambda m:res[m]['aicc'])
print(f"\nbest by AICc: {best}")
print("dAICc (vs best):  "+"  ".join(f"{m} {res[m]['aicc']-res[best]['aicc']:+.1f}" for m in res))
print("dBIC  (vs best):  "+"  ".join(f"{m} {res[m]['bic']-res[min(res,key=lambda x:res[x]['bic'])]['bic']:+.1f}" for m in res))
print("\nInterpretation: dAICc>10 = decisive. The single-hit model is decisively")
print("rejected; the Hill and Weibull forms cannot be separated (dAICc ~ 0.2).")

import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(11,4.3))
Dg=np.linspace(0,D.max()*1.1,200)
ax[0].scatter([c for c,_ in kur],S*100,c='k',zorder=5,label="Kurake U251SP")
Cg=np.linspace(20,120,100); Dc=np.array([dose_u87(c) for c in Cg])
for nm,(f,_,_,_) in models.items():
    ax[0].plot(Cg,f(Dc,*res[nm]['par'])*100,lw=2,label=f"{nm} (R²={res[nm]['r2']:.2f})")
ax[0].set_xlabel("C_out H2O2 (µM)"); ax[0].set_ylabel("survival (%)")
ax[0].set_title("Fits to the Kurake kill curve"); ax[0].legend(fontsize=8)
ms=list(res); da=[res[m]['aicc']-res[best]['aicc'] for m in ms]
ax[1].bar(ms,da,color=['firebrick' if m=='single-hit' else 'seagreen' for m in ms])
ax[1].axhline(10,ls=':',c='grey'); ax[1].text(0,11,"ΔAICc=10 (decisive)",fontsize=8,color='grey')
ax[1].set_ylabel("ΔAICc vs best"); ax[1].set_title("Model selection (lower = better)")
for i,v in enumerate(da): ax[1].text(i,v+1,f"{v:+.1f}",ha='center',fontsize=9)
fig.tight_layout(); fig.savefig("figS7_model_selection.png",dpi=200)
print("\nSaved figS7_model_selection.png")
