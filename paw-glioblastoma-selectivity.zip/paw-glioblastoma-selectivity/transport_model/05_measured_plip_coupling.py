#!/usr/bin/env python3
# ======================================================================
# 05_measured_plip_coupling.py   
# Feed the MD-MEASURED lipid permeability P_lip of each membrane (from
# permeability/permeability_isd.py) into the transfer-function model, as a
# per-cell input with uncertainty, instead of one generic literature number.
#
#   Phi_cell = (P_AQP8_cell * g(C_in) + P_lip_cell)(A/V) / k_cell
#
# P_AQP8 stays the ABSOLUTE channel term; P_lip is now the measured, cell-
# specific lipid term. Monte-Carlo propagates the P_lip uncertainty into
# S_dose, survival and the regime separation.  numpy / scipy / matplotlib.
# ======================================================================
import numpy as np
from scipy.optimize import brentq
import matplotlib.pyplot as plt

# ---- fixed operating point (same as 01/03) ----
AoverV  = 4000.0          # cm^-1
C_out   = 100e-6          # M
k_astro, k_u87 = 50.0, 5.0
C_half, n_gate = 40e-6, 1.0
PA_astro, PA_u87 = 5e-4, 2.0e-3    # ABSOLUTE AQP8 channel permeability (cm/s): 1x and 4x of the nominal lipid scale

# ====================================================================
# Per-cell lipid permeability inputs (cm/s)
# Baseline values equal the experimental P_lip
# (5e-4) for BOTH cells, which must reproduce the baseline S_dose.
P_LIP_ASTRO = (5.0e-4, 0.0)        # (mean, sd)
P_LIP_U87   = (5.0e-4, 0.0)        # (mean, sd)
# Expectation from the membrane null + cholesterol direction:
#   P_lip(U87) <= P_lip(astro)  -> selectivity unchanged or slightly ENHANCED.
# ====================================================================

g_gate = lambda C: 1.0/(1.0+(C/C_half)**n_gate)
def Cin_ss(P_AQP8, P_lip, k):
    kin = lambda C: (P_AQP8*g_gate(C) + P_lip)*AoverV
    return brentq(lambda C: kin(C)*(C_out-C) - k*C, 0.0, C_out)
def selectivity(plip_a, plip_u):
    Ca = Cin_ss(PA_astro, plip_a, k_astro)
    Cu = Cin_ss(PA_u87,  plip_u, k_u87)
    return Cu/max(Ca,1e-15), Ca, Cu

# ---- point estimate ----
S0, Ca0, Cu0 = selectivity(P_LIP_ASTRO[0], P_LIP_U87[0])
print(f"point estimate (gated):  C_in astro={Ca0*1e6:5.1f}  U87={Cu0*1e6:5.1f} uM   S_dose={S0:.2f}")

# ---- Monte-Carlo propagation of P_lip uncertainty ----
rng = np.random.default_rng(0); N = 20000
pa = np.clip(rng.normal(*P_LIP_ASTRO, N), 1e-6, None)
pu = np.clip(rng.normal(*P_LIP_U87,   N), 1e-6, None)
S = np.array([selectivity(a, u)[0] for a, u in zip(pa, pu)])
if P_LIP_ASTRO[1] == 0 and P_LIP_U87[1] == 0:
    print("  (sd=0 -> deterministic; paste MD mean+sd to get bands)")
else:
    print(f"  S_dose: median {np.median(S):.2f}  IQR[{np.percentile(S,25):.2f},{np.percentile(S,75):.2f}]"
          f"  P(S>2)={np.mean(S>2):.2f}")

# ---- selectivity against the background lipid ceiling (Sec. 4.4) ----
plip_grid = np.logspace(-4, -2.3, 60)              # 1e-4 .. ~5e-3 cm/s
S_equal = [selectivity(p, p)[0] for p in plip_grid]   # if both membranes share P_lip
fig, ax = plt.subplots(figsize=(6.2, 4))
ax.semilogx(plip_grid, S_equal, 'k-', lw=2)
ax.axvline(5e-4, color='grey', ls=':'); ax.text(5e-4, max(S_equal)*0.9, ' nominal P_lip', fontsize=9, color='grey')
ax.plot(P_LIP_ASTRO[0], S0, 'o', color='tab:red', ms=10, mec='white', zorder=5)
ax.set_xlabel(r"lipid permeability $P_{lip}$ (cm/s)"); ax.set_ylabel(r"$S_{dose}$")
ax.set_title("Lipid permeability sets the selectivity ceiling")
fig.tight_layout(); fig.savefig("fig_plip_ceiling.png", dpi=200)
print("\nA larger non-selective lipid background floods BOTH cells and erases selectivity")
print("(the ceiling of Sec. 4.4). The MD-measured P_lip locates the operating point on this curve.")
print("Saved: fig_plip_ceiling.png")
