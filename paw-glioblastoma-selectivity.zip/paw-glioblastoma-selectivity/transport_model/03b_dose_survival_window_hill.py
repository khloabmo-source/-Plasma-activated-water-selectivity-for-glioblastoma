#!/usr/bin/env python3
# ======================================================================
# 03b_dose_survival_window_hill.py      -> manuscript Fig. 7 and Fig. 8
# Dose and survival versus time (Fig. 7) and the therapeutic window (Fig. 8),
# using the cooperative Hill survival law calibrated to the Kurake et al.
# (2016) U251SP H2O2 kill curve over the assumed 3 h effective exposure window.
#
# All parameters and the five calibration points are taken from _model.py
# (Table 1 baseline), so the model is defined in exactly one place.
# killcurve.csv is the deposited source of the calibration points and is loaded
# by _model.py (no second copy of the numbers lives in this script).
# The 3 h window edges drawn on Fig. 8 are COMPUTED here with the same
# criterion as 10_bootstrap_uncertainty.py (U87 survival < 20 % and astrocyte
# survival > 80 %), not typed in.
# Deps: numpy, scipy, matplotlib
# ======================================================================
import os, sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.optimize import brentq, curve_fit
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import _model as m

# --- operating point (Table 1 baseline, from _model.py) ---
AoverV, C_out0, P_lip = m.AV, m.C_OUT, m.P_LIP
PA_astro, PA_u87 = m.P_AQP8["astro"], m.P_AQP8["u87"]
k_astro, k_u87 = m.K_CLEAR["astro"], m.K_CLEAR["u87"]
C_half, n_gate = m.C_HALF, m.N_GATE
k_in=lambda P,g:(P*g+P_lip)*AoverV
g_gate=lambda C:1.0/(1.0+(C/C_half)**n_gate)
WIN_MIN=m.T_EXPOSURE/60.0   # 180 min = 3 h assumed effective window

# --- calibration points: single source killcurve.csv, loaded by _model.py ---
kur=m.KURAKE

def run(P,kcl,T_s,C_out=C_out0,gate=True):
    def rhs(t,y):
        Cin,_=y; g=g_gate(Cin) if gate else 1.0
        return [k_in(P,g)*(C_out-Cin)-kcl*Cin, Cin*1e6]
    s=solve_ivp(rhs,(0,T_s),[0,0],t_eval=np.linspace(0,T_s,600),
                method='LSODA',rtol=1e-9,atol=1e-14)
    return s.t/3600.0, s.y[0]*1e6, s.y[1]

def Dend(P,kcl,C_out,T_min,gate=True):     # Cin->ss in <1 s  =>  D ~ C_ss * T
    Css=brentq(lambda C:k_in(P,(g_gate(C) if gate else 1.0))*(C_out-C)-kcl*C,0,C_out)
    return Css*1e6*(T_min*60.0)

# --- calibrate Hill survival to Kurake 2016 (external conc -> internal dose -> fit) ---
def dose_full(P,kcl,C_out_uM,T_min,gate=True):
    C_out=C_out_uM*1e-6; Ts=T_min*60.0
    rhs=lambda t,y:[k_in(P,(g_gate(y[0]) if gate else 1.0))*(C_out-y[0])-kcl*y[0], y[0]*1e6]
    return solve_ivp(rhs,(0,Ts),[0,0],method="LSODA",rtol=1e-9,atol=1e-14).y[1,-1]
Dk=np.array([dose_full(PA_u87,k_u87,c,WIN_MIN) for c,_ in kur])
Sk=np.array([s for _,s in kur])
hill=lambda D,D50,h:1.0/(1.0+(D/D50)**h)
(D50,hh),_=curve_fit(hill,Dk,Sk,p0=[3.0e5,3.0],bounds=([1,0.5],[1e8,12]),maxfev=20000)
R2=1-np.sum((Sk-hill(Dk,D50,hh))**2)/np.sum((Sk-Sk.mean())**2)
surv=lambda D:hill(D,D50,hh)
print(f"Hill: D50={D50:.3e} uM*s  h={hh:.2f}  R2={R2:.3f}")

# --- trajectories over 3 h ---
T=WIN_MIN*60.0
ta,Cina,Da=run(PA_astro,k_astro,T)
tu,Cinu,Du=run(PA_u87,k_u87,T)
print(f"@100uM/3h  astro dose={Da[-1]:.2e}  U87 dose={Du[-1]:.2e}  uM*s")
print(f"@100uM/3h  astro surv={surv(Da[-1])*100:.1f}%  U87 surv={surv(Du[-1])*100:.1f}%  "
      f"selectivity={surv(Da[-1])/surv(Du[-1]):.1f}x")

# --- 3 h therapeutic-window edges (same criterion as script 10) ---
Cg=np.arange(20.0,600.0,0.5)
ok=np.array([(surv(Dend(PA_u87,k_u87,c*1e-6,WIN_MIN))<0.2) and (surv(Dend(PA_astro,k_astro,c*1e-6,WIN_MIN))>0.8) for c in Cg])
W_LO,W_HI=Cg[ok].min(),Cg[ok].max()
print(f"3 h window (U87 < 20 % and astrocyte > 80 % survival): {W_LO:.0f} - {W_HI:.0f} uM")

# ====================== FIG 7 : dose + survival vs time ======================
fig,(a1,a2)=plt.subplots(1,2,figsize=(11,4))
a1.plot(ta,Da,'tab:blue',lw=2,label="astrocyte")
a1.plot(tu,Du,'tab:red',lw=2,label="U87 + PAW")
a1.axhline(D50,color='k',ls=':'); a1.text(0.05,D50*1.04,r"$D_{50}$",fontsize=9)
a1.set(xlabel="treatment time (h)",
       ylabel=r"cumulative dose $D=\int C_{in}\,dt$ (µM·s)",
       title="Accumulated intracellular dose")
a1.legend(fontsize=9)
a2.plot(ta,surv(Da)*100,'tab:blue',lw=2,label="astrocyte")
a2.plot(tu,surv(Du)*100,'tab:red',lw=2,label="U87 + PAW")
a2.set(xlabel="treatment time (h)",ylabel="survival (%)",
       title="Viability (Hill-calibrated)",ylim=(0,105)); a2.legend(fontsize=9)
fig.tight_layout(); fig.savefig("fig7_dose_survival.png",dpi=200)

# ====================== FIG 8 : therapeutic window ===========================
Couts=np.linspace(20e-6,400e-6,90); Th=np.linspace(0.05,3.0,90)   # hours; extended to reveal the astrocyte-death upper bound
gap=np.array([[surv(Dend(PA_astro,k_astro,Co,Tm*60))-surv(Dend(PA_u87,k_u87,Co,Tm*60))
               for Co in Couts] for Tm in Th])
f2,ax=plt.subplots(figsize=(6.4,4.6))
cs=ax.contourf(Couts*1e6,Th,gap,levels=np.linspace(0,1,11),cmap='RdYlGn')
f2.colorbar(cs,label="therapeutic gap (astro − U87 survival)")
ax.contour(Couts*1e6,Th,gap,levels=[0.5],colors='k',linewidths=1.5)
for cx in (W_LO,W_HI): ax.plot([cx,cx],[2.96,3.0],'k-',lw=3)   # computed 3 h window edges
ax.set(xlabel=r"PAW dose $C_{out}$ (µM)",ylabel="treatment time (h)",
       title="Therapeutic window: kill U87, spare astrocytes")
f2.tight_layout(); f2.savefig("fig8_therapeutic_window.png",dpi=200)
print("Saved fig7_dose_survival.png, fig8_therapeutic_window.png")
