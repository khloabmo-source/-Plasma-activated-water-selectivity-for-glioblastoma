#!/usr/bin/env python3
# ======================================================================
# 01_transfer_function.py
# Paper A — WS2 steady-state transfer-function model of intracellular H2O2.
#   C_in,ss = C_out * Phi/(1+Phi),  Phi = (rho*p_f*g + P_lip)(A/V)/k_clear,
#   with Hill redox gating g(C)=1/(1+(C/C_half)^n) (Cys53 brake).
# Absolute parameters are literature-bracketed/illustrative; the load-bearing
# outputs are the ratios (rho, k) and the regime separation. Units: CGS (cm,s,M).
# Produces:  Fig 1 (regime separation), Fig 2 (selectivity map), Fig 3 (gated
#            dynamic time-course). Prints Phi, C_in,ss and S_dose.
# Deps:  numpy, scipy, matplotlib    Run: python3 01_transfer_function.py
# ======================================================================
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ===== 1. PARAMETERS (edit here) =====
r_cell  = 7.5e-4                 # cm (~7.5 µm)
AoverV  = 3.0/r_cell             # cm^-1 (sphere A/V=3/r ≈ 4000)
C_out   = 100e-6                 # M  extracellular H2O2 from PAW
P_lip   = 5e-4                   # cm/s  lipid route, non-selective (Orrico 2022)
fAQP_astro = 1.0                 # P_AQP8,astro = f * P_lip  (basal)
fAQP_u87   = 4.0                 # P_AQP8,U87  = f * P_lip  (over-expressed; Zhu2013/Hao2023)
k_astro = 50.0                   # s^-1  intact clearance (catalase+GPx+Prx)
k_u87   = 5.0                    # s^-1  PAW-collapsed catalase (Bauer trigger): 10x lower
C_half  = 40e-6                  # M  intracellular H2O2 half-closing AQP8 (Medraño-Fernández 2016)
n_gate=1.0

# ===== 2. DERIVED RATES & Phi =====
def k_in(P_AQP8, g=1.0): return (P_AQP8*g + P_lip)*AoverV     # s^-1
def g_gate(Cin):         return 1.0/(1.0+(Cin/C_half)**n_gate) # Cys53 redox brake
PA_astro, PA_u87 = fAQP_astro*P_lip, fAQP_u87*P_lip
Phi_astro = k_in(PA_astro)/k_astro
Phi_u87   = k_in(PA_u87)/k_u87
Cin_ss = lambda Phi: C_out*Phi/(1+Phi)

print("="*56,"\n NO-GATING STEADY STATE\n","="*55)
print(f" Phi_astro={Phi_astro:.3f} -> C_in/C_out={Phi_astro/(1+Phi_astro):.3f}")
print(f" Phi_u87  ={Phi_u87:.3f} -> C_in/C_out={Phi_u87/(1+Phi_u87):.3f}")
S = (Phi_u87/(1+Phi_u87))/(Phi_astro/(1+Phi_astro))
print(f" Selectivity S_dose = {S:.1f}x  | rho-amplif (k_in ratio)={k_in(PA_u87)/k_in(PA_astro):.2f}"
      f"  x  clearance asymm (k ratio)={k_astro/k_u87:.1f}")
# gated U87 steady state (self-consistent)
Cin_u87_g = brentq(lambda C: k_in(PA_u87,g_gate(C))*(C_out-C)-k_u87*C, 0, C_out)
print(f" U87 gated C_in,ss={Cin_u87_g*1e6:.1f} µM  (vs no-brake {Cin_ss(Phi_u87)*1e6:.1f} µM) -> Cys53 brake")

# ===== 3. FIG 1 — universal regime separation =====
Phi=np.logspace(-2.5,2.5,500)
f1,ax=plt.subplots(figsize=(6,4.2))
ax.semilogx(Phi,Phi/(1+Phi),'k-',lw=2)
ax.axhline(.5,color='grey',ls=':'); ax.axvline(1,color='grey',ls=':')
ax.fill_betweenx([0,1],1e-3,1,alpha=.06,color='tab:blue')
ax.fill_betweenx([0,1],1,1e3,alpha=.06,color='tab:red')
for nm,Ph,c,dy in [("astrocyte",Phi_astro,'tab:blue',-14),("U87 + PAW",Phi_u87,'tab:red',8)]:
    y=Ph/(1+Ph); ax.plot(Ph,y,'o',color=c,ms=9,zorder=5)
    ax.annotate(f"{nm}\nΦ={Ph:.2g}",(Ph,y),textcoords="offset points",xytext=(8,dy),
                color=c,fontsize=9,fontweight='bold')
ax.text(.03,.9,"clearance-dominated\n(protected)",color='tab:blue',fontsize=8.5)
ax.text(8,.12,"influx-dominated\n(flooded)",color='tab:red',fontsize=8.5,ha='center')
ax.set_xlabel(r"$\Phi=(P_{AQP8}+P_{lip})(A/V)/k_{clear}$"); ax.set_ylabel(r"$C_{in,ss}/C_{out}$")
ax.set_title("Regime separation sets selectivity"); ax.set_xlim(Phi[0],Phi[-1]); ax.set_ylim(0,1)
f1.tight_layout(); f1.savefig("fig1_regime_separation.png",dpi=200)

# ===== 4. FIG 2 — selectivity map (rho ratio × k ratio) =====
rr=np.logspace(0,1.3,200); kr=np.logspace(0,1.6,200); RR,KR=np.meshgrid(rr,kr)
Phi_a=k_in(PA_astro)/k_astro
Phi_u=((RR*PA_astro+P_lip)*AoverV)/(k_astro/KR)
Smap=(Phi_u/(1+Phi_u))/(Phi_a/(1+Phi_a))
f2,ax=plt.subplots(figsize=(6.2,4.6))
cs=ax.contourf(RR,KR,Smap,levels=np.linspace(1,np.nanmax(Smap),15),cmap='magma')
f2.colorbar(cs,label=r"$S_{dose}=C_{in,U87}/C_{in,astro}$")
cb=ax.contour(RR,KR,Phi_u,levels=[1.0],colors='cyan',linewidths=2)
ax.clabel(cb,inline=True,fmt=r"$\Phi_{U87}=1$",fontsize=9)
ax.plot(fAQP_u87/fAQP_astro,k_astro/k_u87,'o',ms=11,color='lime',mec='k',zorder=5)
ax.annotate("operating point",(fAQP_u87/fAQP_astro,k_astro/k_u87),textcoords="offset points",
            xytext=(8,6),color='white',fontsize=9,fontweight='bold')
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel(r"AQP8 density ratio $\rho_{U87}/\rho_{astro}$")
ax.set_ylabel(r"clearance ratio $k_{astro}/k_{U87}$")
ax.set_title("AQP8 over-expression × clearance collapse")
f2.tight_layout(); f2.savefig("fig2_selectivity_map.png",dpi=200)

# ===== 5. FIG 3 — dynamic ODE: with/without Cys53 brake =====
def rhs(t,C,P,kcl,gate):
    g=g_gate(C[0]) if gate else 1.0
    return [k_in(P,g)*(C_out-C[0]) - kcl*C[0]]
te=np.linspace(0,2,600)
runs={"astrocyte (gated)":(PA_astro,k_astro,True,'tab:blue','-'),
      "U87+PAW (no brake)":(PA_u87,k_u87,False,'tab:red','--'),
      "U87+PAW (Cys53 brake)":(PA_u87,k_u87,True,'tab:red','-')}
f3,ax=plt.subplots(figsize=(6.2,4.2))
for lab,(P,k,g,c,ls) in runs.items():
    s=solve_ivp(rhs,(0,2),[0.0],t_eval=te,args=(P,k,g),method='LSODA',rtol=1e-8,atol=1e-12)
    ax.plot(s.t,s.y[0]*1e6,color=c,ls=ls,lw=2,label=lab)
ax.axhline(C_out*1e6,color='grey',ls=':'); ax.text(1.5,C_out*1e6*.96,r"$C_{out}$ (PAW)",color='grey',fontsize=9,va='top')
ax.set_xlabel("time (s)"); ax.set_ylabel(r"intracellular $C_{in}$ (µM)")
ax.set_title("Dynamic flood, capped by Cys53 gating"); ax.legend(fontsize=9,loc='center right')
f3.tight_layout(); f3.savefig("fig3_timecourse.png",dpi=200)
print("\nSaved: fig1_regime_separation.png, fig2_selectivity_map.png, fig3_timecourse.png")