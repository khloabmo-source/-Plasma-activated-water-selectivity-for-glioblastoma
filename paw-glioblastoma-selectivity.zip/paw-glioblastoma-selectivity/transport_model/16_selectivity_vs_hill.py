#!/usr/bin/env python3
"""Supplementary - kill selectivity as a function of the Hill exponent h.

The headline survival selectivity is governed primarily by h, which is fitted to
five digitised points from a different cell line (U251SP) than the one modelled.
D50 is refitted at each fixed h so the comparison is like-for-like.
"""
import os, sys
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _model as m

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures")
os.makedirs(OUT, exist_ok=True)
Da = m.dose(m.P_AQP8["astro"], m.K_CLEAR["astro"])
Du = m.dose(m.P_AQP8["u87"],  m.K_CLEAR["u87"])
Dk = np.array([m.dose(m.P_AQP8["u87"], m.K_CLEAR["u87"], c*1e-6) for c, _ in m.KURAKE])
print(f"gating form: n = {m.N_GATE:.0f} (steady state of Eq. 6)")
print(f"doses at 100 uM / 3 h: astro {Da:.3e}  U87 {Du:.3e}  ratio {Du/Da:.2f}")

hs = np.linspace(2, 9, 60); sel = []; r2s = []
for h in hs:
    (D50,), _ = curve_fit(lambda D, d: m.hill(D, d, h), Dk, m.S_KUR, p0=[3e5], maxfev=20000)
    r2s.append(1 - np.sum((m.S_KUR - m.hill(Dk, D50, h))**2) / np.sum((m.S_KUR - m.S_KUR.mean())**2))
    sel.append(m.hill(Da, D50, h) / m.hill(Du, D50, h))
sel, r2s = np.array(sel), np.array(r2s)
D50_0, h_0, _ = m.calibrate()
def _at(h):          # evaluate at the EXACT h (not the nearest grid point)
    (D50,), _ = curve_fit(lambda D, d: m.hill(D, d, h), Dk, m.S_KUR, p0=[3e5], maxfev=20000)
    r2 = 1 - np.sum((m.S_KUR - m.hill(Dk, D50, h))**2) / np.sum((m.S_KUR - m.S_KUR.mean())**2)
    return D50, m.hill(Da, D50, h), m.hill(Du, D50, h), r2
for h in (3, 4, 5, h_0, 8):
    D50, sa, su, r2 = _at(h)
    print(f"  h={h:4.2f}: D50={D50:.3e}  astro {sa*100:5.1f}%  U87 {su*100:5.1f}%  selectivity {sa/su:7.1f}x  R2={r2:.3f}")

fig, ax = plt.subplots(figsize=(6.4, 4.2))
ax.semilogy(hs, sel, "k-", lw=2)
_ci = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bootstrap_h_ci.txt")
h_lo, h_hi = np.loadtxt(_ci) if os.path.exists(_ci) else (np.nan, np.nan)   # written by 10_bootstrap_uncertainty.py
ax.axvspan(h_lo, h_hi, color="tab:blue", alpha=.10, label=f"bootstrap 95% CI on $h$ [{h_lo:.1f}, {h_hi:.1f}]")
ax.axvline(h_0, color="tab:red", ls="--", lw=1.5, label=f"calibrated $h$ = {h_0:.2f}")
ax.set(xlabel="Hill cooperativity exponent $h$", ylabel="kill selectivity (astro / U87 survival)",
       title="Survival selectivity is governed by $h$\n(100 µM, 3 h; $D_{50}$ refitted at each $h$)")
ax.legend(fontsize=9); ax.grid(alpha=.25, which="both")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figS15_selectivity_vs_hill.png"), dpi=200)
print(f"Saved {OUT}/figS15_selectivity_vs_hill.png")
