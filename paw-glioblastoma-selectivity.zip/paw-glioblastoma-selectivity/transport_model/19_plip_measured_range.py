#!/usr/bin/env python3
# ======================================================================
# 19_plip_measured_range.py
# Paper A — How the predicted dose selectivity depends on the background
# lipid permeability P_lip, evaluated at the values actually MEASURED by
# Orrico et al. 2022 (J. Biol. Chem. 298(1) 101503), the reference the
# baseline P_lip is anchored to.
#
# Their Table 2, at 37 C:
#   DMPC:DPPG:Chol (4:1:5), saturated      P_m = (4.1 +/- 0.5) x 10^-4 cm/s
#   DOPC:POPG:Chol (4:1:5), unsaturated    P_m = (5.5 +/- 0.3) x 10^-3 cm/s
#   intact human red blood cell            P_m = (1.6 +/- 0.3) x 10^-3 cm/s
# and from their solubility profile (their Fig. 1), P_m ~ 7 x 10^-4 cm/s.
#
# The model baseline, 5 x 10^-4 cm/s, sits at the saturated end of that
# range, and the Table 1 sampling interval [1e-4, 1e-3] covers that end
# only. This script states what the selectivity would be elsewhere in the
# measured range, so the choice is explicit rather than implicit.
#
# Deps:  numpy, scipy      Run:  python3 19_plip_measured_range.py
# ======================================================================
import numpy as np
from scipy.optimize import brentq
import _model as m

CASES = [
    (5.0e-4, "model baseline (Table 1)"),
    (4.1e-4, "measured, saturated +Chol liposome, 37 C"),
    (7.0e-4, "estimated from the solubility profile"),
    (1.0e-3, "Table 1 sampling upper bound"),
    (1.6e-3, "measured, intact human RBC, 37 C"),
    (5.5e-3, "measured, unsaturated +Chol liposome, 37 C"),
]


def solve(P_lip, n=m.N_GATE):
    """Steady state and dose selectivity at an arbitrary background P_lip.
    The channel permeabilities are multiples of P_lip (Table 1), so they
    scale with it, exactly as in _model.py."""
    g = lambda C: 1.0 / (1.0 + (C / m.C_HALF) ** n)
    def css(P_aqp8, k):
        return brentq(lambda C: (P_aqp8 * g(C) + P_lip) * m.AV * (m.C_OUT - C) - k * C,
                      0.0, m.C_OUT)
    Pa, Pu = 1.0 * P_lip, 4.0 * P_lip
    Ca = css(Pa, m.K_CLEAR["astro"])
    Cu = css(Pu, m.K_CLEAR["u87"])
    phi_a = (Pa + P_lip) * m.AV / m.K_CLEAR["astro"]
    phi_u = (Pu + P_lip) * m.AV / m.K_CLEAR["u87"]
    return Ca * 1e6, Cu * 1e6, Cu / Ca, phi_a, phi_u


D50, H, _ = m.calibrate()
print(f"Survival law: D50 = {D50:.3g} uM.s, h = {H:.3g}; exposure {m.T_EXPOSURE/3600:.0f} h, "
      f"C_out = {m.C_OUT*1e6:.0f} uM, gate n = {m.N_GATE:g}\n")
hdr = (f"{'P_lip (cm/s)':>12}  {'provenance':<44}{'C_astro':>8}{'C_U87':>8}{'S_dose':>8}"
       f"{'Phi_a':>7}{'Phi_u':>7}{'surv_astro':>11}{'surv_U87':>9}")
print(hdr); print("-" * len(hdr))
rows = []
for P, lab in CASES:
    Ca, Cu, S, pa, pu = solve(P)
    sv_u = m.hill(Cu * m.T_EXPOSURE, D50, H)
    sv_a = m.hill(Ca * m.T_EXPOSURE, D50, H)
    rows.append((P, lab, Ca, Cu, S, pa, pu, sv_a, sv_u))
    print(f"{P:12.2e}  {lab:<44}{Ca:8.1f}{Cu:8.1f}{S:8.2f}{pa:7.2f}{pu:7.2f}"
          f"{sv_a*100:10.1f}%{sv_u*100:8.1f}%")

lo = min(r[4] for r in rows if r[0] >= 4.1e-4)
hi = max(r[4] for r in rows if r[0] >= 4.1e-4)
print(f"\nAcross the measured range (4.1e-4 to 5.5e-3 cm/s) the dose selectivity spans "
      f"{lo:.1f} to {hi:.1f}.")
print("Two-fold selectivity survives throughout; its magnitude does not.")
spared = [r for r in rows if r[0] >= 4.1e-4 and r[7] >= 0.90]
print(f"Normal-cell sparing (astrocyte survival >= 90%) holds up to P_lip = "
      f"{max(r[0] for r in spared):.1e} cm/s and fails above it: at the unsaturated measured "
      f"value the astrocyte itself retains only {rows[-1][7]*100:.0f}% survival, so the "
      f"therapeutic window closes.")
print(f"The Table 1 sampling interval [1e-4, 1e-3] stops "
      f"{5.5e-3/1e-3:.1f}x below the unsaturated measured value, so the Monte Carlo of "
      f"Section 3.6 is conditional on a lipid background at or below 1e-3 cm/s.")
with open("plip_measured_range.txt", "w") as f:
    f.write("P_lip_cm_s,provenance,C_astro_uM,C_U87_uM,S_dose,Phi_astro,Phi_U87,survival_astro,survival_U87\n")
    for P, lab, Ca, Cu, S, pa, pu, sva, svu in rows:
        f.write(f"{P:.3e},{lab},{Ca:.2f},{Cu:.2f},{S:.3f},{pa:.3f},{pu:.3f},{sva:.5f},{svu:.5f}\n")
print("Saved: plip_measured_range.txt")
