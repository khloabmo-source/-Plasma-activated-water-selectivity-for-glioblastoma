#!/usr/bin/env python3
"""Shared transfer-function core. Imported by the figure scripts so that the
model is defined in exactly one place (Table 1 baseline values)."""
import csv, os
import numpy as np
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
from scipy.optimize import curve_fit

# ---- Table 1 baseline ----
AV      = 4000.0        # cm^-1   surface-to-volume ratio
P_LIP   = 5e-4          # cm/s    background lipid permeability
C_HALF  = 40e-6         # M       AQP8 half-closing concentration (assumed)
C_OUT   = 100e-6        # M       extracellular H2O2
P_AQP8  = {"astro": 1.0 * P_LIP, "u87": 4.0 * P_LIP}
K_CLEAR = {"astro": 50.0, "u87": 5.0}          # s^-1
T_EXPOSURE = 180 * 60.0                        # s (assumed effective window)

# Kurake et al. 2016, U251SP, H2O2-only killing branch (digitised from the marker
# centroids of Fig. 4(b)(iii), scaled to the 50% and 100% guide lines).
# SINGLE SOURCE: killcurve.csv. Every script that needs the five calibration points
# imports KURAKE from here; none keeps its own copy.
def load_killcurve(path=None):
    """Return [(C_out_uM, survival), ...] from killcurve.csv (comment lines start with '#')."""
    path = path or os.path.join(os.path.dirname(os.path.abspath(__file__)), "killcurve.csv")
    with open(path, newline="") as fh:
        rows = [r for r in csv.reader(l for l in fh if l.strip() and not l.lstrip().startswith("#"))]
    header, data = rows[0], rows[1:]
    assert header == ["cell", "C_out_uM", "time_min", "survival"], f"unexpected header {header}"
    assert len(data) == 5, f"expected 5 calibration points, found {len(data)}"
    assert all(abs(float(r[2]) - T_EXPOSURE / 60.0) < 1e-9 for r in data), \
        "killcurve.csv time_min differs from T_EXPOSURE"
    return [(float(r[1]), float(r[3])) for r in data]

KURAKE = load_killcurve()
S_KUR  = np.array([s for _, s in KURAKE])

hill = lambda D, D50, h: 1.0 / (1.0 + (D / D50) ** h)


# Gating exponent. n = 1 is the steady state of the single-thiol kinetic scheme
# of Eq. (6) and is used for every reported result. The cooperative form n = 2
# (the submitted value) is kept only as a sensitivity case: pass n=N_GATE_COOPERATIVE.
N_GATE = 1.0
N_GATE_COOPERATIVE = 2.0


def gate(C, n=N_GATE):
    """Open-channel fraction (see note above on n)."""
    return 1.0 / (1.0 + (C / C_HALF) ** n)


def c_in_ss(P_aqp8, k_clear, C_out=C_OUT, n=N_GATE, gated=True):
    """Self-consistent steady-state cytoplasmic concentration (M)."""
    f = lambda C: (P_aqp8 * (gate(C, n) if gated else 1.0) + P_LIP) * AV * (C_out - C) - k_clear * C
    return brentq(f, 0.0, C_out)


def phi(P_aqp8, k_clear, g=1.0):
    return (P_aqp8 * g + P_LIP) * AV / k_clear


def dose(P_aqp8, k_clear, C_out=C_OUT, T=T_EXPOSURE, n=N_GATE, gated=True):
    """Cumulative cytoplasmic dose (uM*s). C_in reaches steady state in <1 s,
    so the integral is C_ss * T to within a part in 10^4."""
    return c_in_ss(P_aqp8, k_clear, C_out, n, gated) * 1e6 * T


def calibrate(k_calibration=None, T=T_EXPOSURE, n=N_GATE):
    """Fit the Hill survival law to the Kurake curve.

    k_calibration is the clearance rate ASSIGNED to the cells on which the
    kill curve was measured. This is an attribution, not a measurement, and
    the fitted parameters depend on it (see Section 3.5)."""
    k = K_CLEAR["u87"] if k_calibration is None else k_calibration
    D = np.array([dose(P_AQP8["u87"], k, c * 1e-6, T, n) for c, _ in KURAKE])
    (D50, h), _ = curve_fit(hill, D, S_KUR, p0=[D[1], 5.0],
                            bounds=([1, 0.5], [1e9, 20]), maxfev=40000)
    r2 = 1 - np.sum((S_KUR - hill(D, D50, h)) ** 2) / np.sum((S_KUR - S_KUR.mean()) ** 2)
    return D50, h, r2
