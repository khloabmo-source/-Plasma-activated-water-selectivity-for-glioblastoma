#!/usr/bin/env python3
# ======================================================================
# permeability_isd.py  —  H2O2 lipid permeability from an umbrella-sampling
# PMF + a position-dependent diffusion profile D(z), via the inhomogeneous
# solubility-diffusion (ISD) relation:
#
#     1/P = integral  exp(G(z)/kT) / D(z)  dz             (Marrink-Berendsen 1994)
#     D(z) = Var(xi) / tau_int(xi)   per umbrella window   (Hummer 2005)
#
# ----------------------------------------------------------------------
# STATUS (see FINDINGS.md): this PMF is reported in Section 4.4 and is not the source of
# P_lip in the paper. The bare-bilayer MD permeability computed here
# OVERESTIMATES the direct experimental value (Orrico et al. 2022) by ~1-2
# orders of magnitude, consistent with additive force fields under-representing
# the H2O2 partitioning barrier. The transport model uses the experiment-
# anchored P_lip. This tool is retained for transparency and reuse.
# ----------------------------------------------------------------------
# Corrections over the initial version (each matters for the absolute P):
#   1. dt is AUTO-DETECTED from the pullx TIME column (not hard-coded). The
#      relevant interval is pull-nstxout * dt_MD (e.g. ~0.1 ps, not 2 ps);
#      since D = Var/tau and tau is proportional to dt, a wrong dt rescales P.
#   2. tau_int uses SOKAL automatic windowing instead of first-zero-crossing
#      truncation, which integrated noisy ACF tails and biased tau.
#   3. Membrane geometry is DETECTED. A half profile (bilayer centre at one end,
#      bulk at the other) is integrated as ONE leaflet; the full-membrane
#      resistance is then 2x (two leaflets in series). A full bulk->centre->bulk
#      profile is integrated as-is. The earlier fixed "symmetrise about the
#      geometric midpoint" was invalid for half profiles (it halved the barrier).
#
# Usage:
#   python3 permeability_isd.py --pmf profile.xvg --pullx 'umb*_x.xvg' --T 310.15
#   python3 permeability_isd.py --selftest        # validates the math, no data
# Deps: numpy
# ======================================================================
import argparse, glob, numpy as np

KB = 0.0083145          # kJ/mol/K
NM2CM = 1e-7            # 1 nm = 1e-7 cm

try:                                    # numpy >= 2.0 renamed trapz -> trapezoid
    from numpy import trapezoid as _trapz
except ImportError:
    from numpy import trapz as _trapz


def tau_int(x, dt_ps, c=6.0):
    """Integrated autocorrelation time (ps) via Sokal automatic windowing."""
    x = np.asarray(x, float); x = x - x.mean()
    n = len(x); var = (x @ x) / n
    if var <= 0:
        return np.nan
    rho = np.correlate(x, x, 'full')[n - 1:] / (var * n)      # normalized ACF, rho[0]=1
    tau_steps = 0.5 + np.cumsum(rho[1:])                      # integrated time at window M=1,2,...
    M = np.arange(1, len(tau_steps) + 1)
    idx = np.argmax(M >= c * tau_steps)                      # first M satisfying Sokal criterion
    if idx == 0 and M[0] < c * tau_steps[0]:
        idx = len(tau_steps) - 1                             # no window found -> use longest
    return float(tau_steps[idx] * dt_ps)                     # ps


def Dz_from_windows(pullx_files, dt_ps=None):
    """D(z) per window:  D = Var(xi)/tau_int.   1 nm^2/ps = 1e-2 cm^2/s.
    dt_ps is auto-detected from each file's time column unless given."""
    zc, Dz = [], []
    for f in sorted(pullx_files):
        a = np.loadtxt(f, comments=('@', '#'))
        xi = a[:, 1]                                          # pull coordinate (nm)
        dt = dt_ps if dt_ps is not None else float(np.median(np.diff(a[:, 0])))
        tau = tau_int(xi, dt)
        if tau and tau > 0:
            zc.append(xi.mean()); Dz.append((np.var(xi) / tau) * 1e-2)   # nm^2/ps -> cm^2/s
    o = np.argsort(zc)
    return np.array(zc)[o], np.array(Dz)[o]


def permeability(z_nm, G_kJ, z_D, D_cm2s, T=310.15, kT_threshold=3.0):
    """ISD permeability (cm/s) from PMF G(z) and diffusion D(z).
    Auto-detects half (centre->bulk) vs full (bulk->centre->bulk) geometry and
    applies the two-leaflets-in-series factor for a half profile."""
    kT = KB * T
    edge = 0.3
    lo = G_kJ[z_nm < z_nm.min() + edge].mean()
    hi = G_kJ[z_nm > z_nm.max() - edge].mean()
    G = G_kJ - min(lo, hi)                                    # reference = bulk (lower-G end)
    Dg = np.interp(z_nm, z_D, D_cm2s)                         # constant extrapolation at the ends
    R = np.exp(G / kT) / Dg                                   # s/cm^2 per (z in cm)
    Rint = _trapz(R, z_nm * NM2CM)                           # s/cm  (resistance of the sampled span)
    # is the high-G end the membrane centre (half profile) or bulk (full profile)?
    half_profile = (max(lo, hi) - min(lo, hi)) > kT_threshold * kT
    leaflets = 2.0 if half_profile else 1.0                   # two leaflets in series for a half profile
    return 1.0 / (leaflets * Rint)                            # cm/s


def selftest():
    print("SELF-TEST: full symmetric Gaussian barrier, constant D.")
    z = np.linspace(-3.0, 3.0, 241)                          # bulk..centre..bulk (FULL profile)
    Gmax = 20.0; G = Gmax * np.exp(-(z / 0.8) ** 2)          # kJ/mol, 0 in bulk
    D0 = 5e-6; zD = z; Dz = np.full_like(z, D0)              # cm^2/s
    P = permeability(z, G, zD, Dz, T=310.15)
    kT = KB * 310.15
    print(f"  barrier {Gmax} kJ/mol (~{Gmax/kT:.1f} kT), D={D0:.0e} cm^2/s -> P = {P:.3e} cm/s")
    assert P > 0 and np.isfinite(P), "P must be finite positive"
    P2 = permeability(z, (Gmax + 10) * np.exp(-(z / 0.8) ** 2), zD, Dz)
    print(f"  +10 kJ/mol -> P = {P2:.3e} cm/s   (ratio {P/P2:.0f}x, expect ~e^(10/kT)={np.exp(10/kT):.0f})")
    assert P2 < P, "higher barrier must lower P"
    print("  PASS: integration, units, geometry and monotonicity OK.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pmf"); ap.add_argument("--pullx")
    ap.add_argument("--dt_ps", type=float, default=None, help="override; default = auto-detect from pullx time column")
    ap.add_argument("--T", type=float, default=310.15)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest or not a.pmf:
        selftest()
    else:
        pr = np.loadtxt(a.pmf, comments=('@', '#'))
        z_nm, G = pr[:, 0], pr[:, 1]
        zD, Dz = Dz_from_windows(glob.glob(a.pullx), a.dt_ps)
        P = permeability(z_nm, G, zD, Dz, T=a.T)
        print(f"P(H2O2) = {P:.3e} cm/s   (PMF max-min = {np.max(G)-np.min(G):.1f} kJ/mol, "
              f"{len(zD)} windows, T={a.T} K)")
        print("NOTE: bare-bilayer MD; EXPLORATORY only. See FINDINGS.md "
              "(overestimates the experimental P_lip by ~1-2 orders).")
