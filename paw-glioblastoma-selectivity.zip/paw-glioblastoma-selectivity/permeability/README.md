# Lipid permeability of H2O2 (Section 4.4)

> See `FINDINGS.md`. This bare-bilayer PMF overestimates the experimental H2O2
> permeability (Orrico et al. 2022) by a factor of two to eight (di-unsaturated) and up to two orders of magnitude (saturated), so it is **not** the
> source of `P_lip`. The paper anchors `P_lip` to experiment and establishes the
> membrane null from the observables/TOST in `../membrane_analysis/`. The
> pipeline and `permeability_isd.py` are retained for transparency.

Computes P(H2O2) for a bilayer from an umbrella-sampling PMF + position-dependent
diffusion. Originally intended to convert the structural membrane comparison into
a permeability comparison; in practice it confirmed that the experiment-anchored
choice is correct (the force-field absolute is unreliable, while the relative
comparison is carried by the cheaper observables).

## Pipeline (per membrane, on a GPU cluster with GROMACS)

```bash
# 0) one-time prep: build the permeant + parameters + index groups
python3 build_h2o2.py            # -> h2o2.gro/.pdb/.mol2 (correct geometry)
bash topology_from_cgenff.sh     # -> h2o2.itp/.prm via CGenFF (one manual server step)
#    (after inserting H2O2 into the system:)
bash make_index.sh ins.gro       # -> index.ndx with MEMB / SOLV / H2O2
python3 verify_h2o2_topology.py h2o2.itp --prm h2o2.prm   # static checks before production

# in an astrocyte (or u87) run dir with conf.gro, topol.top, index.ndx:
bash run_pmf.sh astro       # -> profile.xvg (PMF) + pullx-*.xvg (for D(z))
```

`run_pmf.sh` inserts one H2O2, runs a slow steered pull across the bilayer to
seed ~30 umbrella windows (0.1 nm spacing), runs 30 ns/window, builds the PMF
with `gmx wham` (bootstrapped), then calls:

```bash
python3 permeability_isd.py --pmf profile.xvg --pullx 'pullx-*.xvg' --T 310.15
```

which returns **P (cm/s)** via the inhomogeneous solubility-diffusion integral
`1/P = ∫ exp(G(z)/kT)/D(z) dz`, with D(z) from the per-window position
autocorrelation (Hummer 2005).

## Validate the analysis without data

```bash
python3 permeability_isd.py --selftest
```

Checks the integration, units, and barrier→permeability monotonicity on a
synthetic PMF.

## Then close the loop

Paste `P_astro` and `P_U87` (mean ± bootstrap sd) into
`../transport_model/05_measured_plip_coupling.py` to propagate the measured
lipid permeability through to S_dose and the therapeutic window.

Files: `pull_steered.mdp`, `umbrella.mdp`, `run_pmf.sh`, `permeability_isd.py`,
`h2o2_params_NOTE.md`.

H2O2 bilayer PMF workflow reported in Section 4.4 (anchored to Orrico et al. 2022; Cordeiro 2014).
