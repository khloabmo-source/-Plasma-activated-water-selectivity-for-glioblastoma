#!/usr/bin/env python3
# ======================================================================
# str2itp_h2o2.py -- convert a CGenFF .str (RESI + params by analogy) into a
# self-contained GROMACS .itp with EXPLICIT bonded parameters (correct unit
# conversion of the authoritative CGenFF output). Atom types (e.g. OG311,
# HGP1) are standard CHARMM36 -> their LJ comes from the charmm36.ff your
# system already includes; only this molecule's charges + bonded params are
# written here. Equivalent to cgenff_charmm2gmx for a small molecule.
#   python3 str2itp_h2o2.py h2o2.str  ->  h2o2.itp
# ======================================================================
import sys, re
src = open(sys.argv[1] if len(sys.argv) > 1 else "h2o2.str").read().splitlines()

# CHARMM->GROMACS unit factors
KCAL = 4.184
KB  = lambda K: 2*100*KCAL*K     # kcal/mol/A^2 -> kJ/mol/nm^2 (E=1/2 k x^2)
KTH = lambda K: 2*KCAL*K         # kcal/mol/rad^2 -> kJ/mol/rad^2
KDIH= lambda K: KCAL*K           # kcal/mol -> kJ/mol
mass_of = lambda t: 15.9994 if t.startswith("O") else (1.0080 if t.startswith("H") else 12.011)

atoms=[]; conn=[]; bpar={}; apar={}; dpar={}
sec=None
for ln in src:
    s=ln.split("!")[0].strip()
    if not s: continue
    u=s.upper()
    if u.startswith("RESI"): sec="resi"; continue
    if u=="BONDS": sec="bonds"; continue
    if u=="ANGLES": sec="angles"; continue
    if u=="DIHEDRALS": sec="dih"; continue
    if u in ("IMPROPERS","END","RETURN","GROUP"): sec=("resi" if u=="GROUP" else None); continue
    f=s.split()
    if sec=="resi" and u.startswith("ATOM"):
        atoms.append((f[1], f[2], float(f[3])))            # name, type, charge
    elif sec=="resi" and u.startswith("BOND"):
        for i in range(1,len(f),2):                        # BOND a b [c d ...]
            if i+1<len(f): conn.append((f[i], f[i+1]))
    elif sec=="bonds" and len(f)>=4:
        bpar[frozenset(f[:2])]=(float(f[2]), float(f[3]))  # K, b0
    elif sec=="angles" and len(f)>=5:
        apar[tuple(f[:3])]=(float(f[3]), float(f[4]))      # K, theta0
    elif sec=="dih" and len(f)>=7:
        dpar.setdefault(tuple(f[:4]),[]).append((float(f[4]), int(f[5]), float(f[6])))

name2i={a[0]:i+1 for i,a in enumerate(atoms)}
typ={a[0]:a[1] for a in atoms}
adj={a[0]:[] for a in atoms}
for x,y in conn: adj[x].append(y); adj[y].append(x)

# enumerate angles (a-b-c) and proper dihedrals (a-b-c-d) + 1-4 pairs
angles=[]
for b in adj:
    for i in range(len(adj[b])):
        for j in range(i+1,len(adj[b])):
            angles.append((adj[b][i], b, adj[b][j]))
dih=[]; pairs=set()
for (x,y) in conn:
    for a in adj[x]:
        for d in adj[y]:
            if a!=y and d!=x and a!=d:
                dih.append((a,x,y,d)); pairs.add(frozenset((a,d)))

def lookpar(d, key):
    return d.get(key) or d.get(tuple(reversed(key)))

out=[]
out.append("; H2O2 -- converted from CGenFF h2o2.str (CGenFF 4.0 / params 5.0).")
out.append("; Atom types OG311/HGP1 are standard CHARMM36 (LJ from charmm36.ff).")
out.append("; Bonded params explicit (unit-converted from the .str). nrexcl=3.")
out.append("; NOTE: HOOH dihedral parameter penalty = 104.6; validate before production use.")
out.append("\n[ moleculetype ]\n; name  nrexcl\nH2O2    3\n")
out.append("[ atoms ]\n;  nr  type  resnr resnm atom cgnr   charge      mass")
for i,(nm,t,q) in enumerate(atoms,1):
    out.append(f"{i:5d}  {t:6s} 1     H2O2  {nm:4s} {i:3d}  {q:9.4f} {mass_of(t):9.4f}")
out.append("\n[ bonds ]\n;  ai aj  funct       b0(nm)        kb")
for (x,y) in conn:
    K,b0=lookpar(bpar, frozenset((typ[x],typ[y]))) if frozenset((typ[x],typ[y])) in bpar else bpar[frozenset((typ[x],typ[y]))]
    out.append(f"{name2i[x]:5d}{name2i[y]:4d}   1   {b0*0.1:12.6f} {KB(K):14.2f}")
out.append("\n[ pairs ]\n;  ai aj  funct")
for p in sorted(pairs, key=lambda s:sorted(name2i[a] for a in s)):
    a,d=sorted(p, key=lambda n:name2i[n]); out.append(f"{name2i[a]:5d}{name2i[d]:4d}   1")
out.append("\n[ angles ]\n;  ai aj ak funct    theta0      ktheta     ub0   kub")
for (a,b,c) in angles:
    par=lookpar(apar,(typ[a],typ[b],typ[c]))
    if par is None: continue
    K,th0=par
    out.append(f"{name2i[a]:5d}{name2i[b]:4d}{name2i[c]:4d}   5   {th0:9.3f} {KTH(K):11.3f}  0.000   0.0")
out.append("\n[ dihedrals ]\n;  ai aj ak al funct   phi0       kphi      mult")
seen=set()
for (a,b,c,d) in dih:
    key=(typ[a],typ[b],typ[c],typ[d]); terms=lookpar(dpar,key)
    if terms is None or (a,b,c,d) in seen: continue
    seen.add((a,b,c,d)); seen.add((d,c,b,a))
    for (K,n,delta) in terms:
        out.append(f"{name2i[a]:5d}{name2i[b]:4d}{name2i[c]:4d}{name2i[d]:4d}   9   {delta:7.2f} {KDIH(K):10.5f}  {n:2d}")
open("h2o2.itp","w").write("\n".join(out)+"\n")
print("Wrote h2o2.itp")
print(f"  atoms {len(atoms)} | bonds {len(conn)} | angles {len(angles)} | dihedrals {len(dih)} | pairs {len(pairs)}")
print(f"  net charge = {sum(a[2] for a in atoms):+.4f}")
