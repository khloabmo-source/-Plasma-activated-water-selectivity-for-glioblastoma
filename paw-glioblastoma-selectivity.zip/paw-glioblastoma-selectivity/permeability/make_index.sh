#!/usr/bin/env bash
# Build index groups MEMB / SOLV / H2O2 for the pull run.
#   MEMB = all lipids            (thermostat group + pull reference)
#   SOLV = water + ions + H2O2   (thermostat group; covers the rest)
#   H2O2 = the permeant          (pull group only)
# tc_grps in the mdp = "MEMB SOLV" so the two must tile ALL atoms; H2O2 is a
# sub-selection of SOLV used only for pulling.
#   bash make_index.sh ins.gro
set -e
GRO=${1:-ins.gro}
SOLV_RES="TIP3 SOL WAT TIP3P SPC POT CLA SOD NA CL K MG CA ZN H2O2"
gmx select -f "$GRO" -s "$GRO" -on index.ndx -select \
"\"MEMB\" not resname $SOLV_RES;
 \"SOLV\" resname $SOLV_RES;
 \"H2O2\" resname H2O2"
echo
echo "Wrote index.ndx. Verify:  gmx make_ndx -f $GRO -n index.ndx  (then 'q')"
echo "MEMB+SOLV must cover every atom (tc_grps); H2O2 must contain exactly 4 atoms."
