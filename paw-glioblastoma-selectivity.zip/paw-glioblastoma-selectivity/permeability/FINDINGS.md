# Permeability PMF — findings & status (Section 4.4)

## Summary
This directory computes the H2O2 lipid permeability of the astrocyte bilayer
from an umbrella-sampling PMF + a position-dependent diffusion profile (ISD).
It is retained for transparency and reuse, but its **absolute** permeability is
**not** the source of `P_lip` in the paper. The paper anchors `P_lip` to direct
experimental measurement (Orrico et al. 2022).

## What we found
- Astrocyte bilayer PMF (29 umbrella windows, good overlap, flat bulk): central
  free-energy barrier ~17 kJ/mol at z ≈ 0.76 nm (a small methyl-trough dip at the
  bilayer midplane).
- ISD permeability (Sokal-windowed D(z); half-profile
  leaflet factor; dt auto-detected): **P_astro ≈ 1.3×10⁻² cm/s** (first-zero-
  crossing D) to **4.2×10⁻² cm/s** (Sokal D). Equivalently κ = P·(A/V) ≈ 50–170 s⁻¹
  for A/V = 4000 cm⁻¹.

## Why it is NOT used to set P_lip
Orrico et al. (2022) measured H2O2 permeability of cholesterol-containing
phospholipid membranes **directly**: 4×10⁻⁴ cm/s (saturated acyl chains),
5×10⁻³ cm/s (unsaturated), and 1.6×10⁻³ cm/s for the intact human RBC membrane;
permeabilities of several human cells span 2×10⁻⁴ – 1.6×10⁻³ cm/s. The bare-
bilayer MD value here exceeds these by a factor of two to eight (di-unsaturated) and up to two orders of magnitude (saturated).

The discrepancy is consistent with additive force fields under-representing the
H2O2 partitioning free energy: the MD barrier (~17 kJ/mol) lies well below
the 29.0 kJ/mol free energy of transfer of H2O2 from water to hexadecane (Orrico et al. 2022) and the 33 ± 4 kJ/mol obtained for a POPC bilayer by earlier simulation (Cordeiro 2014). The experimental coefficient is therefore the trustworthy absolute
anchor; the MD provides only relative information.

## Bearing on the paper (conclusions unchanged)
The paper's membrane null does **not** depend on this PMF:
- Relative (compositional) non-selectivity is established by the membrane
  observables and TOST in `../membrane_analysis/` — astrocyte ≈ U87-MG, and if
  anything the malignant membrane is marginally **less** permeable (NULL#1).
- `P_lip` magnitude is from Orrico et al. (2022); the transfer-function argument
  (clearance asymmetry sets selectivity) is unaffected.

This exploration's value was to confirm, from first principles, that the
**experiment-anchored** choice is the correct one — a systematic FF offset
cancels in the relative comparison but disqualifies the bare-bilayer absolute.

## Note on `../transport_model/05_measured_plip_coupling.py`
With P_lip taken from experiment, `05_...` is best read as a **sensitivity tool**:
feed any P_lip (e.g. the MD value above, or the Orrico bracket) and propagate it
to S_dose / the window. It is not a calibration step for the paper.

## Analysis script
`permeability_isd.py` implements:
- dt read from the pullx time column;
- Sokal automatic windowing for D(z), rather than first-zero-crossing truncation;
- automatic half/full geometry handling — a half profile is integrated as one
  leaflet and doubled for the bilayer, since fixed midpoint symmetrisation is
  invalid for half profiles and halves the barrier.

Validate the math with `python3 permeability_isd.py --selftest`.
