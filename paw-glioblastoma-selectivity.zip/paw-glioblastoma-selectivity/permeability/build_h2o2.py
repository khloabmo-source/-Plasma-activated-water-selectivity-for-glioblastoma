#!/usr/bin/env python3
# ======================================================================
# build_h2o2.py  -- generate a single H2O2 molecule with correct gas-phase
# geometry, written as .gro (nm, for GROMACS), .pdb and .mol2 (Angstrom,
# for the CGenFF server). No external deps beyond numpy.
#
# Experimental geometry: r(O-O)=1.452 A, r(O-H)=0.965 A,
#   angle(O-O-H)=102.3 deg, dihedral(H-O-O-H)=113.5 deg.
#   python3 build_h2o2.py
# ======================================================================
import numpy as np

rOO, rOH = 1.452, 0.965          # Angstrom
aOOH = np.radians(102.3)
dih  = np.radians(113.5)

# O1 at origin; O2 along +x
O1 = np.array([0.0, 0.0, 0.0])
O2 = np.array([rOO, 0.0, 0.0])
# H1 on O1 in the xy-plane (reference for the dihedral)
H1 = O1 + rOH*np.array([np.cos(aOOH), np.sin(aOOH), 0.0])
# H2 on O2: rotate by the H-O-O-H dihedral about the O1-O2 (x) axis
hx = -np.cos(aOOH)                      # component along O2->O1 (-x)
hr =  np.sin(aOOH)                      # perpendicular radius
H2 = O2 + rOH*np.array([hx, hr*np.cos(dih), hr*np.sin(dih)])

atoms = [("O1","O",O1),("O2","O",O2),("H1","H",H1),("H2","H",H2)]

def chk(p,q): return np.linalg.norm(p-q)
print(f"r(O1-O2)={chk(O1,O2):.3f}  r(O1-H1)={chk(O1,H1):.3f}  r(O2-H2)={chk(O2,H2):.3f} A")
ang=lambda a,b,c: np.degrees(np.arccos(np.dot(a-b,c-b)/(np.linalg.norm(a-b)*np.linalg.norm(c-b))))
print(f"angle(O2-O1-H1)={ang(O2,O1,H1):.1f}  angle(O1-O2-H2)={ang(O1,O2,H2):.1f} deg")

# --- .gro (nm) ---
with open("h2o2.gro","w") as f:
    f.write("H2O2 molecule\n%5d\n" % len(atoms))
    for i,(nm,el,xyz) in enumerate(atoms,1):
        x,y,z = xyz/10.0                      # A -> nm
        f.write("%5d%-5s%5s%5d%8.3f%8.3f%8.3f\n" % (1,"H2O2",nm,i,x,y,z))
    f.write("%10.5f%10.5f%10.5f\n" % (2.0,2.0,2.0))

# --- .pdb (Angstrom) ---
with open("h2o2.pdb","w") as f:
    f.write("REMARK  H2O2 single molecule\n")
    for i,(nm,el,xyz) in enumerate(atoms,1):
        f.write("HETATM%5d %-4s %-3s A   1    %8.3f%8.3f%8.3f  1.00  0.00          %2s\n"
                % (i,nm,"H2O",xyz[0],xyz[1],xyz[2],el))
    f.write("CONECT    1    2    3\nCONECT    2    1    4\nEND\n")

# --- .mol2 (Angstrom; upload THIS to the CGenFF server) ---
bonds=[(1,2,"1"),(1,3,"1"),(2,4,"1")]
with open("h2o2.mol2","w") as f:
    f.write("@<TRIPOS>MOLECULE\nH2O2\n 4 3 0 0 0\nSMALL\nNO_CHARGES\n\n@<TRIPOS>ATOM\n")
    syb={"O":"O.3","H":"H"}
    for i,(nm,el,xyz) in enumerate(atoms,1):
        f.write("%7d %-4s %9.4f %9.4f %9.4f %-5s 1 H2O2 0.0000\n"
                % (i,nm,xyz[0],xyz[1],xyz[2],syb[el]))
    f.write("@<TRIPOS>BOND\n")
    for j,(a,b,o) in enumerate(bonds,1):
        f.write("%6d %4d %4d %s\n" % (j,a,b,o))
print("Wrote h2o2.gro, h2o2.pdb, h2o2.mol2")
