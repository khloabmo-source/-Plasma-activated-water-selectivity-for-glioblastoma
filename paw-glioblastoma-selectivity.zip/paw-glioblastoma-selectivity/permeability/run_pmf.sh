#!/usr/bin/env bash
# H2O2 permeability PMF for ONE membrane. Run once per system (astro, u87).
# Prereqs: equilibrated membrane (conf.gro, topol.top, index.ndx with MEMB,SOLV),
#          an H2O2 .itp/params (CGenFF; see h2o2_params_NOTE.md), and GROMACS.
set -e
SYS=${1:-astro}                     # astro | u87
GRO=conf.gro; TOP=topol.top; NDX=index.ndx

# 1) insert one H2O2 in the water slab and add it to the topology + index
gmx insert-molecules -f $GRO -ci h2o2.gro -nmol 1 -o ins.gro -try 200
#   (add 'H2O2  1' under [ molecules ] in $TOP, and an [ H2O2 ] group to $NDX)

# 2) slow steered pull from bulk water to the bilayer centre -> windows
gmx grompp -f pull_steered.mdp -c ins.gro -p $TOP -n $NDX -o steer.tpr -maxwarn 1
gmx mdrun -deffnm steer -pf steerf.xvg -px steerx.xvg

# 3) sample ~30 starting frames every ~0.1 nm in z from the steered trajectory
echo 0 | gmx trjconv -s steer.tpr -f steer.xtc -o win.gro -sep -dt 100   # adjust dt to hit 0.1 nm spacing

# 4) one umbrella window per frame
for i in $(seq 0 29); do
  gmx grompp -f umbrella.mdp -c win${i}.gro -p $TOP -n $NDX -o umb${i}.tpr -maxwarn 1
  gmx mdrun -deffnm umb${i} -px pullx-${i}.xvg -pf pullf-${i}.xvg
done

# 5) WHAM -> PMF (profile.xvg). Bootstrapped error.
ls umb*.tpr  > tpr-files.dat
ls pullf-*.xvg > pullf-files.dat
gmx wham -it tpr-files.dat -if pullf-files.dat -o profile.xvg -hist hist.xvg \
         -unit kJ -nBootstrap 50 -bsres bsResult.xvg -b 5000      # discard first 5 ns

# 6) permeability via inhomogeneous solubility-diffusion (PMF + D(z))
python3 permeability_isd.py --pmf profile.xvg --pullx 'pullx-*.xvg' --T 310.15
echo "Done $SYS. Re-run for the other membrane and compare P_astro vs P_U87."
