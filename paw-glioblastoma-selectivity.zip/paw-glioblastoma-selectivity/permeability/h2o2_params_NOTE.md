# H2O2 parameters & system prep — quick guide

Deterministic, ready files:
- `build_h2o2.py`  -> `h2o2.gro` / `h2o2.pdb` / `h2o2.mol2` (correct geometry).
- `make_index.sh`  -> `index.ndx` with **MEMB / SOLV / H2O2** (matches the mdp
  `tc_grps = MEMB SOLV`; H2O2 is a pull-only sub-group of SOLV).

Force field (the one manual step — do it the authoritative way, don't invent
parameters for a published permeability number):
- `topology_from_cgenff.sh` walks through CGenFF server -> `cgenff_charmm2gmx.py`
  -> `h2o2.itp` + `h2o2.prm`. For internal consistency, prefer reusing the same
  standard CGenFF peroxide parameter source.
- `h2o2.itp` here is a **skeleton** (correct connectivity + CHARMM atom types,
  charges flagged) to cross-check the converter output — not for production.

Then: `bash run_pmf.sh astro` (and `u87`).

Verify before production:
- `verify_h2o2_topology.py h2o2.itp --prm h2o2.prm` — static checks (charge
  neutrality, 2O+2H, total mass 34.0147, 3 bonds/2 angles/1 dihedral,
  connectivity, parameter completeness) and warns if you are still on the
  skeleton. Then the bulk-water run (`bulk_npt.mdp`) and
  `... --bulk bulk.edr` for energy-drift/temperature.

UPDATE: h2o2.str (CGenFF 4.0) is included; h2o2.itp here is the REAL converted
topology (charges +/-0.419, OG311/HGP1, bonded params explicit) produced by
`str2itp_h2o2.py h2o2.str` -- not the skeleton. Verified by verify_h2o2_topology.py.
Wire into topol.top:  #include "h2o2.itp"  (AFTER the charmm36.ff include),
then add  H2O2  1  under [ molecules ].
