#!/usr/bin/env python3
# ======================================================================
# verify_h2o2_topology.py  -- pre-production sanity checks on the H2O2
# GROMACS topology produced by cgenff_charmm2gmx.py (or the skeleton).
#
# STATIC checks (no GROMACS needed):
#   * exactly 4 atoms (2 O ~15.999, 2 H ~1.008); total mass ~ 34.0147 g/mol
#   * net charge ~ 0
#   * connectivity: 3 bonds (O-O, O-H, O-H), 2 angles, >=1 proper dihedral,
#     degree(O)=2, degree(H)=1
#   * parameter completeness against h2o2.prm (if given): every bonded
#     interaction's atom-type tuple has a matching *type entry
#   * warns if charges are still the skeleton placeholders (not real CGenFF)
#
# DYNAMIC check (needs GROMACS; prints the recipe, and analyses the output
#   if you pass --bulk bulk.edr): single H2O2 in TIP3P must show no energy
#   drift and a flat bulk PMF (the G=0 reference for the permeability run).
#
#   python3 verify_h2o2_topology.py h2o2.itp [--prm h2o2.prm] [--bulk bulk.edr]
#   python3 verify_h2o2_topology.py --selftest
# Deps: stdlib only (panedr optional, only for --bulk).
# ======================================================================
import sys, argparse, re

PASS, FAIL, WARN = [], [], []
def ok(m):  PASS.append(m)
def bad(m): FAIL.append(m)
def warn(m): WARN.append(m)

def _rows(path, section):
    """Yield whitespace-split data rows of an itp/top [section]."""
    cur, out = None, []
    for raw in open(path):
        line = raw.split(";")[0].rstrip()
        if not line.strip():
            continue
        h = re.match(r"\s*\[\s*(\S+)\s*\]", line)
        if h:
            cur = h.group(1).lower(); continue
        if cur == section.lower():
            out.append(line.split())
    return out

def parse_itp(path):
    atoms = []
    for r in _rows(path, "atoms"):
        # nr type resnr resnm atom cgnr charge [mass]
        nr = int(r[0]); typ = r[1]; name = r[4]
        charge = float(r[6]); mass = float(r[7]) if len(r) > 7 else None
        atoms.append(dict(nr=nr, type=typ, name=name, charge=charge, mass=mass))
    bonds  = [(int(r[0]), int(r[1])) for r in _rows(path, "bonds")]
    angles = [(int(r[0]), int(r[1]), int(r[2])) for r in _rows(path, "angles")]
    dih    = [tuple(map(int, r[:4])) for r in _rows(path, "dihedrals")]
    return atoms, bonds, angles, dih

ELEM_MASS = {"O": 15.999, "H": 1.008}
def element_of(mass):
    if mass is None: return "?"
    return min(ELEM_MASS, key=lambda e: abs(ELEM_MASS[e] - mass))

def check_static(itp, prm=None):
    atoms, bonds, angles, dih = parse_itp(itp)

    # --- atoms / masses / element makeup ---
    if len(atoms) == 4: ok("4 atoms")
    else: bad(f"expected 4 atoms, found {len(atoms)}")
    masses = [a["mass"] for a in atoms]
    if all(m is not None for m in masses):
        els = sorted(element_of(m) for m in masses)
        if els == ["H", "H", "O", "O"]: ok("composition 2xO + 2xH")
        else: bad(f"composition wrong: {els}")
        tot = sum(masses)
        if abs(tot - 34.0147) < 0.05: ok(f"total mass {tot:.4f} ~ 34.0147")
        else: bad(f"total mass {tot:.4f} != 34.0147 (HOOH)")
    else:
        warn("masses absent in [atoms]; GROMACS will read them from atomtypes")

    # --- net charge ---
    q = sum(a["charge"] for a in atoms)
    if abs(q) < 1e-3: ok(f"net charge {q:+.4f} ~ 0")
    else: bad(f"net charge {q:+.4f} not neutral")
    # skeleton-placeholder detection
    qs = sorted(abs(a["charge"]) for a in atoms)
    if len(set(round(x, 3) for x in qs)) == 1 and abs(qs[0] - 0.410) < 1e-3:
        warn("charges look like the SKELETON placeholders (+/-0.410). Replace with "
             "the CGenFF .str output before production.")

    # --- connectivity ---
    if len(bonds) == 3: ok("3 bonds")
    else: bad(f"expected 3 bonds, found {len(bonds)}")
    if len(angles) == 2: ok("2 angles")
    else: bad(f"expected 2 angles, found {len(angles)}")
    if len(dih) >= 1: ok(f"{len(dih)} dihedral(s)")
    else: bad("no proper dihedral (H-O-O-H) found")

    deg = {a["nr"]: 0 for a in atoms}
    for i, j in bonds:
        if i in deg and j in deg: deg[i] += 1; deg[j] += 1
        else: bad(f"bond ({i},{j}) references a non-existent atom")
    by_el = {a["nr"]: element_of(a["mass"]) for a in atoms}
    odeg = [deg[a["nr"]] for a in atoms if by_el[a["nr"]] == "O"]
    hdeg = [deg[a["nr"]] for a in atoms if by_el[a["nr"]] == "H"]
    if odeg == [2, 2]: ok("each O bonded to 2 partners (O-O + O-H)")
    elif odeg: bad(f"O degrees {odeg} != [2,2] (peroxide O-O missing?)")
    if hdeg == [1, 1]: ok("each H bonded to exactly 1 O")
    elif hdeg: bad(f"H degrees {hdeg} != [1,1]")

    # --- parameter completeness against the .prm (optional) ---
    if prm:
        defined = {s: set() for s in ("bondtypes", "angletypes", "dihedraltypes", "atomtypes")}
        atype = {}
        for r in _rows(prm, "atomtypes"):
            defined["atomtypes"].add(r[0])
        for sec, n in (("bondtypes", 2), ("angletypes", 3), ("dihedraltypes", 4)):
            for r in _rows(prm, sec):
                defined[sec].add(frozenset_pair(r[:n]))
        T = {a["nr"]: a["type"] for a in atoms}
        missing = []
        for (i, j) in bonds:
            if frozenset_pair([T[i], T[j]]) not in defined["bondtypes"]:
                missing.append(f"bond {T[i]}-{T[j]}")
        for (i, j, k) in angles:
            if frozenset_pair([T[i], T[j], T[k]]) not in defined["angletypes"]:
                missing.append(f"angle {T[i]}-{T[j]}-{T[k]}")
        for a in atoms:
            if a["type"] not in defined["atomtypes"]:
                missing.append(f"atomtype {a['type']}")
        if not missing: ok("all atom/bonded types present in .prm")
        else: bad("missing parameters in .prm: " + ", ".join(sorted(set(missing))))
    else:
        warn("no --prm given: grompp will resolve bonded params from the force "
             "field include; run grompp to confirm none are missing.")

def frozenset_pair(types):
    # match either order (CHARMM bonded params are symmetric)
    return frozenset([tuple(types), tuple(reversed(types))])

BULK_RECIPE = """
DYNAMIC stability check (run on the cluster, ~1 ns, CPU is fine):
  gmx solvate -cs spc216.gro -cp h2o2.gro -o bulk.gro -p topol_bulk.top
  gmx grompp  -f bulk_npt.mdp -c bulk.gro -p topol_bulk.top -o bulk.tpr -maxwarn 1
  gmx mdrun   -deffnm bulk
  # then:  python3 verify_h2o2_topology.py h2o2.itp --bulk bulk.edr
Expect: Total/Conserved-Energy drift ~ 0, temperature ~ 310 K, the molecule
stays intact (O-O bond ~0.145 nm), and the bulk PMF is flat (G=0 reference).
A bulk H2O2 self-diffusion of ~1-2e-5 cm^2/s is a good sanity value.
"""

def check_bulk(edr):
    try:
        import panedr, numpy as np
    except ImportError:
        warn("panedr not installed; skipping --bulk drift analysis. " + BULK_RECIPE.strip())
        return
    import numpy as np
    df = panedr.edr_to_df(edr); t = df["Time"].to_numpy() / 1000.0
    for key in ("Total Energy", "Conserved En.", "Temperature"):
        if key in df:
            y = df[key].to_numpy()
            slope = np.polyfit(t, y, 1)[0]
            tag = "Temperature" in key
            if "Energy" in key:
                (ok if abs(slope) < 5e2 else bad)(f"{key} drift {slope:+.2f}/ns")
            else:
                (ok if abs(y.mean()-310) < 5 else warn)(f"{key} mean {y.mean():.1f} K")

def selftest():
    import tempfile, os
    skel = """[ atoms ]
 1 OG311 1 H2O2 O1 1 -0.410 15.9994
 2 OG311 1 H2O2 O2 2 -0.410 15.9994
 3 HGP1  1 H2O2 H1 3  0.410  1.0080
 4 HGP1  1 H2O2 H2 4  0.410  1.0080
[ bonds ]
 1 2 1
 1 3 1
 2 4 1
[ angles ]
 2 1 3 5
 1 2 4 5
[ dihedrals ]
 3 1 2 4 9
"""
    f = tempfile.NamedTemporaryFile("w", suffix=".itp", delete=False); f.write(skel); f.close()
    print("SELF-TEST on a valid skeleton itp:")
    check_static(f.name); os.unlink(f.name)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("itp", nargs="?")
    ap.add_argument("--prm"); ap.add_argument("--bulk")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest or not a.itp:
        selftest()
    else:
        check_static(a.itp, a.prm)
        if a.bulk: check_bulk(a.bulk)
        else: print(BULK_RECIPE)

    print("\n" + "="*60)
    for m in PASS: print(f"  PASS  {m}")
    for m in WARN: print(f"  WARN  {m}")
    for m in FAIL: print(f"  FAIL  {m}")
    print("="*60)
    print(("ALL STATIC CHECKS PASSED" if not FAIL else f"{len(FAIL)} CHECK(S) FAILED")
          + (f"  ({len(WARN)} warning(s))" if WARN else ""))
    sys.exit(1 if FAIL else 0)
