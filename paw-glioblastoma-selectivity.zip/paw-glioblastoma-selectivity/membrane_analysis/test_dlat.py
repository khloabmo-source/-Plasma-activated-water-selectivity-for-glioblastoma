# -*- coding: utf-8 -*-
# Synthetic validation of lateral_D() in extract_ws1.py: generates
# 2-D Brownian motion with a KNOWN D plus a large per-leaflet collective drift and
# PBC wrapping, and checks the function (per-leaflet COM removal + unwrap) recovers
# D. No trajectories required.   run: python3 test_dlat.py
import numpy as np, MDAnalysis as mda, warnings
from MDAnalysis.coordinates.memory import MemoryReader
warnings.filterwarnings("ignore")
ns={}; exec(compile(open("extract_ws1.py").read().split("\nrows = []")[0],"extract_ws1.py","exec"),ns)
lateral_D=ns["lateral_D"]
rng=np.random.default_rng(0)
n_lip,n_fr,dt_ns,box=120,200,1.0,80.0
D_true=3.0                                   # um^2/s
sigma=np.sqrt(2*(D_true/10.0)*dt_ns)         # 1 A^2/ns = 10 um^2/s
z=np.array([20.0]*60+[-20.0]*60)
xy0=rng.uniform(0,box,size=(n_lip,2))
steps=rng.normal(0,sigma,size=(n_fr,n_lip,2)); steps[0]=0
disp=np.cumsum(steps,axis=0)
t=np.arange(n_fr)*dt_ns; drift=np.zeros((n_fr,n_lip,2))
drift[:,:60,0]=(2.0*t)[:,None]; drift[:,:60,1]=(1.0*t)[:,None]
drift[:,60:,0]=(-1.0*t)[:,None]; drift[:,60:,1]=(3.0*t)[:,None]
pos=np.zeros((n_fr,n_lip,3)); pos[:,:,:2]=np.mod(xy0[None]+disp+drift,box); pos[:,:,2]=z[None]
u=mda.Universe.empty(n_lip,n_residues=n_lip,atom_resindex=np.arange(n_lip),trajectory=True)
u.add_TopologyAttr("names",["P"]*n_lip); u.add_TopologyAttr("resnames",["POPC"]*n_lip)
u.add_TopologyAttr("resids",np.arange(1,n_lip+1))
u.load_new(pos,format=MemoryReader,dimensions=np.tile([box,box,box,90,90,90],(n_fr,1)),dt=dt_ns*1000)
ns["T_EQUIL_NS"]=0.0
D=lateral_D(u,fit_ns=(20.0,80.0),report=True)
print(f"  TRUE D_lat = {D_true:.3f} um^2/s ; RECOVERED = {D:.3f} um^2/s (PBC + per-leaflet drift)")
assert abs(D-D_true)<0.4, f"recovered {D}"
print("  PASS: drift removed, PBC unwrapped, units correct (um^2/s)\nLATERAL_D VALIDATED")
