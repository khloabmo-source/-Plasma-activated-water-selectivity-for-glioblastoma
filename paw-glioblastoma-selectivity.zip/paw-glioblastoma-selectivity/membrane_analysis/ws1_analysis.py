#!/usr/bin/env python3
# ======================================================================
# WS1 membrane analysis — finalize the 80-200 ns window, compare U87 vs
# astrocyte across 3 replicates each, and emit manuscript-ready numbers
# for §2.1 / §3.1 / §4.1.
#
# PART A (optional)  re-extract APL, P-P thickness, and lateral D_lat from
#                    the completed 200 ns trajectories (MDAnalysis).
# PART B (core)      block-average within cell type, two-sample tests
#                    (Welch t + Mann-Whitney U), Cohen's d, convergence
#                    check, results table, and auto-written manuscript text.
#
# NOTE on -S_CD: uses per-replicate -S_CD summaries from ws1_values.csv.
# ======================================================================

import numpy as np
from scipy import stats

# ----------------------------- CONFIG ---------------------------------
T_EQUIL_NS   = 80.0            # discard 0-80 ns as equilibration
T_TOTAL_NS   = 200.0
MSD_FIT_NS   = (20.0, 80.0)    # lag window for the linear MSD fit (Methods Section 2.1)
ALPHA        = 0.05

# ======================================================================
# PART B INPUT  -- per-replicate scalars over the 80-200 ns window.
# Fill from your own extraction (the numbers behind Figs S1-S3), order
# rep1, rep2, rep3.  Set unknowns to None and the metric is skipped.
# ======================================================================
data = {
    "astro": {
        "SCD_glycero": [None, None, None],  # MANUSCRIPT -S_CD: mean over ALL glycerophospholipid acyl segments
        "SCD_plateau": [None, None, None],  # POPC sn-1 plateau -S_CD (C34-C38)
        "APL":         [None, None, None],  # A^2 / lipid
        "thickness":   [None, None, None],  # nm  (P-P)
        "Dlat":        [None, None, None],  # 1e-7 cm^2/s  (keep a consistent unit)
    },
    "u87": {
        "SCD_glycero": [None, None, None],
        "SCD_plateau": [None, None, None],
        "APL":         [None, None, None],
        "thickness":   [None, None, None],
        "Dlat":        [None, None, None],
    },
}

# Optional per-carbon -S_CD profiles for a curve-level comparison
# shape (3, n_carbons); leave None to skip.
scd_profile = {"astro_sn1": None, "u87_sn1": None,
               "astro_sn2": None, "u87_sn2": None}

# ----------------------------------------------------------------------
# CSV auto-load: if ws1_values.csv is present, it overrides `data` above.
# Columns: cell,rep,SCD_glycero,SCD_plateau,APL,thickness,Dlat   (cell in {astro,u87})
# This is the fastest path -- fill it from the numbers behind Figs S1-S3.
# ----------------------------------------------------------------------
import os, csv
_CSV = "ws1_values.csv"
if os.path.exists(_CSV):
    _tmp = {"astro": {k: [None]*3 for k in ("SCD_glycero","SCD_plateau","APL","thickness","Dlat")},
            "u87":   {k: [None]*3 for k in ("SCD_glycero","SCD_plateau","APL","thickness","Dlat")}}
    with open(_CSV) as fh:
        for row in csv.DictReader(fh):
            cell = row["cell"].strip().lower()
            i = int(row["rep"]) - 1
            if cell in _tmp and 0 <= i < 3:
                for k in ("SCD_glycero","SCD_plateau","APL","thickness","Dlat"):
                    val = row.get(k, "").strip()
                    _tmp[cell][k][i] = float(val) if val not in ("", "None", "nan") else None
    data = _tmp
    print(f"[loaded {_CSV}]\n")

# ----------------------------- helpers --------------------------------
def msem(v):
    v = np.asarray(v, float); n = len(v)
    return v.mean(), v.std(ddof=1), v.std(ddof=1)/np.sqrt(n), n

def cohend(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    sp = np.sqrt(((na-1)*a.var(ddof=1) + (nb-1)*b.var(ddof=1)) / (na+nb-2))
    return (b.mean()-a.mean())/sp if sp > 0 else np.nan

def compare(name, astro, u87, unit, note=""):
    if any(x is None for x in list(astro)+list(u87)):
        print(f"  {name:11s}: (fill values to compute)"); return None
    a, u = np.asarray(astro, float), np.asarray(u87, float)
    ma, _, ea, _ = msem(a); mu, _, eu, _ = msem(u)
    t,  p_t = stats.ttest_ind(u, a, equal_var=False)            # Welch
    U,  p_u = stats.mannwhitneyu(u, a, alternative="two-sided") # nonparametric
    d = cohend(a, u)
    sig = "n.s." if p_t > ALPHA else f"p={p_t:.3f}"
    arrow = "U87>astro" if mu > ma else "U87<astro"
    print(f"  {name:11s}: astro {ma:7.3f}±{ea:.3f}   U87 {mu:7.3f}±{eu:.3f} {unit:6s}"
          f"  Δ={mu-ma:+.3f}  Welch {sig}  MWU p={p_u:.3f}  d={d:+.2f}  [{arrow}] {note}")
    return dict(name=name, ma=ma, ea=ea, mu=mu, eu=eu, p_t=p_t, p_u=p_u, d=d,
                unit=unit, higher_u87=(mu > ma))

def profile_compare(tag, astro_arr, u87_arr):
    if astro_arr is None or u87_arr is None: return None
    a, u = np.asarray(astro_arr, float), np.asarray(u87_arr, float)  # (3, ncarbon)
    # paired per-carbon Welch across the profile -> fraction of carbons where U87 is higher
    ma, mu = a.mean(0), u.mean(0)
    frac_u87_higher = float(np.mean(mu > ma))
    # global Welch on per-replicate chain-averaged value
    t, p = stats.ttest_ind(u.mean(1), a.mean(1), equal_var=False)
    print(f"  {tag}: chain-avg astro {a.mean():.3f}  U87 {u.mean():.3f}  "
          f"({100*frac_u87_higher:.0f}% of carbons U87-higher)  Welch p={p:.3f}")
    return frac_u87_higher

# ----------------------------- run ------------------------------------
print("="*78)
print(f"WS1 membrane comparison | window {T_EQUIL_NS:.0f}-{T_TOTAL_NS:.0f} ns | n=3 reps/cell")
print("="*78)
res = {}
res["SCD"]   = compare("-S_CD",     data["astro"]["SCD_glycero"], data["u87"]["SCD_glycero"], "",   "(glycerophospholipid mean; higher=more ordered=LESS permeable)")
res["SCDpl"] = compare("-S_CD(pl.)",data["astro"]["SCD_plateau"], data["u87"]["SCD_plateau"], "",   "(POPC sn-1 plateau, C34-C38)")
res["APL"]   = compare("APL",       data["astro"]["APL"],         data["u87"]["APL"],         "A^2")
res["thick"] = compare("thickness", data["astro"]["thickness"],   data["u87"]["thickness"],   "nm")
res["Dlat"]  = compare("D_lat",     data["astro"]["Dlat"],        data["u87"]["Dlat"],        "um^2/s","(higher=more fluid)")

print("\nPer-carbon -S_CD profiles:")
profile_compare("sn-1 (16:0)", scd_profile["astro_sn1"], scd_profile["u87_sn1"])
profile_compare("sn-2 (18:1)", scd_profile["astro_sn2"], scd_profile["u87_sn2"])

# --------------------- auto manuscript sentence -----------------------
done = [r for r in res.values() if r]
if done:
    any_sig = any(r["p_t"] <= ALPHA for r in done)
    # "wrong sign" check: a permeability-based selectivity for U87 would need
    # U87 LESS ordered / MORE fluid / LARGER APL. Report the actual direction.
    scd = res.get("SCD")
    sign_phrase = ""
    if scd:
        sign_phrase = (" and where the membranes differ at all the malignant bilayer is "
                       "marginally MORE ordered (higher -S_CD), the wrong sign for a "
                       "permeability-based selectivity") if scd["higher_u87"] else \
                      (" the malignant membrane is marginally less ordered, which would "
                       "need quantitative weighing against the clearance mechanism")
    verdict = ("statistically indistinguishable (all p > %.2f)" % ALPHA) if not any_sig \
              else "different in at least one observable (see table); interpret the sign carefully"
    print("\n" + "-"*78)
    print("Summary comparison (Section 3.1):")
    print("-"*78)
    print(f"Across acyl-chain order (-S_CD), area per lipid, P-P bilayer thickness, and "
          f"lateral diffusion, over the 80-200 ns window and three replicates per cell "
          f"type, the U87-MG and astrocyte membranes were {verdict}{sign_phrase}. The "
          f"passive-membrane hypothesis is therefore not supported for this cell pair.")

# --------------------- convergence diagnostic note --------------------
print("\n" + "-"*78)
print("CONVERGENCE CHECK (addresses the D_lat replicate spread in Fig S3):")
print("-"*78)
if all(x is not None for x in data["u87"]["Dlat"]):
    for cell in ("astro", "u87"):
        v = np.asarray(data[cell]["Dlat"], float)
        cv = 100*v.std(ddof=1)/v.mean() if v.mean() else float("nan")
        print(f"  {cell}: D_lat per-rep CV = {cv:.0f}%  "
              f"({'OK' if cv < 25 else 'high — extend or widen fit window / check Fickian regime'})")
else:
    print("  (fill D_lat values; aim for per-replicate CV < ~25% and fit only the")
    print(f"   linear/Fickian part of the MSD, e.g. lag {MSD_FIT_NS[0]:.0f}-{MSD_FIT_NS[1]:.0f} ns).")

# ======================================================================
# PART A (OPTIONAL) -- extract APL / thickness / D_lat with MDAnalysis.
# Verify the selections against your CHARMM36 system before trusting these.
# Order parameters are computed in extract_ws1.py.
# ======================================================================
RUN_EXTRACTION = False   # set True after checking selections / paths below

if RUN_EXTRACTION:
    import MDAnalysis as mda
    from MDAnalysis.analysis.msd import EinsteinMSD

    REPS = {"astro": [f"astro_rep{i}" for i in (1,2,3)],
            "u87":   [f"u87_rep{i}"   for i in (1,2,3)]}
    TPR = "md.tpr"; XTC = "md.xtc"          # adjust to your filenames
    PHOS = "name P"                          # CHARMM36 phosphate
    LIPID = "resname POPC CHL1 CHOL"         # adjust to your lipids
    DT_NS = 0.0                              # 0 -> read from trajectory

    def extract(path):
        u = mda.Universe(f"{path}/{TPR}", f"{path}/{XTC}")
        dt_ns = (u.trajectory.dt/1000.0) if DT_NS == 0 else DT_NS
        f0 = int(round(T_EQUIL_NS/dt_ns))    # first frame of the 80 ns window
        # ---- APL (projected): box_xy / lipids-per-leaflet ----
        phos = u.select_atoms(PHOS)
        n_leaf = len(phos)//2
        areas = []
        for ts in u.trajectory[f0:]:
            areas.append(ts.dimensions[0]*ts.dimensions[1])
        APL = float(np.mean(areas))/n_leaf
        # ---- P-P thickness: upper vs lower phosphate mean-z ----
        th = []
        for ts in u.trajectory[f0:]:
            z = phos.positions[:,2]; c = z.mean()
            up, lo = z[z>c], z[z<c]
            th.append((up.mean()-lo.mean())/10.0)   # A -> nm
        THICK = float(np.mean(th))
        # ---- lateral D from Einstein MSD (xy) over the fit window ----
        msd = EinsteinMSD(u, select=PHOS, msd_type="xy", fft=True)
        msd.run(start=f0)
        lag = np.arange(msd.n_frames)*dt_ns
        lo_i = np.searchsorted(lag, MSD_FIT_NS[0]); hi_i = np.searchsorted(lag, MSD_FIT_NS[1])
        slope = np.polyfit(lag[lo_i:hi_i], msd.results.timeseries[lo_i:hi_i], 1)[0]
        # MSD in A^2, lag in ns -> slope A^2/ns; D = slope/(2*dim), dim=2 -> /4
        Dlat_A2_per_ns = slope/4.0
        Dlat_cm2_s = Dlat_A2_per_ns*1e-16/1e-9        # A^2/ns -> cm^2/s
        return APL, THICK, Dlat_cm2_s*1e7              # report in 1e-7 cm^2/s

    print("\n" + "="*78 + "\nEXTRACTION (80-200 ns):")
    for cell, dirs in REPS.items():
        for d in dirs:
            try:
                apl, th, dl = extract(d)
                print(f"  {d:11s}  APL={apl:6.2f} A^2  thick={th:5.3f} nm  D_lat={dl:5.2f}e-7 cm^2/s")
            except Exception as e:
                print(f"  {d}: extraction failed -> {e}")
    print("Paste these into the `data` dict above and re-run PART B.")
