# -*- coding: utf-8 -*-
"""
plot_msd_S4.py — plot Fig. S4 MSD curves from an existing msd_S4.npz (no
trajectory re-read). Headless-safe for Colab subprocesses.

    python3 plot_msd_S4.py            # -> figS4_lateral_msd.png  (200 dpi)

Left : linear MSD, 20-80 ns fit window shaded, dashed line at the window end.
Right: log-log MSD with a slope-1 (Fickian) reference, so the disclosed
       sub-diffusive scaling (alpha ~ 0.6) is visible rather than hidden.
Per-cell mean alpha (log-log slope over the fit window) is printed and shown.
"""
import os
os.environ["MPLBACKEND"] = "Agg"
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

FIT = (20.0, 80.0)
d = np.load("msd_S4.npz")
bases = sorted({k.rsplit("_", 1)[0] for k in d.files})
col = {"astro": "#2ca02c", "u87": "#d62728"}

# per-replicate alpha (log-log slope in the fit window) -> per-cell mean
alpha = {}
for base in bases:
    t = d[base + "_t"]; msd = d[base + "_msd"]
    i0 = np.searchsorted(t, FIT[0]); i1 = max(np.searchsorted(t, FIT[1]), i0 + 2)
    a = np.polyfit(np.log(t[i0:i1]), np.log(msd[i0:i1]), 1)[0]
    alpha.setdefault(base.split("_")[0], []).append(a)
acell = {c: np.mean(v) for c, v in alpha.items()}

fig, (axL, axR) = plt.subplots(1, 2, figsize=(10.5, 4.2), dpi=200)
for base in bases:
    cell = base.split("_")[0]
    t = d[base + "_t"]; msd = d[base + "_msd"]
    axL.plot(t, msd, color=col.get(cell, "grey"), lw=1.3, alpha=0.9, label=base.replace("_", " "))
    m = t > 0
    axR.plot(t[m], msd[m], color=col.get(cell, "grey"), lw=1.3, alpha=0.9)

# linear panel: shaded fit window + thin dashed line at window END 
axL.axvspan(*FIT, color="0.85", alpha=0.6, label="fit window")
axL.axvline(FIT[1], color="0.45", ls="--", lw=0.9)
axL.set_xlabel("lag (ns)"); axL.set_ylabel(r"lateral MSD ($\mathrm{\AA}^2$)")
axL.set_title("Lateral MSD (centre-of-mass-removed)")
axL.legend(fontsize=7, ncol=2, loc="upper left")

# log-log panel: Fickian slope-1 reference anchored at window start
axR.set_xscale("log"); axR.set_yscale("log")
b0 = bases[0]; t0 = d[b0 + "_t"]; m0 = d[b0 + "_msd"]
ia = np.searchsorted(t0, FIT[0]); anchor = m0[ia] if 0 < ia < len(m0) else None
if anchor:
    tref = np.array(FIT); axR.plot(tref, anchor * (tref / FIT[0]), "k--", lw=1, label="slope 1 (Fickian)")
axR.axvspan(*FIT, color="0.85", alpha=0.6)
txt = "  ".join(f"$\\alpha_{{{c}}}$={acell[c]:.2f}" for c in sorted(acell))
axR.text(0.03, 0.97, txt, transform=axR.transAxes, va="top", ha="left", fontsize=8,
         bbox=dict(boxstyle="round", fc="white", ec="0.7", alpha=0.85))
axR.set_xlabel("lag (ns)"); axR.set_ylabel(r"lateral MSD ($\mathrm{\AA}^2$)")
axR.set_title("log-log (sub-diffusive: slope < 1)")
axR.legend(fontsize=7, loc="lower right")

plt.tight_layout(); plt.savefig("figS4_lateral_msd.png", dpi=200, bbox_inches="tight")
print(f"wrote figS4_lateral_msd.png (200 dpi)  |  alpha per cell: " +
      ", ".join(f"{c}={acell[c]:.3f}" for c in sorted(acell)))
