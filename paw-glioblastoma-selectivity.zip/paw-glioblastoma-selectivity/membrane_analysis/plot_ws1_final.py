#!/usr/bin/env python3
"""Figs. S2 and S3 from the deposited derived data.

    ws1_scd_profiles.npz  per-carbon -S_CD of the POPC sn-1 and sn-2 chains,
                          per replicate, 80-200 ns, minimum-image C-H vectors
    ws1_values.csv        per-replicate area, thickness and order parameter

Fig. S2  acyl-chain order profiles (POPC sn-1 16:0 and sn-2 18:1)
Fig. S3  area per phospholipid, area per total lipid and P-P thickness:
         replicate values with mean +- SD, Welch p between compositions

    python3 plot_ws1_final.py
"""
import os
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
COLOR = {"astro": "#2A9D8F", "u87": "#E63946"}
LABEL = {"astro": "astrocyte", "u87": "U87-MG"}
MARK = {"astro": "o", "u87": "s"}
INK = "#222222"
N_LIPID = 512
N_PL = {"astro": 307, "u87": 297}          # phospholipids per bilayer (Table S1)

# ---------------------------------------------------------------- Fig. S2
npz = np.load(os.path.join(HERE, "ws1_scd_profiles.npz"))


def stack(cell, chain):
    arrs = [npz[f"{cell}_rep{i}_{chain}"] for i in (1, 2, 3)]
    n = min(len(a) for a in arrs)
    return np.vstack([a[:n] for a in arrs])


fig, ax = plt.subplots(1, 2, figsize=(11, 4))
for k, (chain, title) in enumerate((("sn1", "POPC sn-1 (16:0)"), ("sn2", "POPC sn-2 (18:1)"))):
    for cell in ("astro", "u87"):
        m = stack(cell, chain)
        mean, sem = m.mean(0), m.std(0, ddof=1) / np.sqrt(m.shape[0])
        x = np.arange(2, 2 + len(mean))
        ax[k].errorbar(x, mean, yerr=sem, color=COLOR[cell], marker=MARK[cell], ms=4,
                       lw=1.3, capsize=2, label=LABEL[cell])
    ax[k].set_title(title, fontsize=10.5)
    ax[k].set_xlabel("carbon number")
    ax[k].set_ylabel(r"$-S_{CD}$")
    ax[k].set_xticks(np.arange(2, 19 if chain == "sn2" else 17, 2))
    ax[k].grid(alpha=0.22, lw=0.6)
    for s in ("top", "right"):
        ax[k].spines[s].set_visible(False)
ax[0].legend(frameon=False, fontsize=9)
fig.tight_layout()
fig.savefig(os.path.join(HERE, "figS2_order.png"), dpi=300)
plt.close(fig)

# ---------------------------------------------------------------- Fig. S3
rows = list(csv.DictReader(open(os.path.join(HERE, "ws1_values.csv"))))
vals = {c: {"apl": [], "atot": [], "thick": []} for c in ("astro", "u87")}
for r in rows:
    c = r["cell"].strip().lower()
    apl = float(r["APL"])
    vals[c]["apl"].append(apl)
    vals[c]["atot"].append(apl * N_PL[c] / N_LIPID)
    vals[c]["thick"].append(float(r["thickness"]))

panels = (("apl", r"area per phospholipid ($\mathrm{\AA^2}$)", "raw area per phospholipid"),
          ("atot", r"area per total lipid ($\mathrm{\AA^2}$)", "cholesterol-corrected area"),
          ("thick", "P–P thickness (nm)", "bilayer thickness"))
fig, ax = plt.subplots(1, 3, figsize=(11, 3.8))
rng = np.random.default_rng(3)
for a, (key, ylab, title) in zip(ax, panels):
    for j, cell in enumerate(("astro", "u87")):
        y = np.array(vals[cell][key])
        a.errorbar(j, y.mean(), yerr=y.std(ddof=1), color=INK, capsize=6, lw=1.4,
                   marker="_", ms=22, mew=1.6, zorder=3)
        a.scatter(j + rng.uniform(-0.07, 0.07, len(y)), y, s=34, color=COLOR[cell],
                  marker=MARK[cell], zorder=4, edgecolor="white", linewidth=0.8)
    p = stats.ttest_ind(vals["astro"][key], vals["u87"][key], equal_var=False).pvalue
    lo = min(min(vals[c][key]) for c in vals)
    hi = max(max(vals[c][key]) for c in vals)
    pad = 0.6 * (hi - lo)
    a.set_ylim(lo - pad, hi + 1.25 * pad)
    a.text(0.5, hi + 0.85 * pad, f"Welch p = {p:.3f}", ha="center", fontsize=8.5, color=INK)
    a.set_xticks([0, 1])
    a.set_xticklabels([LABEL["astro"], LABEL["u87"]])
    a.set_xlim(-0.6, 1.6)
    a.set_ylabel(ylab)
    a.set_title(title, fontsize=10)
    a.grid(axis="y", alpha=0.22, lw=0.6)
    for s in ("top", "right"):
        a.spines[s].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(HERE, "figS3_structure.png"), dpi=300)
plt.close(fig)

for key, _, title in panels:
    a, u = np.array(vals["astro"][key]), np.array(vals["u87"][key])
    p = stats.ttest_ind(a, u, equal_var=False).pvalue
    print(f"{title:<28} astro {a.mean():.3f} ± {a.std(ddof=1):.3f}   "
          f"U87-MG {u.mean():.3f} ± {u.std(ddof=1):.3f}   Welch p = {p:.3f}")
print("Wrote figS2_order.png and figS3_structure.png")
