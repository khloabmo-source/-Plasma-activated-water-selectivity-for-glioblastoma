# Membrane analysis (Figs. S2–S5)

`extract_ws1.py` reads the six production trajectories and writes `ws1_values.csv`
(per replicate, per observable) and `ws1_scd_profiles.npz` (per-carbon order
parameters of POPC). Both derived files are deposited here, so the figures that
depend only on them regenerate without the trajectories. The order-parameter
values in both files are computed over 80–200 ns at 1 ns intervals with
minimum-image C–H vectors; area, thickness and D_lat are at the full 100 ps
frame rate.

Analysis window 80–200 ns (`T_EQUIL_NS = 80.0`); lateral diffusion fitted over
20–80 ns lag (`MSD_FIT_NS = (20.0, 80.0)`).

| script | needs trajectories | output |
|---|---|---|
| `tost_equivalence.py` | no | Fig. S5 |
| `plot_ws1_final.py` | no | Figs. S2, S3 |
| `scd_definition_check.py` | no (optional recompute from exported trajectories) | order-parameter definitions |
| `test_scd.py`, `test_dlat.py` | no | unit tests |
| `extract_ws1.py` | **yes** | regenerates the CSV/NPZ |
| `msd_S4.py`, `plot_msd_S4.py` | **yes** | Fig. S4 |
| `plot_convergence_figS11.py` | no (`box_series/`, `pp_thickness_1ns.csv` are deposited) | Fig. S11 |
| `check_trajectory_provenance.py` | reads box vectors only | production check |
| `ws1_convergence.py` | **yes** | order-parameter and thickness convergence |

## Equilibration

`box_series/box_<replicate>.csv` holds the box lengths of every frame (100 ps) of
the six production runs over 0–200 ns. Each run starts from a configuration
pre-equilibrated at constant area, at about 90 Å² per phospholipid, and the area
relaxes once the lateral box is free. `plot_convergence_figS11.py` locates the
end of that relaxation by automated equilibration detection (Chodera 2016,
J. Chem. Theory Comput. 12, 1799) and tests the 80–200 ns window for a trend on
10 ns block means.

| replicate | equilibration (ns) | trend (Å² per 100 ns) | t |
|---|---|---|---|
| astrocyte 1 | 28 | −0.11 ± 0.17 | −0.6 |
| astrocyte 2 | 24 | +0.16 ± 0.24 | +0.6 |
| astrocyte 3 | — | −0.82 ± 0.26 | −3.1 |
| U87-MG 1 | 32 | +0.23 ± 0.21 | +1.1 |
| U87-MG 2 | 27 | −0.13 ± 0.16 | −0.8 |
| U87-MG 3 | 40 | −0.16 ± 0.23 | −0.7 |

Astrocyte replicate 3 drifts downward over the window and the detection method
finds no early stationary point for it. Restricting all six runs to 140–200 ns
leaves both area comparisons in the same direction and significant: per
phospholipid +2.22% (Welch p = 0.003), per total lipid −1.11% (p = 0.031),
against +2.03% (p = 0.005) and −1.29% (p = 0.014) over 80–200 ns. The script
prints this sensitivity check. The window means reproduce Table S2.

## Composition

Both bilayers contain 512 lipids. The compositions were specified a priori from
the published glioblastoma lipidome and were not adjusted after any result:
205 cholesterol (astrocyte) and 215 (U87-MG), giving 307 and 297 phospholipids
respectively. These counts set the normalisation of the cholesterol-corrected
area below.

## Values

|  | astrocyte | U87-MG | Welch p |
|---|---|---|---|
| −S_CD (glycerophospholipid) | 0.249 ± 0.001 | 0.254 ± 0.003 | 0.106 |
| APL (Å²/phospholipid) | 73.840 ± 0.092 | 75.337 ± 0.260 | 0.005 |
| A per total lipid (Å²) | 44.275 ± 0.055 | 43.701 ± 0.151 | 0.014 |
| P–P thickness (nm) | 4.563 ± 0.006 | 4.581 ± 0.014 | 0.141 |
| D_lat (µm²/s) | 1.797 ± 0.422 | 1.721 ± 0.184 | 0.793 |

The cholesterol-corrected area is derived as APL × N_phospholipid / 512, with
N_phospholipid = 307 (astrocyte) and 297 (U87-MG).

With n = 3 replicates per group a rank test cannot return p < 0.10, so none is
reported.

## The order parameter: minimum image and weighting

The tabulated −S_CD is the time average per acyl carbon, with each C–H vector
taken under the minimum-image convention, averaged over every acyl carbon of
every glycerophospholipid molecule; sphingomyelin and cholesterol are excluded.

**Minimum image.** GROMACS writes molecules broken across the periodic boundary.
In each frame 1.16–1.42% of acyl C–H pairs lie on opposite faces of the box; the
raw difference vector is then of the order of the box length and nearly in the
bilayer plane, contributing about +0.5 whatever the bond's true orientation.
`extract_ws1.py` applies the correction (`_unit_ch`); `test_scd.py` Test E checks
it on a bond split across the boundary.

**Weighting.** Counting every acyl carbon once weights each lipid species by its
abundance. Counting each species' per-carbon profile once gives the 15 POPI
molecules the weight of the 95 POPC; it is not a membrane average and is
reported only for comparison.

| C–H vector | weighting | astrocyte | U87-MG | Welch p |
|---|---|---|---|---|
| minimum image | per acyl carbon (reported) | 0.2490 ± 0.0011 | 0.2537 ± 0.0031 | 0.11 |
| raw | per acyl carbon | 0.2514 ± 0.0011 | 0.2565 ± 0.0031 | 0.09 |
| minimum image | per species | 0.2469 ± 0.0014 | 0.2484 ± 0.0021 | 0.39 |
| raw | per species | 0.2493 ± 0.0014 | 0.2512 ± 0.0020 | 0.25 |

`scd_definitions.csv` holds the per-replicate values; `scd_definition_check.py`
prints this table, and with `--trajectories` recomputes it from the exported
1 ns trajectories. The difference is not significant under any definition, so
chain order is reported as a direction and no conclusion rests on it.

The per-carbon profiles of `ws1_scd_profiles.npz` (Fig. S2) are POPC only and so
lie above the whole-membrane scalar.

## Source of the plotted values

`tost_equivalence.py` reads every observable from `ws1_values.csv`, so the
equivalence figure and the means quoted in the text derive from one source.
Lateral diffusion is taken from the 20–80 ns lag window (`MSD_FIT_NS`), the fit
interval stated in the Methods; narrower windows give a different magnitude and
sign for the astrocyte–U87 difference, so the window must match throughout.
