# -*- coding: utf-8 -*-
# Unit test for the extended extract_ws1.py -S_CD logic. Validates code
# CORRECTNESS (acyl-carbon selection, -S_CD formula, per-segment averaging,
# species exclusion, minimum image) WITHOUT trajectories. It does NOT reproduce 0.249/0.254
# (that requires the archived six 200 ns MD trajectories).
#
#   python3 test_scd.py
import numpy as np, MDAnalysis as mda, warnings
from MDAnalysis.core.topologyattrs import Bonds
warnings.filterwarnings("ignore")

src = open("extract_ws1.py").read()
prefix = src.split("\nrows = []")[0]               # function/constant defs only
ns = {}; exec(compile(prefix, "extract_ws1.py", "exec"), ns)
ACYL_RE = ns["ACYL_RE"]; scd_glycero_mean = ns["scd_glycero_mean"]; GLYCERO_SEL = ns["GLYCERO_SEL"]

print("=== Test A: acyl-carbon selection regex (CHARMM36 names) ===")
names = ["P","N","C1","C2","C3","C11","C12","C13","C14","C15",
         "C21","C31", "C22","C23","C24","C28","C218", "C32","C33","C316"]
sel = [n for n in names if (ACYL_RE.match(n) and int(ACYL_RE.match(n).group(1)) >= 2)]
assert sorted(sel) == sorted(["C22","C23","C24","C28","C218","C32","C33","C316"]), sel
print(f"  selected = {sel}\n  PASS: carbonyls(C21/C31), glycerol(C2/C3), headgroup(C1x) excluded")

print("\n=== Test B: -S_CD formula at known C-H orientations ===")
scd = lambda cz: -(0.5*(3*cz**2 - 1))
for lab, cz, exp in [("along normal cz=1",1.0,-1.0),("perpendicular cz=0",0.0,0.5),
                     ("magic cos^2=1/3",np.sqrt(1/3),0.0)]:
    assert abs(scd(cz)-exp) < 1e-12, lab
    print(f"  {lab:20s}-> -S_CD={scd(cz):+.3f} (expect {exp:+.3f}) OK")

print("\n=== Test C: full scd_glycero_mean on synthetic universe ===")
atom_res = [0]*10 + [1]*7 + [2]*2 + [3]*2
u = mda.Universe.empty(21, n_residues=4, atom_resindex=atom_res,
                       residue_segindex=[0,0,0,0], trajectory=True)
u.add_TopologyAttr("names",
    ["P","C2","C31","C21","C32","H32R","H32S","C22","H22R","H22S",   # res0 POPC
     "C3","C33","H33R","H33S","C23","H23R","H23S",                   # res1 POPE
     "C2S","C3S", "C20","C21"])                                      # res2 PSM, res3 CHL1 (excluded)
u.add_TopologyAttr("resnames", ["POPC","POPE","PSM","CHL1"])
u.add_TopologyAttr("resids", [1,2,3,4])
u.add_TopologyAttr(Bonds([(4,5),(4,6),(7,8),(7,9),(11,12),(11,13),(14,15),(14,16)]))
P = np.zeros((21,3))
P[4]=[4,0,10]; P[5]=[5.09,0,10]; P[6]=[2.91,0,10]      # C32 + H perpendicular to z
P[7]=[6,0,10]; P[8]=[6,1.09,10]; P[9]=[6,-1.09,10]     # C22 + H perpendicular
P[11]=[4,5,10];P[12]=[5.09,5,10];P[13]=[2.91,5,10]     # C33 + H perpendicular
P[14]=[6,5,10];P[15]=[6,6.09,10];P[16]=[6,3.91,10]     # C23 + H perpendicular
P[0]=[0,0,0];P[1]=[1,0,0];P[2]=[2,0,0];P[3]=[3,0,0];P[10]=[0,5,0]
P[17]=[0,9,0];P[18]=[1,9,0];P[19]=[0,15,0];P[20]=[1,15,0]
u.atoms.positions = P
ns["T_EQUIL_NS"] = 0.0
val, nacyl = scd_glycero_mean(u, u.select_atoms(GLYCERO_SEL))
assert nacyl == 4 and abs(val - 0.5) < 1e-9, (nacyl, val)
print(f"  acyl carbons = {nacyl} (expect 4); mean -S_CD = {val:+.4f} (expect +0.5000)")
print("  PASS: PSM & CHL1 excluded; carbonyls/glycerol/P excluded; averaging correct")

print("\n=== Test D: plateau vs all-chain mean (physical relationship) ===")
prof = dict(zip([f"C3{i}" for i in range(2,17)],
        [0.34,0.355,0.358,0.357,0.356,0.353,0.34,0.31,0.27,0.22,0.17,0.12,0.07,0.03,0.015]))
plateau = np.mean([prof[f"C3{i}"] for i in range(4,9)]); allmean = np.mean(list(prof.values()))
assert allmean < plateau
print(f"  plateau(C34-C38)={plateau:.3f}  all-carbon mean={allmean:.3f}  ratio={allmean/plateau:.3f}")
print("  PASS: full-chain mean necessarily < head-proximal plateau")
print(f"        consistent with the reported mean 0.249/0.254 vs plateau 0.357/0.365")

print("\n=== Test E: C-H vector split across the periodic boundary ===")
_unit_ch = ns["_unit_ch"]
v = mda.Universe.empty(4, trajectory=True)
v.dimensions = [50.0, 50.0, 80.0, 90.0, 90.0, 90.0]
# the same tilted bond, (-0.80, 0, +0.75) A, once intact and once split across x = 0
v.atoms.positions = np.array([[25.0, 10.0, 40.0], [24.2, 10.0, 40.75],
                              [0.3, 10.0, 40.0], [49.5, 10.0, 40.75]])
cz = _unit_ch(v, np.array([0, 2]), np.array([1, 3]))[:, 2]
raw = v.atoms.positions[3] - v.atoms.positions[2]
cz_raw = raw[2] / np.linalg.norm(raw)
expect = 0.75 / np.hypot(0.80, 0.75)
assert abs(cz[0] - expect) < 1e-6 and abs(cz[1] - expect) < 1e-6, cz
assert abs(cz_raw - expect) > 0.6, cz_raw
print(f"  intact cz = {cz[0]:.3f}; split, corrected cz = {cz[1]:.3f}; split, raw cz = {cz_raw:.3f}")
print(f"  -S_CD: true {-(0.5*(3*expect**2-1)):+.3f}, raw split {-(0.5*(3*cz_raw**2-1)):+.3f}")
print("  PASS: the corrected vector equals the intact one; the raw one is nearly in-plane")

print("\nALL UNIT TESTS PASSED")
