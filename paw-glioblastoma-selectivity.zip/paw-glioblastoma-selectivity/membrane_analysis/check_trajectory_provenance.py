#!/usr/bin/env python3
"""Check that a trajectory matches the production settings of prod_npt.mdp.

Reads only the box vectors, so it needs no topology and no GROMACS install,
and runs in seconds on a multi-gigabyte file.

Two things are checked, and both are decisive on their own:

  1. The lateral box must fluctuate. Production used semi-isotropic NPT with
     compressibility 4.5e-5 in both directions, so Lx varies from frame to
     frame. A trajectory in which Lx takes a single value was run with the
     lateral compressibility set to zero (constant area, NPAT) and is not
     production.

  2. Over the 80-200 ns analysis window, the area per phospholipid must match
     the reported value: 73.8 A^2 (astrocyte) and 75.3 A^2 (U87-MG). Frames
     before 80 ns are not judged on area, because each run starts from a
     configuration pre-equilibrated at constant area and the area relaxes over
     the first 24-40 ns; a part file from that stretch lies several percent
     above the reported value and is still production.

Usage:
    python3 check_trajectory_provenance.py astro file1.xtc [file2.xtc ...]
    python3 check_trajectory_provenance.py u87   file1.xtc [file2.xtc ...]
"""
import sys
import numpy as np

try:
    from MDAnalysis.coordinates.XTC import XTCReader
except ImportError:
    sys.exit("MDAnalysis is required: pip install MDAnalysis")

# Table S1 composition and the reported areas of Fig. S3.
SYSTEM = {
    "astro": {"n_chol": 205, "apl": 73.84, "label": "astrocyte"},
    "u87": {"n_chol": 215, "apl": 75.34, "label": "U87-MG"},
}
N_LIPID = 512
WINDOW = (80.0, 200.0)   # the analysis window of the Methods, in ns
TOL = 0.05               # fractional tolerance on the area


def check(cell, path):
    spec = SYSTEM[cell]
    n_pl_per_leaflet = (N_LIPID - spec["n_chol"]) / 2
    r = XTCReader(path)
    t, lx, ly = [], [], []
    for ts in r:
        d = ts.dimensions
        t.append(ts.time / 1000.0)
        lx.append(d[0])
        ly.append(d[1])
    t, lx, ly = np.array(t), np.array(lx), np.array(ly)
    apl = (lx * ly) / n_pl_per_leaflet

    # float32 storage means an exactly constant box still shows ~1e-5 scatter
    frozen = lx.std() / lx.mean() < 1e-6
    in_win = (t >= WINDOW[0]) & (t <= WINDOW[1])
    dev = apl[in_win].mean() / spec["apl"] - 1.0 if in_win.any() else None
    covers = t[-1] >= WINDOW[0]

    print(f"\n{path}")
    print(f"  frames {len(t)}   time {t[0]:.1f} - {t[-1]:.1f} ns   dt {(t[1]-t[0])*1000:.0f} ps")
    print(f"  Lx {lx.mean():.2f} A (sd {lx.std():.4f})   "
          f"area per phospholipid {apl.mean():.1f} A^2")
    ok = True
    if frozen:
        print("  FAIL  lateral box is constant -> run under fixed area (NPAT), not production")
        ok = False
    else:
        print("  ok    lateral box fluctuates, consistent with tensionless NPT")
    if dev is None:
        why = ("held fixed by the barostat" if frozen
               else "the area is still relaxing before 80 ns")
        print(f"  note  no frames in the {WINDOW[0]:.0f}-{WINDOW[1]:.0f} ns window; area "
              f"{apl.mean():.1f} A^2 ({apl.mean()/spec['apl']-1:+.1%}) not judged: {why}")
    elif abs(dev) > TOL:
        print(f"  FAIL  area over the window is {dev:+.1%} against the reported "
              f"{spec['apl']:.1f} A^2 for the {spec['label']} system")
        ok = False
    else:
        print(f"  ok    area over the window within {dev:+.1%} of the reported {spec['apl']:.1f} A^2")
    if not covers:
        print(f"  note  ends at {t[-1]:.0f} ns, before the analysis window; later parts carry it")
    return ok


def main():
    if len(sys.argv) < 3 or sys.argv[1] not in SYSTEM:
        sys.exit(__doc__)
    cell = sys.argv[1]
    results = [check(cell, p) for p in sys.argv[2:]]
    print(f"\n{sum(results)} of {len(results)} file(s) consistent with production.")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
