#!/usr/bin/env python3
"""How the mean order parameter depends on its definition.

Two choices are embedded in a single mean -S_CD over a mixed bilayer:

  * weighting: every acyl carbon of every glycerophospholipid molecule counts
    once (the reported convention, abundance-weighted), or each lipid species'
    per-carbon profile counts once regardless of how many molecules of that
    species the membrane holds (species-weighted);
  * the C-H vector: taken as the raw coordinate difference, or under the
    minimum-image convention. GROMACS writes molecules broken across the
    periodic boundary, and a C-H pair split across a lateral face gives a vector
    of order the box length lying almost in the bilayer plane, which adds about
    +0.5 to -S_CD for that bond. Only the minimum-image value is physical.

scd_definitions.csv holds all four combinations per replicate, computed over
80-200 ns at 1 ns intervals (121 frames) from the production trajectories. This
script prints the group comparison for each. With --trajectories DIR it first
recomputes the table from exported trajectories (<cell>_rep<n>_1ns.xtc and
<cell>_lipids.pdb, as written by export_production_trajectories.ipynb).

    python3 scd_definition_check.py
    python3 scd_definition_check.py --trajectories export_for_analysis/
"""
import os
import re
import sys
import csv
import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
TABLE = os.path.join(HERE, "scd_definitions.csv")
GPL = ["POPC", "DOPC", "POPE", "DOPE", "POPI", "POPS"]
ACYL = re.compile(r"^C([23])(\d+)$")
T0_NS = 80.0
COLUMNS = (("per_segment", "per segment, minimum image (reported)"),
           ("per_segment_uncorrected", "per segment, raw C-H vector"),
           ("per_species", "per species, minimum image"),
           ("per_species_uncorrected", "per species, raw C-H vector"))


def recompute(d):
    import warnings
    warnings.filterwarnings("ignore")
    import MDAnalysis as mda
    from MDAnalysis.lib.distances import minimize_vectors
    rows = []
    for cell in ("astro", "u87"):
        for rep in (1, 2, 3):
            u = mda.Universe(os.path.join(d, f"{cell}_lipids.pdb"),
                             os.path.join(d, f"{cell}_rep{rep}_1ns.xtc"))
            ci, hi, atom, species = [], [], [], []
            for c in u.select_atoms("resname " + " ".join(GPL)).atoms:
                m = ACYL.match(c.name)
                if not m or int(m.group(2)) < 2:
                    continue
                for h in c.bonded_atoms:
                    if h.name.startswith("H"):
                        ci.append(c.index); hi.append(h.index); atom.append(c.index)
                        species.append((c.resname, m.group(1), c.name))
            ci, hi, atom = np.array(ci), np.array(hi), np.array(atom)
            labels = sorted(set(species))
            sp = np.array([labels.index(k) for k in species])
            raw, mic, nf, split = np.zeros(len(ci)), np.zeros(len(ci)), 0, 0
            for ts in u.trajectory:
                if ts.time / 1000.0 < T0_NS:
                    continue
                v = u.atoms.positions[hi] - u.atoms.positions[ci]
                n = np.linalg.norm(v, axis=1)
                split += int((n > 2.0).sum())
                raw += 0.5 * (3 * (v[:, 2] / n) ** 2 - 1)
                vm = minimize_vectors(v, box=ts.dimensions)
                mic += 0.5 * (3 * (vm[:, 2] / np.linalg.norm(vm, axis=1)) ** 2 - 1)
                nf += 1

            def seg(acc):
                s = -acc / nf
                return np.mean([s[atom == k].mean() for k in np.unique(atom)])

            def spc(acc):
                s = -acc / nf
                return np.mean([s[sp == k].mean() for k in range(len(labels))])

            rows.append([cell, rep, f"{seg(raw):.4f}", f"{seg(mic):.4f}",
                         f"{spc(raw):.4f}", f"{spc(mic):.4f}", f"{split / (nf * len(ci)):.4f}"])
            print(f"  {cell}_rep{rep}: {nf} frames", flush=True)
    with open(TABLE, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["cell", "rep", "per_segment_uncorrected", "per_segment",
                    "per_species_uncorrected", "per_species", "split_CH_fraction"])
        w.writerows(rows)


def main():
    if "--trajectories" in sys.argv:
        recompute(sys.argv[sys.argv.index("--trajectories") + 1])
    rows = list(csv.DictReader(open(TABLE)))
    print(f"{'definition':<40}{'astrocyte':>18}{'U87-MG':>18}{'diff':>8}{'Welch p':>9}  ranges")
    for col, name in COLUMNS:
        a = np.array([float(r[col]) for r in rows if r["cell"] == "astro"])
        u = np.array([float(r[col]) for r in rows if r["cell"] == "u87"])
        p = stats.ttest_ind(a, u, equal_var=False).pvalue
        sep = "overlap" if a.max() >= u.min() else f"separate by {u.min() - a.max():.4f}"
        print(f"{name:<40}{a.mean():9.4f} ± {a.std(ddof=1):.4f}{u.mean():9.4f} ± {u.std(ddof=1):.4f}"
              f"{100 * (u.mean() / a.mean() - 1):+7.2f}%{p:9.3f}  {sep}")
    f = [float(r["split_CH_fraction"]) for r in rows]
    art = [float(r["per_segment_uncorrected"]) - float(r["per_segment"]) for r in rows]
    print(f"\nC-H vectors split across the periodic boundary: {100 * min(f):.2f}-{100 * max(f):.2f}% "
          f"per frame; effect on the per-segment mean +{min(art):.4f} to +{max(art):.4f}")


if __name__ == "__main__":
    main()
