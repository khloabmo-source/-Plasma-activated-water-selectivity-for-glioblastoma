#!/usr/bin/env python3
# ======================================================================
# tost_equivalence.py  ->  Fig. S5
#
# Two one-sided tests (TOST) for equivalence of the membrane observables
# between the astrocyte-like and U87-MG-like bilayers.
#
# All observables are read from ws1_values.csv, the output of extract_ws1.py,
# so that the figure and the reported means derive from one source. Lateral
# diffusion is taken from the 20-80 ns lag window (MSD_FIT_NS in extract_ws1.py),
# matching the fit interval stated in the Methods.
#
# The cholesterol-corrected area per total lipid is derived from the raw area
# per phospholipid as  A_total = APL * N_phospholipid / 512, with
# N_phospholipid = 512 - N_cholesterol (307 astrocyte, 297 U87-MG).
#
# Deps: numpy, scipy, matplotlib      Run: python3 tost_equivalence.py
# ======================================================================
import csv
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
CSV = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "ws1_values.csv")
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "figures")
os.makedirs(OUT, exist_ok=True)

N_CHOL = {"astro": 205, "u87": 215}
N_TOTAL = 512
N_PL = {c: N_TOTAL - n for c, n in N_CHOL.items()}

rows = list(csv.DictReader(open(CSV)))
col = lambda cell, key: np.array([float(r[key]) for r in rows if r["cell"] == cell])

OBS = [
    ("-S_CD (glycerophospholipid)", lambda c: col(c, "SCD_glycero")),
    ("P-P thickness (nm)",          lambda c: col(c, "thickness")),
    ("APL (A^2 / phospholipid)",    lambda c: col(c, "APL")),
    ("A per total lipid (A^2)",     lambda c: col(c, "APL") * N_PL[c] / N_TOTAL),
    ("D_lat (um^2/s)",              lambda c: col(c, "Dlat")),
]


def welch_ci(a, b, conf=0.90):
    """Difference (b - a) with a two-sided Welch CI and p-value."""
    ma, mb = a.mean(), b.mean()
    sa, sb = a.std(ddof=1), b.std(ddof=1)
    na, nb = len(a), len(b)
    se = np.sqrt(sa ** 2 / na + sb ** 2 / nb)
    df = se ** 4 / ((sa ** 2 / na) ** 2 / (na - 1) + (sb ** 2 / nb) ** 2 / (nb - 1))
    tc = stats.t.ppf(1 - (1 - conf) / 2, df)
    d = mb - ma
    p = 2 * stats.t.sf(abs(d / se), df)
    return ma, mb, d, d - tc * se, d + tc * se, p


print(f"TOST equivalence, n = 3 replicates per composition   (source: {os.path.basename(CSV)})\n")
hdr = f"{'observable':30s}{'astro':>9s}{'U87':>9s}{'diff %':>9s}{'90% CI (%)':>18s}{'Welch p':>9s}   +-5% / +-10%"
print(hdr)
print("-" * len(hdr))

res = []
for label, getter in OBS:
    a, b = getter("astro"), getter("u87")
    ma, mb, d, lo, hi, p = welch_ci(a, b)
    gm = (ma + mb) / 2
    e5 = "pass" if (lo > -0.05 * gm and hi < 0.05 * gm) else "fail"
    e10 = "pass" if (lo > -0.10 * gm and hi < 0.10 * gm) else "fail"
    print(f"{label:30s}{ma:9.3f}{mb:9.3f}{100*d/gm:+9.2f}"
          f"{f'[{100*lo/gm:+.1f}, {100*hi/gm:+.1f}]':>18s}{p:9.3f}   {e5} / {e10}")
    res.append((label, 100 * d / gm, 100 * lo / gm, 100 * hi / gm, p))

print("\nInterpretation: where a difference is resolvable it is small (<= 3%) and in the")
print("direction that LOWERS U87-MG permeability (more ordered, more condensed) - the")
print("opposite of what a permeability-based selectivity mechanism requires.")
print("D_lat shows no significant difference but is the least tightly bounded observable")
print("at n = 3, and is not contained within the +-10% equivalence margin.")

fig, ax = plt.subplots(figsize=(7.8, 3.9))
y = np.arange(len(res))[::-1]
for yi, (lab, pc, lo, hi, _) in zip(y, res):
    ax.errorbar(pc, yi, xerr=[[pc - lo], [hi - pc]], fmt="o",
                color="tab:blue", capsize=4, ms=7)
ax.axvspan(-10, 10, color="green", alpha=0.10, label="$\\pm$10% equivalence")
ax.axvspan(-5, 5, color="green", alpha=0.20, label="$\\pm$5% equivalence")
ax.axvline(0, color="k", lw=0.8)
ax.set_yticks(y)
ax.set_yticklabels([r[0] for r in res], fontsize=8.5)
ax.set_xlabel("difference (U87-MG $-$ astrocyte), % of grand mean")
ax.set_title("Membrane equivalence (TOST), n = 3 replicates per composition\n"
             "all observables from ws1_values.csv", fontsize=10)
ax.legend(fontsize=8, loc="lower right")
ax.set_xlim(-45, 45)
fig.tight_layout()
dest = os.path.join(OUT, "figS5_tost_equivalence.png")
fig.savefig(dest, dpi=200)
print(f"\nSaved {dest}")
