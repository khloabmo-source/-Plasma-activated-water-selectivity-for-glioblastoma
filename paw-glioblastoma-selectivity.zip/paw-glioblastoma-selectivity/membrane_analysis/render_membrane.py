#!/usr/bin/env python3
# ======================================================================
# render_membrane.py  --  Figure S0: side-view cross-section of the two
# plasma-membrane models (astrocyte vs U87-MG), coloured by lipid type.
# Reliable (MDAnalysis + matplotlib, no PyMOL/VMD install). Uses the
# single-frame ws1_top.gro already in each rundir.
#   python3 render_membrane.py   ->  figS0_membranes.png
# ======================================================================
import os
os.environ["MPLBACKEND"] = "Agg"
import glob, numpy as np
import matplotlib, matplotlib.pyplot as plt
from matplotlib.patches import Patch
import MDAnalysis as mda

BASE_DIR = "/content/drive/MyDrive/gbm_md/run_hmr/multidir"
REPS = {"astrocyte": "astro_rep1", "U87-MG": "u87_rep1"}
SLAB = 12.0   # Angstrom: thickness of the y-slab shown, to avoid overlap

# lipid -> colour
COL = {"CHL1": "#F4A261", "PSM": "#E9C46A", "POPC": "#2A6F97", "DOPC": "#48CAE4",
       "POPE": "#E76F51", "DOPE": "#F4978E", "POPS": "#9D4EDD", "POPI": "#52B788"}
LABEL = {"CHL1": "cholesterol", "PSM": "sphingomyelin", "POPC": "POPC", "DOPC": "DOPC",
         "POPE": "POPE", "DOPE": "DOPE", "POPS": "POPS", "POPI": "POPI"}

def topfile(d):
    g = sorted(glob.glob(f"{d}/*.gro"), key=os.path.getsize)
    return g[-1] if g else None

fig, axes = plt.subplots(1, 2, figsize=(13, 5.6), sharey=True)
for ax, (title, rd) in zip(axes, REPS.items()):
    d = os.path.join(BASE_DIR, rd)
    u = mda.Universe(topfile(d))
    lip = u.select_atoms("not resname TIP3 POT CLA SOD CL NA K")
    yc = lip.positions[:, 1].mean()
    slab = lip[np.abs(lip.positions[:, 1] - yc) < SLAB]
    for resn, col in COL.items():
        ag = slab.select_atoms(f"resname {resn}")
        if len(ag):
            p = ag.positions
            ax.scatter(p[:, 0]/10, p[:, 2]/10, s=2, c=col, alpha=0.7, linewidths=0, rasterized=True)
    P = slab.select_atoms("name P")
    if len(P):
        ax.scatter(P.positions[:, 0]/10, P.positions[:, 2]/10, s=14, c="k", marker="o",
                   label="phosphate", zorder=5)
    ax.set_title(title); ax.set_xlabel("x (nm)")
    ax.set_aspect("equal", adjustable="box")
axes[0].set_ylabel("z — membrane normal (nm)")
handles = [Patch(color=c, label=LABEL[r]) for r, c in COL.items()]
fig.legend(handles=handles, loc="lower center", ncol=8, frameon=False, fontsize=9, bbox_to_anchor=(0.5, -0.02))
plt.tight_layout(rect=[0, 0.04, 1, 1])
plt.savefig("figS0_membranes.png", dpi=200, bbox_inches="tight")
print("Wrote figS0_membranes.png")
