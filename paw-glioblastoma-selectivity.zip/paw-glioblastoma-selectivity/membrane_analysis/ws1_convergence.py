#!/usr/bin/env python3
# ======================================================================
# ws1_convergence.py  --  generate Figure S4: equilibration & convergence
# of the membrane observables over the full 0-200 ns, per replicate.
# Shows the systems plateau before the 80 ns analysis window and stay
# stable to 200 ns, establishing that the 80-200 ns analysis window is equilibrated.
#
#   python3 ws1_convergence.py     ->  figS4_convergence.png
#
# Reuses the same robust IO as extract_ws1.py (gro topology fallback for
# tpx 138, concatenated .part xtc, name-based C-H fallback).
# ======================================================================

import os
os.environ["MPLBACKEND"] = "Agg"          # set before importing matplotlib (Colab inline-backend clash)
import glob, re, numpy as np
import matplotlib
import matplotlib.pyplot as plt
import MDAnalysis as mda

RUNDIRS   = {"astro": [f"astro_rep{i}" for i in (1, 2, 3)],
             "u87":   [f"u87_rep{i}"   for i in (1, 2, 3)]}
BASE_DIR  = "/content/drive/MyDrive/gbm_md/run_hmr/multidir"
POPC_RES  = "resname POPC"
PHOS_SEL  = "name P"
SN1_PLATEAU = [f"C3{i}" for i in range(4, 9)]   # sn-1 palmitoyl plateau carbons (C34..C38) for -S_CD
T_EQUIL_NS  = 80.0
BLOCK_NS    = 4.0                                # block size for the running average
TEAL, RED   = "#2A9D8F", "#E63946"

def part_key(f):
    m = re.search(r"part(\d+)", os.path.basename(f)); return int(m.group(1)) if m else 0

def find_inputs(d):
    xtcs = glob.glob(f"{d}/*.xtc")
    if not xtcs: return None, None
    fams = {}
    for f in xtcs:
        pre = re.sub(r"\.part\d+", "", os.path.basename(f)).replace(".xtc", "")
        fams.setdefault(pre, []).append(f)
    pre = max(fams, key=lambda k: sum(os.path.getsize(x) for x in fams[k]))
    parts = sorted(fams[pre], key=part_key)
    tops = sorted(glob.glob(f"{d}/*.gro")) + sorted(glob.glob(f"{d}/*.pdb"))
    tprs = sorted(glob.glob(f"{d}/*.tpr"))
    return (tprs[0] if tprs else None, max(tops, key=os.path.getsize) if tops else None), parts

def universe(tops, parts):
    for top in tops:
        if not top: continue
        try:
            u = mda.Universe(top, parts); return u, top.endswith((".gro", ".pdb"))
        except Exception:
            continue
    raise RuntimeError("no readable topology")

def ch_pairs(popc, names):
    ci, hi = [], []
    for cname in names:
        pos = cname[2:]
        for c in popc.select_atoms("name " + cname):
            hs = [h for h in c.bonded_atoms if h.name.startswith("H")] or \
                 list(c.residue.atoms.select_atoms(f"name H{pos}R H{pos}S H{pos}T"))
            for h in hs:
                ci.append(c.index); hi.append(h.index)
    return np.array(ci, int), np.array(hi, int)

def series(d):
    (tpr, gro), parts = find_inputs(d)
    u, guessed = universe([tpr, gro], parts)
    popc = u.select_atoms(POPC_RES)
    if guessed:
        try: popc.guess_bonds()
        except Exception: pass
    ci, hi = ch_pairs(popc, SN1_PLATEAU)
    phos = u.select_atoms(PHOS_SEL); n_leaf = len(phos) / 2.0
    t, scd, apl, th = [], [], [], []
    for ts in u.trajectory:
        v = u.atoms.positions[hi] - u.atoms.positions[ci]
        cz = v[:, 2] / np.linalg.norm(v, axis=1)
        t.append(ts.time / 1000.0)
        scd.append(-(0.5 * (3 * cz**2 - 1)).mean())
        apl.append(ts.dimensions[0] * ts.dimensions[1] / n_leaf)
        z = phos.positions[:, 2]; c = z.mean()
        th.append((z[z > c].mean() - z[z < c].mean()) / 10.0)
    return np.array(t), np.array(scd), np.array(apl), np.array(th)

def block(t, y, bw):
    edges = np.arange(0, t.max() + bw, bw)
    idx = np.digitize(t, edges)
    tb = np.array([t[idx == k].mean() for k in range(1, len(edges)) if (idx == k).any()])
    yb = np.array([y[idx == k].mean() for k in range(1, len(edges)) if (idx == k).any()])
    return tb, yb

data = {}
for cell, dirs in RUNDIRS.items():
    for i, d in enumerate(dirs, 1):
        p = os.path.join(BASE_DIR, d)
        try:
            t, scd, apl, th = series(p)
            data[(cell, i)] = (block(t, scd, BLOCK_NS), block(t, apl, BLOCK_NS), block(t, th, BLOCK_NS))
            print(f"  {d}: {len(t)} frames, {t.max():.0f} ns")
        except Exception as e:
            print(f"  {d}: FAILED -> {str(e).splitlines()[0]}")

obs = [("-S_CD (plateau)", 0, ""), ("Area / phospholipid (Å²)", 1, ""), ("P–P thickness (nm)", 2, "")]
fig, axes = plt.subplots(1, 3, figsize=(13, 3.6))
for ax, (ylab, j, _) in zip(axes, obs):
    for (cell, i), series_tuple in data.items():
        tb, yb = series_tuple[j]
        ax.plot(tb, yb, color=(TEAL if cell == "astro" else RED), alpha=0.8, lw=1.3,
                label=cell if i == 1 else None)
    ax.axvspan(0, T_EQUIL_NS, color="0.85", alpha=0.5)
    ax.axvline(T_EQUIL_NS, color="0.4", ls="--", lw=1)
    ax.set_xlabel("time (ns)"); ax.set_ylabel(ylab)
    if j == 0:
        ax.legend(frameon=False, fontsize=9)
axes[1].set_title("equilibration: grey = discarded 0–80 ns; analysis window 80–200 ns")
plt.tight_layout(); plt.savefig("figS4_convergence.png", dpi=200)
print("\nWrote figS4_convergence.png")
