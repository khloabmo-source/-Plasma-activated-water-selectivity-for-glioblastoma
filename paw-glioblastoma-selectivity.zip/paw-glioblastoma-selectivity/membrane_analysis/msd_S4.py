# -*- coding: utf-8 -*-
"""
msd_S4.py  —  Produce Fig. S4 (centre-of-mass-removed lateral MSD curves).

extract_ws1.py computes D_lat from the MSD but keeps only the scalar; this script
reuses extract_ws1's VALIDATED trajectory-loading (find_inputs / build_universe /
RUNDIRS) and re-computes the *full* per-replicate MSD(lag) with the identical
per-leaflet-COM-removal + PBC-unwrap used for D_lat, then:
  1. saves the arrays to  msd_S4.npz   (per replicate: t_ns, msd_A2)
  2. writes the figure     figS4_lateral_msd.png   (6 curves, 20-80 ns fit window shaded)

The curves are the honest substitute for the per-replicate D_lat bar chart: they
let the reader SEE the sub-diffusivity (log-log slope ~0.6) that the manuscript
reports. Run in the same environment as extract_ws1 (Colab, Drive mounted):

    python3 msd_S4.py

No trajectories are fabricated; if a replicate is missing it is skipped and noted.
"""
import os, numpy as np

# ---- reuse extract_ws1's functions/constants WITHOUT running its main loop ----
_src = open("extract_ws1.py", encoding="utf-8").read().split("\nrows = []")[0]
_ns = {}
exec(compile(_src, "extract_ws1.py", "exec"), _ns)
find_inputs    = _ns["find_inputs"]
build_universe = _ns["build_universe"]
RUNDIRS        = _ns["RUNDIRS"]
BASE_DIR       = _ns["BASE_DIR"]
PHOS_SEL       = _ns["PHOS_SEL"]
T_EQUIL_NS     = _ns["T_EQUIL_NS"]
MSD_FIT_NS     = _ns["MSD_FIT_NS"]


def msd_com_removed(u):
    """Full MSD(lag) of phosphate atoms, per-leaflet-COM-removed and PBC-unwrapped
    — byte-for-byte the same accumulation used inside extract_ws1.lateral_D, but
    returning (t_ns, msd_A2) instead of the fitted scalar."""
    phos = u.select_atoms(PHOS_SEL); n = len(phos)
    u.trajectory[0]
    upper = phos.positions[:, 2] > phos.positions[:, 2].mean()
    prev = None; cum = np.zeros((n, 2)); times = []; traj = []
    for ts in u.trajectory:
        xy = phos.positions[:, :2].copy(); box = ts.dimensions[:2]
        if prev is not None:
            step = xy - prev; step -= box * np.round(step / box)
            cum += step
        prev = xy
        if ts.time / 1000.0 + 1e-9 < T_EQUIL_NS:
            continue
        rel = cum.copy()
        rel[upper]  -= rel[upper].mean(axis=0)
        rel[~upper] -= rel[~upper].mean(axis=0)
        times.append(ts.time / 1000.0); traj.append(rel)
    if len(times) < 5:
        return None, None
    times = np.asarray(times); times -= times[0]; traj = np.asarray(traj)
    nf = len(times); msd = np.zeros(nf)
    for lag in range(1, nf):
        d = traj[lag:] - traj[:-lag]; msd[lag] = (d * d).sum(axis=2).mean()
    return times, msd


def main():
    store = {}
    for cell, dirs in RUNDIRS.items():
        for i, d in enumerate(dirs, start=1):
            path = os.path.join(BASE_DIR, d)
            if not os.path.isdir(path):
                print(f"  {d}: rundir not found — skipped"); continue
            tpr, gro, parts = find_inputs(path)
            if not parts:
                print(f"  {d}: no .xtc — skipped"); continue
            u, _top, _g = build_universe(tpr, gro, parts)
            t, msd = msd_com_removed(u)
            if t is None:
                print(f"  {d}: <5 frames after equilibration — skipped"); continue
            i0 = np.searchsorted(t, MSD_FIT_NS[0]); i1 = max(np.searchsorted(t, MSD_FIT_NS[1]), i0 + 2)
            slope = np.polyfit(t[i0:i1], msd[i0:i1], 1)[0]
            ll = np.polyfit(np.log(t[i0:i1]), np.log(msd[i0:i1]), 1)[0]
            store[f"{cell}_rep{i}_t"]   = t
            store[f"{cell}_rep{i}_msd"] = msd
            print(f"  {cell}_rep{i}: {len(t)} frames  D_lat={slope/4*10:.3f} um^2/s  "
                  f"log-log slope={ll:.2f} (Fickian~1.0)")
    if not store:
        print("No replicates read — nothing written."); return
    np.savez("msd_S4.npz", **store)
    print("wrote msd_S4.npz")

    os.environ["MPLBACKEND"]="Agg"; import matplotlib; import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6.0, 4.2), dpi=200)
    col = {"astro": "#2ca02c", "u87": "#d62728"}
    for k in sorted(store):
        if not k.endswith("_t"):
            continue
        base = k[:-2]; cell = base.split("_")[0]
        t = store[base + "_t"]; msd = store[base + "_msd"]
        ax.plot(t, msd, color=col.get(cell, "grey"), lw=1.3, alpha=0.9,
                label=base.replace("_", " "))
    ax.axvspan(MSD_FIT_NS[0], MSD_FIT_NS[1], color="0.85", alpha=0.5, label="fit window")
    ax.set_xlabel("lag (ns)"); ax.set_ylabel(r"lateral MSD ($\mathrm{\AA}^2$)")
    ax.set_title("Lateral MSD (centre-of-mass-removed)")
    ax.legend(fontsize=7, ncol=2)
    plt.tight_layout(); plt.savefig("figS4_lateral_msd.png", bbox_inches="tight")
    print("wrote figS4_lateral_msd.png")


if __name__ == "__main__":
    main()
