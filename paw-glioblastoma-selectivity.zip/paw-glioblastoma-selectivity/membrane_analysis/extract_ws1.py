#!/usr/bin/env python3
# ======================================================================
# extract_ws1.py  --  read the six completed 200 ns trajectories and write
# ws1_values.csv (+ ws1_scd_profiles.npz) for ws1_analysis.py.
#
#   python3 extract_ws1.py
#
# Handles:
#   * GROMACS 2025 .tpr (tpx 138) that MDAnalysis can't parse -> reads a
#     .gro/.pdb for topology and guesses C-H bonds on the phospholipids only.
#   * production trajectory split into .partNNNN.xtc chunks -> loads ALL
#     parts of the production family as one continuous trajectory.
#   * window selected by TIME (>= 80 ns), robust to chunk boundaries.
#
# -S_CD SUMMARIES (both reported per replicate):
#   * SCD_plateau  : POPC sn-1 (palmitoyl) plateau, carbons C34-C38. This is
#                    the high-order head-proximal value (~0.357) used as a
#                    regression check against the archived scd_plateau_values.csv.
#   * SCD_glycero  : MANUSCRIPT VALUE. Mean -S_CD over *all glycerophospholipid*
#                    acyl segments (both chains, every methylene/methyl carbon),
#                    averaged over chains and frames, with sphingomyelin (PSM)
#                    and cholesterol (CHL1) excluded. This is the 0.249 / 0.254
#                    reported in the paper (Methods: "mean glycerophospholipid
#                    carbon-deuterium order parameter ... averaged over chains
#                    and frames"). The full-chain mean is necessarily lower than
#                    the head-proximal plateau because the disordered chain-end
#                    carbons are included.
# ======================================================================

import os, csv, glob, re, numpy as np
import MDAnalysis as mda
from MDAnalysis.lib.distances import minimize_vectors

# ----------------------------- CONFIG ---------------------------------
RUNDIRS   = {"astro": [f"astro_rep{i}" for i in (1, 2, 3)],
             "u87":   [f"u87_rep{i}"   for i in (1, 2, 3)]}
BASE_DIR  = "/content/drive/MyDrive/gbm_md/run_hmr/multidir"
POPC_RES  = "resname POPC"
PHOS_SEL  = "name P"

# Glycerophospholipid classes of the model plasma membrane (manuscript inventory:
# PC, PE, PI, PS in mono- and di-unsaturated forms). Sphingomyelin (PSM, a
# sphingolipid) and cholesterol (CHL1) are NOT glycerophospholipids and are
# excluded, matching the paper's "with sphingomyelin treated separately".
GLYCERO_RESNAMES = ["POPC", "DOPC", "POPE", "DOPE", "POPI", "POPS"]
GLYCERO_SEL = "resname " + " ".join(GLYCERO_RESNAMES)
# Acyl carbons in CHARMM36 are named C3<n> (sn-1) and C2<n> (sn-2) with n>=2;
# n==1 is the ester carbonyl (C31/C21) and bare C2/C3 are glycerol backbone.
ACYL_RE = re.compile(r"^C[23](\d+)$")

SN1_CARB  = [f"C3{i}" for i in range(2, 17)]   # CHARMM36 sn-1 PALMITOYL (16:0): C32..C316
SN2_CARB  = [f"C2{i}" for i in range(2, 19)]   # CHARMM36 sn-2 OLEOYL   (18:1): C22..C218
SN1_PLATEAU = [f"C3{i}" for i in range(4, 9)]  # palmitoyl plateau carbons for scalar -S_CD
T_EQUIL_NS  = 80.0
MSD_FIT_NS  = (20.0, 80.0)   # Fickian-ish fit window (ns); MSD is sub-diffusive on this timescale (log-log ~0.6)

def part_key(f):
    m = re.search(r"part(\d+)", os.path.basename(f))
    return int(m.group(1)) if m else 0

def find_inputs(d):
    xtcs = glob.glob(f"{d}/*.xtc")
    if not xtcs:
        return None, None, None
    fams = {}
    for f in xtcs:
        pre = re.sub(r"\.part\d+", "", os.path.basename(f)).replace(".xtc", "")
        fams.setdefault(pre, []).append(f)
    pre = max(fams, key=lambda k: sum(os.path.getsize(x) for x in fams[k]))
    parts = sorted(fams[pre], key=part_key)
    tprs = sorted(glob.glob(f"{d}/*.tpr"))
    tops = sorted(glob.glob(f"{d}/*.gro")) + sorted(glob.glob(f"{d}/*.pdb"))
    tpr = tprs[0] if tprs else None
    gro = max(tops, key=os.path.getsize) if tops else None
    return tpr, gro, parts

def build_universe(tpr, gro, parts):
    errs = []
    for top in (tpr, gro):
        if not top:
            continue
        try:
            u = mda.Universe(top, parts)
            return u, top, top.endswith((".gro", ".pdb"))
        except Exception as e:
            errs.append(f"{os.path.basename(top)}: {str(e).splitlines()[0]}")
    raise RuntimeError(" ; ".join(errs) if errs else "no topology found")

def _h_of(c):
    """C-H hydrogens bonded to carbon c, with CHARMM36 name-based fallback."""
    try:
        hs = [h for h in c.bonded_atoms if h.name.startswith("H")]
    except Exception:                             # no bond information in topology
        hs = []
    if not hs:                                    # fallback: CHARMM36 HnR/HnS (CH2), HnX/HnY/HnZ or HnT (CH3)
        pos = c.name[2:]
        hs = c.residue.atoms.select_atoms(
            f"name H{pos}R H{pos}S H{pos}T H{pos}X H{pos}Y H{pos}Z")
    return list(hs)

def _unit_ch(u, ci, hi):
    """Unit C-H vectors for the current frame, under the minimum-image convention.

    GROMACS writes trajectories with molecules broken across the periodic
    boundary, so a C-H pair can sit on opposite faces of the box; the raw
    difference is then of order the box length and lies almost in the bilayer
    plane, contributing about +0.5 to -S_CD regardless of the true orientation.
    In these trajectories about 1.2-1.4% of acyl C-H vectors are split this way
    in any frame, which raises the mean order parameter by about 0.0025.
    """
    v = u.atoms.positions[hi] - u.atoms.positions[ci]
    box = u.trajectory.ts.dimensions
    if box is not None and np.all(box[:3] > 0):
        v = minimize_vectors(v, box=box)
    return v / np.linalg.norm(v, axis=1)[:, None]


def ch_pairs(popc, carbon_names):
    ci, hi, cn = [], [], []
    for cname in carbon_names:
        for c in popc.select_atoms("name " + cname):
            for h in _h_of(c):
                ci.append(c.index); hi.append(h.index); cn.append(cname)
    return np.array(ci, int), np.array(hi, int), np.array(cn, dtype=object)

def scd_profile(u, popc, carbon_names):
    ci, hi, cn = ch_pairs(popc, carbon_names)
    if len(ci) == 0:
        return {}
    acc = np.zeros(len(ci)); nfr = 0
    for ts in u.trajectory:
        if ts.time / 1000.0 < T_EQUIL_NS:
            continue
        cz = _unit_ch(u, ci, hi)[:, 2]
        acc += 0.5 * (3 * cz**2 - 1); nfr += 1
    scd = acc / max(nfr, 1)
    return {n: -scd[cn == n].mean() for n in carbon_names if (cn == n).any()}

def glycero_acyl_pairs(glyc):
    """C-H pairs for every acyl segment (C3>=2, C2>=2) of every glycerophospholipid
    molecule, grouped by carbon-atom index so each segment can be averaged first."""
    ci, hi, key = [], [], []
    for c in glyc.atoms:                          # iterate + regex (no wildcard selection)
        m = ACYL_RE.match(c.name)
        if not m or int(m.group(1)) < 2:          # skip carbonyls (C31/C21) and glycerol (C2/C3)
            continue
        for h in _h_of(c):
            ci.append(c.index); hi.append(h.index); key.append(c.index)
    return np.array(ci, int), np.array(hi, int), np.array(key, int)

def scd_glycero_mean(u, glyc):
    """MANUSCRIPT -S_CD: per-segment order parameter averaged over all
    glycerophospholipid acyl carbons (both chains, all molecules) and frames."""
    ci, hi, key = glycero_acyl_pairs(glyc)
    if len(ci) == 0:
        return float("nan"), 0
    acc = np.zeros(len(ci)); nfr = 0
    for ts in u.trajectory:
        if ts.time / 1000.0 < T_EQUIL_NS:
            continue
        cz = _unit_ch(u, ci, hi)[:, 2]
        acc += 0.5 * (3 * cz**2 - 1); nfr += 1
    scd = acc / max(nfr, 1)                        # time-averaged, per C-H bond
    uniq = np.unique(key)                          # one -S_CD per acyl carbon (mean over its H's), then grand mean
    per_seg = np.array([-scd[key == k].mean() for k in uniq])
    return float(per_seg.mean()), int(len(uniq))

def apl_thickness(u, phos):
    n_leaf = len(phos) / 2.0
    areas, thicks = [], []
    for ts in u.trajectory:
        if ts.time / 1000.0 < T_EQUIL_NS:
            continue
        areas.append(ts.dimensions[0] * ts.dimensions[1])
        z = phos.positions[:, 2]; c = z.mean()
        thicks.append((z[z > c].mean() - z[z < c].mean()) / 10.0)
    return float(np.mean(areas)) / n_leaf, float(np.mean(thicks))

def lateral_D(u, fit_ns=MSD_FIT_NS, report=False):
    """Lipid lateral diffusion D_lat (um^2/s) with PER-LEAFLET COM removal.
    PBC-unwraps phosphate xy (accumulated minimum-image steps), removes each
    LEAFLET's centre-of-mass drift every frame so D measures single-lipid motion
    relative to its leaflet (Fig S3 is centre-of-mass-removed), then fits the
    linear MSD window; D = slope/4 (2-D Einstein). Units: A, ns -> A^2/ns; x10 ->
    um^2/s. The printed log-log slope should be ~1; on the 200 ns trajectories it
    is ~0.6 (sub-diffusive), so D_lat is an effective mobility for comparison."""
    phos = u.select_atoms(PHOS_SEL); n = len(phos)
    u.trajectory[0]
    upper = phos.positions[:, 2] > phos.positions[:, 2].mean()   # static leaflet split
    prev = None; cum = np.zeros((n, 2)); times = []; traj = []
    for ts in u.trajectory:
        xy = phos.positions[:, :2].copy(); box = ts.dimensions[:2]
        if prev is not None:
            step = xy - prev; step -= box * np.round(step / box)  # unwrap (min image)
            cum += step
        prev = xy
        if ts.time / 1000.0 + 1e-9 < T_EQUIL_NS:
            continue
        rel = cum.copy()
        rel[upper]  -= rel[upper].mean(axis=0)        # remove per-leaflet COM drift
        rel[~upper] -= rel[~upper].mean(axis=0)
        times.append(ts.time / 1000.0); traj.append(rel)
    if len(times) < 5:
        return float("nan")
    times = np.asarray(times); times -= times[0]; traj = np.asarray(traj)  # (nfr,n,2)
    nf = len(times); msd = np.zeros(nf)
    for lag in range(1, nf):                          # MSD, sliding origins
        d = traj[lag:] - traj[:-lag]; msd[lag] = (d * d).sum(axis=2).mean()
    i0 = np.searchsorted(times, fit_ns[0]); i1 = max(np.searchsorted(times, fit_ns[1]), i0 + 2)
    slope = np.polyfit(times[i0:i1], msd[i0:i1], 1)[0]            # A^2/ns
    if report:
        ll = np.polyfit(np.log(times[i0:i1]), np.log(msd[i0:i1]), 1)[0]
        print(f"      [D_lat fit {fit_ns[0]:.0f}-{fit_ns[1]:.0f} ns: log-log slope={ll:.2f} (Fickian~1.0)]")
    return slope / 4.0 * 10.0                                     # A^2/ns -> um^2/s

def extract(tpr, gro, parts):
    u, top, guessed = build_universe(tpr, gro, parts)
    popc = u.select_atoms(POPC_RES)
    glyc = u.select_atoms(GLYCERO_SEL)            # all glycerophospholipids (manuscript definition)
    if guessed:
        try:
            glyc.guess_bonds()                    # superset of POPC; covers every acyl C-H
        except Exception as e:
            print(f"      (guess_bonds skipped: {str(e).splitlines()[0]}; using name-based C-H)")
    sn1 = scd_profile(u, popc, SN1_CARB)
    sn2 = scd_profile(u, popc, SN2_CARB)
    plateau = float(np.mean([sn1[c] for c in SN1_PLATEAU if c in sn1]))
    scd_glyc, n_acyl = scd_glycero_mean(u, glyc)  # <-- 0.249 / 0.254 manuscript value
    apl, thick = apl_thickness(u, u.select_atoms(PHOS_SEL))
    try:
        dlat = lateral_D(u, MSD_FIT_NS, report=True)
    except Exception as e:
        dlat = float("nan"); print(f"      (D_lat failed: {str(e).splitlines()[0]})")
    return dict(SCD_plateau=plateau, SCD_glycero=scd_glyc, n_acyl=n_acyl,
                APL=apl, thickness=thick, Dlat=dlat,
                sn1=np.array([sn1[c] for c in SN1_CARB if c in sn1]),
                sn2=np.array([sn2[c] for c in SN2_CARB if c in sn2]),
                top=os.path.basename(top), nparts=len(parts))

rows = []; profiles = {}
for cell, dirs in RUNDIRS.items():
    for i, d in enumerate(dirs, start=1):
        path = os.path.join(BASE_DIR, d)
        if not os.path.isdir(path):
            print(f"  {d}: rundir not found at {path}")
            rows.append([cell, i, "", "", "", "", ""]); continue
        tpr, gro, parts = find_inputs(path)
        if not parts:
            print(f"  {d}: no .xtc found. Contents: {', '.join(sorted(os.listdir(path))[:12])}")
            rows.append([cell, i, "", "", "", "", ""]); continue
        try:
            r = extract(tpr, gro, parts)
            rows.append([cell, i, f"{r['SCD_glycero']:.4f}", f"{r['SCD_plateau']:.4f}",
                         f"{r['APL']:.2f}", f"{r['thickness']:.3f}", f"{r['Dlat']:.3f}"])
            profiles[f"{cell}_rep{i}_sn1"] = r["sn1"]
            profiles[f"{cell}_rep{i}_sn2"] = r["sn2"]
            print(f"  {d}: top={r['top']}  parts={r['nparts']}  "
                  f"-S_CD(glycero)={r['SCD_glycero']:.3f}  -S_CD(plateau)={r['SCD_plateau']:.3f}  "
                  f"[{r['n_acyl']} acyl C]  APL={r['APL']:.2f}  "
                  f"thick={r['thickness']:.3f}  D_lat={r['Dlat']:.3f}")
        except Exception as e:
            print(f"  {d}: FAILED -> {str(e).splitlines()[0]}")
            rows.append([cell, i, "", "", "", "", ""])

n_ok = sum(1 for r in rows if r[2] != "")
if n_ok == 0:
    print("\nNo replicates read - CSV NOT written. Check the messages above.")
    print("If topology failed: make one MDAnalysis can read, e.g.")
    print("  gmx editconf -f astro_rep1/prod_npt.tpr -o astro_rep1/ws1_top.gro")
    print("(.gro is read for names; C-H bonds are guessed for phospholipids.)")
else:
    with open("ws1_values.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["cell", "rep", "SCD_glycero", "SCD_plateau", "APL", "thickness", "Dlat"])
        w.writerows(rows)
    np.savez("ws1_scd_profiles.npz", **profiles)
    ok = [r for r in rows if r[2] != ""]
    for cell in ("astro", "u87"):
        vals = [float(r[2]) for r in ok if r[0] == cell]
        if vals:
            print(f"  mean SCD_glycero ({cell}) = {np.mean(vals):.3f} "
                  f"+/- {np.std(vals, ddof=1) if len(vals) > 1 else 0:.3f}  "
                  f"(manuscript: {'0.249' if cell == 'astro' else '0.254'})")
    print(f"\nWrote ws1_values.csv ({n_ok}/6) and ws1_scd_profiles.npz")
    print("Now run:  python3 ws1_analysis.py")
