#!/usr/bin/env python3
"""Fig. S11 - equilibration and stationarity of the membrane area.

Inputs, both extracted from the production trajectories and deposited:
  box_series/box_<replicate>.csv  box lengths of every frame (0-200 ns, 100 ps);
                                  the area per phospholipid follows from these
  pp_thickness_1ns.csv            phosphate-to-phosphate thickness, 1 ns frames
so this figure regenerates without the trajectories.

Two tests are applied to each replicate:

  * equilibration time, by the automated method of Chodera (2016): the start
    point that maximises the effective number of uncorrelated samples in the
    remainder of the series;
  * stationarity over the 80-200 ns analysis window, by a least-squares trend
    fitted to 10 ns block means, with its standard error from the block scatter.

A sensitivity check then repeats the between-composition comparison on the
second half of the window alone.

Chodera, J. D. (2016). A simple method for automated equilibration detection in
molecular simulations. J. Chem. Theory Comput. 12, 1799-1805.

    python3 plot_convergence_figS11.py
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "box_series")
N_LIPID = 512
N_CHOL = {"astro": 205, "u87": 215}
LABEL = {"astro": "astrocyte", "u87": "U87-MG"}
COLOR = {"astro": "#2A9D8F", "u87": "#E63946"}
STYLE = {1: "-", 2: "--", 3: ":"}
MARK = {1: "o", 2: "s", 3: "^"}
WINDOW = (80.0, 200.0)
BLOCK_NS = 10.0
INK, MUTED = "#222222", "#6b6b6b"


def load(cell, rep):
    a = np.loadtxt(os.path.join(SRC, f"box_{cell}_rep{rep}.csv"), delimiter=",", skiprows=1)
    t, axy = a[:, 0], a[:, 1] * a[:, 2]
    return t, axy


def apl(axy, cell):
    """Area per phospholipid per leaflet."""
    return axy / ((N_LIPID - N_CHOL[cell]) / 2)


def stat_inefficiency(x):
    """g = 1 + 2 sum_t (1 - t/N) C(t), integrated until C(t) first falls to zero."""
    x = np.asarray(x, float)
    n = len(x)
    dx = x - x.mean()
    var = dx.var()
    if var == 0:
        return 1.0
    g = 1.0
    for lag in range(1, n - 1):
        c = np.dot(dx[: n - lag], dx[lag:]) / ((n - lag) * var)
        if c <= 0:
            break
        g += 2.0 * c * (1.0 - lag / n)
    return max(1.0, g)


def equilibration_time(t, x, step=10):
    """Start point maximising N_eff = (N - t0) / g(t0)."""
    best_i, best_neff = 0, -1.0
    for i in range(0, len(x) - 50, step):
        neff = (len(x) - i) / stat_inefficiency(x[i:])
        if neff > best_neff:
            best_i, best_neff = i, neff
    return t[best_i]


def block_trend(t, x):
    """10 ns block means over the window, their OLS slope and its standard error."""
    edges = np.arange(WINDOW[0], WINDOW[1] + 1e-9, BLOCK_NS)
    centres, means = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        s = (t >= lo) & (t < hi)
        centres.append(0.5 * (lo + hi))
        means.append(x[s].mean())
    c, m = np.array(centres), np.array(means)
    fit = stats.linregress(c, m)
    return c, m, fit


fig, ax = plt.subplots(1, 3, figsize=(15.5, 4.4), gridspec_kw=dict(width_ratios=[1.3, 1, 1.05]))
rows = []
for cell in ("astro", "u87"):
    for rep in (1, 2, 3):
        t, axy = load(cell, rep)
        y = apl(axy, cell)
        # panel A: 1 ns means over the full run
        edges = np.arange(0.0, 200.0 + 1e-9, 1.0)
        tb = 0.5 * (edges[:-1] + edges[1:])
        yb = np.array([y[(t >= lo) & (t < hi)].mean() for lo, hi in zip(edges[:-1], edges[1:])])
        ax[0].plot(tb, yb, color=COLOR[cell], ls=STYLE[rep], lw=1.1)
        # panel B: block means and trend over the window
        c, m, fit = block_trend(t, y)
        ax[1].plot(c, m, color=COLOR[cell], ls="none", marker=MARK[rep], ms=4.2)
        xx = np.array(WINDOW)
        ax[1].plot(xx, fit.intercept + fit.slope * xx, color=COLOR[cell], ls=STYLE[rep], lw=1.2)
        w = (t >= WINDOW[0]) & (t <= WINDOW[1])
        half = 0.5 * (WINDOW[0] + WINDOW[1])
        rows.append(dict(cell=cell, rep=rep, teq=equilibration_time(t, y),
                         mean=y[w].mean(), slope=100 * fit.slope, se=100 * fit.stderr,
                         tval=fit.slope / fit.stderr, p=fit.pvalue,
                         half=y[w & (t >= half)].mean() - y[w & (t < half)].mean()))

# panel C: bilayer thickness over the full run
th = np.genfromtxt(os.path.join(HERE, "pp_thickness_1ns.csv"), delimiter=",", names=True)
th_teq, th_fit = {}, {}
for cell in ("astro", "u87"):
    for rep in (1, 2, 3):
        y = th[f"{cell}_rep{rep}"]
        ax[2].plot(th["time_ns"], y, color=COLOR[cell], ls=STYLE[rep], lw=1.0)
        th_teq[(cell, rep)] = equilibration_time(th["time_ns"], y, step=1)
        th_fit[(cell, rep)] = block_trend(th["time_ns"], y)[2]
drift_th = [(k, f) for k, f in th_fit.items() if f.pvalue < 0.05]
steady_th = [f for f in th_fit.values() if f.pvalue >= 0.05]
sub_c = "; ".join(f"{LABEL[c]} rep {r} t = {f.slope / f.stderr:+.1f}" for (c, r), f in drift_th)
sub_c += f"; other five |t| ≤ {max(abs(f.slope / f.stderr) for f in steady_th):.1f}"
ax[2].text(0.0, 1.015, "trend over 80–200 ns: " + sub_c, transform=ax[2].transAxes,
           fontsize=7.6, color=MUTED, va="bottom")
ax[2].axvspan(0, WINDOW[0], color="#000000", alpha=0.05, lw=0)
ax[2].set_xlim(0, 200)
ax[2].set_ylim(3.8, 4.75)
ax[2].set_xlabel("time (ns)")
ax[2].set_ylabel("P–P thickness (nm)")
ax[2].set_title("C   bilayer thickness", loc="left", fontsize=10, pad=16)

# panel A furniture
ax[0].axvspan(0, WINDOW[0], color="#000000", alpha=0.05, lw=0)
ax[0].text(40, 89.2, "discarded", ha="center", fontsize=8.5, color=MUTED)
ax[0].text(140, 89.2, "analysis window", ha="center", fontsize=8.5, color=MUTED)
stable = [r["teq"] for r in rows if r["p"] >= 0.05]
lo, hi = min(stable), max(stable)
ax[0].annotate("", xy=(lo, 86.6), xytext=(hi, 86.6),
               arrowprops=dict(arrowstyle="|-|", color=INK, lw=0.9, mutation_scale=3))
ax[0].text(0.5 * (lo + hi), 87.1, f"detected equilibration\n{lo:.0f}–{hi:.0f} ns",
           ha="center", va="bottom", fontsize=7.8, color=INK)
for cell in ("astro", "u87"):
    m = np.mean([r["mean"] for r in rows if r["cell"] == cell])
    ax[0].text(201.5, m, LABEL[cell], va="center", fontsize=8.5, color=INK)
ax[0].set_xlim(0, 200)
ax[0].set_ylim(72, 91)
ax[0].set_xlabel("time (ns)")
ax[0].set_ylabel(r"area per phospholipid ($\mathrm{\AA^2}$)")
ax[0].set_title("A   relaxation from the starting area", loc="left", fontsize=10, pad=16)

# panel B furniture: trend statistics in the subtitle, clear of the data
drift = [r for r in rows if r["p"] < 0.05]
others = [r for r in rows if r["p"] >= 0.05]
sub = "; ".join(f"{LABEL[r['cell']]} rep {r['rep']} t = {r['tval']:.1f}" for r in drift)
sub += f"; other five |t| ≤ {max(abs(r['tval']) for r in others):.1f}"
ax[1].text(0.0, 1.015, "trend over the window: " + sub, transform=ax[1].transAxes,
           fontsize=7.6, color=MUTED, va="bottom")
ax[1].set_xlim(*WINDOW)
ax[1].set_xlabel("time (ns)")
ax[1].set_ylabel(r"10 ns block mean ($\mathrm{\AA^2}$)")
ax[1].set_title("B   stationarity over 80–200 ns", loc="left", fontsize=10, pad=16)

for a in ax:
    a.grid(alpha=0.22, lw=0.6)
    for s in ("top", "right"):
        a.spines[s].set_visible(False)

handles = [Line2D([], [], color=COLOR["astro"], lw=2, label="astrocyte"),
           Line2D([], [], color=COLOR["u87"], lw=2, label="U87-MG")]
handles += [Line2D([], [], color=MUTED, ls=STYLE[k], marker=MARK[k], ms=4.2, lw=1.2,
                   label=f"replicate {k}") for k in (1, 2, 3)]
fig.legend(handles=handles, frameon=False, fontsize=8.2, loc="lower center", ncol=5,
           bbox_to_anchor=(0.5, 0.0))

fig.tight_layout(rect=(0, 0.07, 1, 1))
out = os.path.join(HERE, "figS11_convergence.png")
fig.savefig(out, dpi=300)

print(f"{'replicate':<16}{'t_eq ns':>8}{'mean':>8}{'slope/100ns':>13}{'SE':>7}{'t':>6}{'p':>7}{'half diff':>10}")
for r in rows:
    print(f"{LABEL[r['cell']]} rep {r['rep']:<5}{r['teq']:8.1f}{r['mean']:8.2f}{r['slope']:+13.3f}"
          f"{r['se']:7.3f}{r['tval']:+6.1f}{r['p']:7.3f}{r['half']:+10.2f}")

print("\nthickness (1 ns frames): equilibration time, 80-200 ns mean and trend")
for (cell, rep), te in th_teq.items():
    y = th[f"{cell}_rep{rep}"]
    f = th_fit[(cell, rep)]
    print(f"  {LABEL[cell]} rep {rep}: t_eq {te:5.0f}   mean {y[th['time_ns'] >= 80].mean():.3f} nm   "
          f"trend {100 * f.slope:+.4f} +- {100 * f.stderr:.4f} nm/100 ns (t = {f.slope / f.stderr:+.1f})")

print("\nsensitivity of the between-composition comparison to the window:")
for lo_, hi_ in ((80.0, 200.0), (100.0, 200.0), (140.0, 200.0)):
    vals = {}
    for cell in ("astro", "u87"):
        a_pl, a_tot = [], []
        for rep in (1, 2, 3):
            t, axy = load(cell, rep)
            w = (t >= lo_) & (t <= hi_)
            a_pl.append(axy[w].mean() / ((N_LIPID - N_CHOL[cell]) / 2))
            a_tot.append(axy[w].mean() / (N_LIPID / 2))
        vals[cell] = (np.array(a_pl), np.array(a_tot))
    for k, name in ((0, "per phospholipid"), (1, "per total lipid")):
        a, u = vals["astro"][k], vals["u87"][k]
        p = stats.ttest_ind(a, u, equal_var=False).pvalue
        print(f"  {lo_:.0f}-{hi_:.0f} ns  {name:<17} {a.mean():7.3f} vs {u.mean():7.3f}"
              f"  ({100 * (u.mean() / a.mean() - 1):+.2f}%)  Welch p = {p:.3f}")
print("Saved", out)
