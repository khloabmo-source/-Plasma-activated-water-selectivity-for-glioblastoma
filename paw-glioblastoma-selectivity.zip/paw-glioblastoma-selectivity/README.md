# Plasma-activated water selectivity for glioblastoma — reproducibility package

Code, derived data and structural models for the transfer-function analysis of
H2O2 transport and clearance in U87-MG glioblastoma cells versus normal
astrocytes.

**Read `MANIFEST.md` first.** It lists every figure, the script that regenerates
it, and — importantly — the items marked **M** that cannot be reproduced from this
deposit alone (trajectory-based Fig. S4, the convergence re-extraction, and the
Section 4.4 PMF) and why.

---

## Quick start

```bash
pip install -r requirements.txt
bash run_all.sh                 # regenerates every manuscript figure that needs no trajectories
RUN_LEGACY=1 bash run_all.sh    # additionally runs the exploratory scripts (figures/legacy/)
```

`run_all.sh` writes one log per script to `logs/`.

Everything in `transport_model/` and `aqp8_structure/` runs from this deposit with
no additional input. `membrane_analysis/` runs from the deposited derived data for
Figs. S2, S3, S5 and S11; Fig. S4 and raw trajectory re-extraction additionally need the production trajectories,
which are deposited separately (see `MANIFEST.md`).

---

## Layout

```
transport_model/     steady-state transfer function, sensitivity, survival   -> Figs 1-9, S1, S6-S10, S12, S15
  _model.py            shared model core: Table 1 values defined once; loads killcurve.csv
  01-04, 08-10, 13-19  manuscript scripts (listed in MANIFEST.md)
  03, 05, 06, 07, 11, 12  exploratory / legacy scripts, run only with RUN_LEGACY=1
  killcurve.csv        digitised Kurake 2016 U251SP kill curve; single source of the
                       five calibration points (read through _model.py by every script)
  sobol_bounds.csv     sampling ranges, distributions and estimator settings

membrane_analysis/   membrane observables from the MD trajectories           -> Figs S2-S5, S11
  extract_ws1.py       trajectories -> ws1_values.csv + ws1_scd_profiles.npz
  ws1_values.csv       per-replicate observables (the figures' actual source)
  tost_equivalence.py  equivalence testing                                   -> Fig S5
  test_scd.py          unit tests for the order-parameter logic, no trajectories needed
  test_dlat.py         unit test for the lateral-diffusion pipeline

md_simulation/       MD provenance
  prod_npt.mdp         the production control file actually used
  colab_production_notebook.ipynb   full build / run / QC workflow

aqp8_structure/      AQP8 selectivity-filter geometry                        -> Sec 4.7, Figs S13-S14
  ensemble/d16,d32,d64   240 ColabFold models + config.json + log.txt
  reference_oriented.pdb membrane-oriented reference for superposition
  pore_radius_ensemble.py  the 240-model analysis
  pore_radius_single.py    connected-path profile on one structure
  results/               computed output

permeability/        umbrella-sampling H2O2 PMF workflow (Section 4.4); the sampled
                     windows are not deposited. See permeability/FINDINGS.md

figures/             generated manuscript figures (see figures/README.md)
  legacy/              exploratory outputs, created only with RUN_LEGACY=1
logs/                per-script logs written by run_all.sh
```

---

## Model provenance

The production MD used tensionless semi-isotropic NPT at a 2 fs timestep
(`md_simulation/prod_npt.mdp`): v-rescale thermostat at 310.15 K, C-rescale
barostat at 1 bar with `compressibility = 4.5e-5 4.5e-5`, PME, force-switched
Lennard-Jones (1.0-1.2 nm), LINCS on bonds to hydrogen. Three 200 ns replicates
per composition, 1.2 us aggregate; the first 80 ns of each are discarded and all
observables are averaged over the 80-200 ns window.

Membranes were built with the CHARMM-GUI Membrane Builder (CHARMM36 lipid force
field as stated in the manuscript, TIP3P), 512 lipids each. The CHARMM-GUI options
file deposited for the AQP8 build records `c36m` (`aqp8_structure/charmmgui_build_config.json`);
the membrane build archives are not in this deposit, so the exact option used for the
two membranes cannot be checked here and must be confirmed against them:

| lipid | astrocyte | U87-MG |
|---|---|---|
| cholesterol | 205 | 215 |
| POPC | 95 | 98 |
| POPE | 51 | 61 |
| PSM | 51 | 46 |
| DOPC | 38 | 31 |
| POPS | 31 | 31 |
| DOPE | 26 | 15 |
| POPI | 15 | 15 |

These compositions were specified before production from the published
glioblastoma lipidome and were not revised in response to any computed
observable.

The AQP8 conformational ensemble was generated with ColabFold 1.6.1
(`alphafold2_ptm`, no templates, 3 recycles, no relaxation) at three MSA depths
with inference dropout enabled: `max_seq:max_extra_seq` of 16:32, 32:64 and
64:128, each with 16 seeds x 5 models = 80 models, 240 in total. The exact
settings are in each depth's `config.json` and the run logs in `log.txt`.

---

## Parameters: what is measured, what is assumed

The manuscript's conclusions rest on ratios and on the structure of the transfer
function, not on absolute parameter values. For transparency:

**Taken from experiment:** the background lipid permeability `P_lip`
(Orrico 2022; baseline 5 x 10^-4 cm/s lies at the saturated-composition end of the
measured 4.1 x 10^-4 to 5.5 x 10^-3 range, see `transport_model/19_plip_measured_range.py`);
the survival law `D50` and `h` (calibrated to Kurake 2016, a U251SP line); the
resting clearance asymmetry benchmark (Doskey 2016).

**Assumed, with sensitivity reported:** the gating parameters `C_half`, `k_ox` and the
gating exponent. Ref. [31] establishes that Cys53 is the redox-sensitive residue
and that its oxidation is reversible, but reports no closure dose-response and no
rate constant; these are therefore phenomenological. The Sobol total-effect indices
of `C_half` and the gating exponent are 0.047 and 0.048, the two smallest in the
analysis (`k_ox` enters only the gating time scale, not the sensitivity analysis).

**Assumed, and load-bearing:** the operational clearance ratio (10) and the extracellular
H2O2 concentration, which is a boundary condition, not a modelled quantity. The model does
not derive either from plasma chemistry. `17_attributed_clearance.py` reports instead
what ratio the observed selectivity *requires*, and shows that this depends on the
clearance state attributed to the cells on which the survival law was calibrated.

**Assumed:** the 3 h effective exposure window. Because cumulative dose scales
linearly with this window on both the calibration and the prediction side, the
predicted selectivity is invariant to its common value (25-fold at 30 min, 3 h and
24 h alike). What the model assumes is that the calibration assay and the modelled
exposure share the same effective window.

---

## Dependencies

Python >= 3.9 with numpy, scipy, matplotlib (transport model and AQP8 analysis)
and MDAnalysis (membrane analysis, AQP8 superposition). See `requirements.txt`.
GROMACS is needed only to rerun the MD itself.

## Licence

See `LICENSE`.
