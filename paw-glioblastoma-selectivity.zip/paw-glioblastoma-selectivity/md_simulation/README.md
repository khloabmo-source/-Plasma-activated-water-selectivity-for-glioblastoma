# MD provenance

`prod_npt.mdp` is the production control file actually used: tensionless
semi-isotropic NPT, 2 fs, v-rescale thermostat (310.15 K), C-rescale barostat
(`compressibility = 4.5e-5 4.5e-5`), PME, force-switched Lennard-Jones
(1.0–1.2 nm), LINCS on bonds to hydrogen. The topology carries the hydrogen-mass
repartitioning applied at system construction (lipid hydrogen 3.024 amu, bonded
heavy atoms reduced correspondingly), integrated here at 2 fs; lateral diffusion
is therefore reported as a comparison between compositions under a common mass
model. Three 200 ns replicates per
composition, 1.2 µs aggregate; first 80 ns discarded, observables averaged over
80–200 ns.

The mass check recorded in the notebook returns a lipid hydrogen mass of
3.024 amu for both systems. The control file written by the notebook is identical
to `prod_npt.mdp` in every parameter; only the header comment lines differ, and
those in `prod_npt.mdp` are the ones that describe the topology as checked.

`colab_production_notebook.ipynb` documents the full workflow: environment setup,
mass check, writing the production mdp, resuming each replicate under tensionless
NPT, and the energy/area quality control.

Membranes were built with the CHARMM-GUI Membrane Builder (CHARMM36m, TIP3P,
512 lipids); the build archives are deposited separately with the trajectories.

**Composition provenance.** The two lipid compositions were fixed before
production, from the published glioblastoma lipidome (cholesterol enrichment,
reduced sphingomyelin, a di- to mono-unsaturated shift in the PC/PE pools), and
were not revised in response to any computed observable. The U87-MG system
analysed throughout carries 215 cholesterol of 512 total lipids, as built. See
the provenance note in `colab_production_notebook.ipynb`.

**Starting configuration.** Each production run starts from a configuration
pre-equilibrated at constant area, at about 90 Å² per phospholipid; the area
relaxes within 24–40 ns once the lateral box is free (Fig. S11), and the first
80 ns are discarded.

**Scope of the deposit.** Every reported value derives from production under the
settings in `prod_npt.mdp`. Exploratory runs carried out during method
development under different barostat and timestep settings are not part of this
analysis and are not deposited; any trajectory added to this deposit must match
`prod_npt.mdp`. `membrane_analysis/check_trajectory_provenance.py` verifies this
from the box vectors alone: the lateral box must fluctuate, and over the
80–200 ns window the area must reproduce the reported value.
