# Figure index

Maps the files in this directory to manuscript figures. Regenerate everything with
`bash ../run_all.sh`. Every file listed here is written by a script in the deposit
and is not edited by hand afterwards.

| manuscript | file | script |
|---|---|---|
| Fig. 1 | `fig1_regime_separation.png` | `transport_model/01_transfer_function.py` |
| Fig. 2 | `fig2_selectivity_map.png` | `transport_model/01_transfer_function.py` |
| Fig. 3 | `fig3_coupled_gating.png` | `transport_model/15_coupled_gating_fig3.py` |
| Fig. 4 | `fig4_tornado_decoupled.png` | `transport_model/02_sensitivity_robustness.py` |
| Fig. 5 | `fig5_robustness_hist_decoupled.png` | `transport_model/02_sensitivity_robustness.py` |
| Fig. 6 | `fig6_robustness_map_decoupled.png` | `transport_model/02_sensitivity_robustness.py` |
| Fig. 7 | `fig7_dose_survival.png` | `transport_model/03b_dose_survival_window_hill.py` |
| Fig. 8 | `fig8_therapeutic_window.png` | `transport_model/03b_dose_survival_window_hill.py` |
| Fig. 9 | `fig9_unified_chain.png`, `fig9_unified_chain.pdf` (vector) | `transport_model/04_causal_chain_schematic.py` |
| Fig. S1 | `figS1_michaelis_menten.png` | `transport_model/14_michaelis_menten_figS1.py` |
| Fig. S2 | `figS2_order.png` | `membrane_analysis/plot_ws1_final.py` |
| Fig. S3 | `figS3_structure.png` | `membrane_analysis/plot_ws1_final.py` |
| Fig. S4 | — | requires the production trajectories; see `../MANIFEST.md` |
| Fig. S5 | `figS5_tost_equivalence.png` | `membrane_analysis/tost_equivalence.py` |
| Fig. S6 | `figS6_clearance_grounding.png` | `transport_model/09_clearance_grounding.py` |
| Fig. S7 | `figS7_model_selection.png` | `transport_model/13_model_comparison.py` |
| Fig. S8 | `figS8_normal_anchor.png` | `transport_model/08_normal_anchor_mcf10a.py` |
| Fig. S9 | `figS9_bootstrap_uncertainty.png` | `transport_model/10_bootstrap_uncertainty.py` |
| Fig. S10 | `figS10_depletion.png` | `transport_model/18_depletion_fixed_law.py` |
| Fig. S11 | `figS11_convergence.png` | `membrane_analysis/plot_convergence_figS11.py` |
| Fig. S12 | `figS12_attributed_clearance.png` | `transport_model/17_attributed_clearance.py` |
| Fig. S13 | `figS13_aqp8_ensemble.png` | `aqp8_structure/plot_ensemble_figS13.py` |
| Fig. S14 | `figS14_aqp8_pore_methods.png` | `aqp8_structure/plot_pore_methods_figS14.py` |
| Fig. S15 | `figS15_selectivity_vs_hill.png` | `transport_model/16_selectivity_vs_hill.py` |

Fig. 9 is a schematic in four panels (A–D) plus a banner. Every box, arrow and label
in `04_causal_chain_schematic.py` is a matplotlib vector primitive at an explicit
coordinate; the two curves (panel C, Φ/(1+Φ) with the two operating points; panel D,
the Hill survival law at h = 5.21) are computed in the script. It reads no external
asset and embeds no raster image.

## Comparator output kept here

| file | what it shows |
|---|---|
| `fig3_timecourse.png` | quasi-steady-state gating, for comparison with the coupled solution in Fig. 3 (written by script 01) |

## Exploratory outputs (`legacy/`; not manuscript figures)

Written only by `RUN_LEGACY=1 bash ../run_all.sh`:
`fig7_dose_survival_singlehit.png`, `fig8_therapeutic_window_singlehit.png`
(single-hit law, rejected, ΔAICc = +15.1), `fig7b_survival_hill_kurake.png`,
`fig11_depletion.png` (re-calibrated law only; does **not** show invariance to bath
depletion — see Fig. S10), `fig12_robustness_map.png`, `fig_plip_ceiling.png`.
