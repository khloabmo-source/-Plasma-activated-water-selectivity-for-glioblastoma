# MANIFEST — what reproduces what

This file states, for every figure and table in the manuscript, which script
regenerates it and whether the inputs are present in this deposit. Items that
**cannot** be reproduced from this deposit alone are marked, with the reason.

| mark | meaning |
|---|---|
| **R** | Reproducible from this deposit with no additional input |
| **D** | Reproducible from derived data included here; raw trajectories not deposited |
| **M** | Missing input — cannot be reproduced from this deposit |

`bash run_all.sh` regenerates every **R** and **D** item below into `figures/` and
writes one log per script to `logs/`. `RUN_LEGACY=1 bash run_all.sh` additionally
runs the exploratory scripts listed under "Not manuscript figures" and writes their
output to `figures/legacy/` (not deposited as figures). `test_scd.py` and
`test_dlat.py` need MDAnalysis and are skipped, not failed, when it is not installed.
All scripts take the five Kurake calibration points from `killcurve.csv` through
`transport_model/_model.py`; no script keeps its own copy.

---

## Main figures

| figure | script | inputs | status |
|---|---|---|---|
| Fig. 1 — regime separation (`fig1_regime_separation.png`) | `transport_model/01_transfer_function.py` | none | **R** |
| Fig. 2 — selectivity map | `transport_model/01_transfer_function.py` | none | **R** |
| Fig. 3 — gating dynamics | `transport_model/15_coupled_gating_fig3.py` | none | **R** |
| Fig. 4 — Sobol indices | `transport_model/02_sensitivity_robustness.py` | `sobol_bounds.csv` | **R** |
| Fig. 5 — robustness histogram | `transport_model/02_sensitivity_robustness.py` | none | **R** |
| Fig. 6 — robustness map | `transport_model/02_sensitivity_robustness.py` | none | **R** |
| Table S3 — conditional robustness | `transport_model/02b_conditional_robustness.py` | none | **R** |
| P_lip measured range (Sec. 4.4) | `transport_model/19_plip_measured_range.py` | none | **R** |
| Fig. 7 — dose and survival | `transport_model/03b_dose_survival_window_hill.py` | `killcurve.csv` (via `_model.py`) | **R** |
| Fig. 8 — therapeutic window (3 h edges computed: 67–350 µM) | `transport_model/03b_dose_survival_window_hill.py` | `killcurve.csv` (via `_model.py`) | **R** |
| Fig. 9 — schematic (`fig9_unified_chain.png`, `.pdf`) | `transport_model/04_causal_chain_schematic.py` | none | **R** |

Fig. 3 integrates Eq. (2) and Eq. (6) together, so the gate relaxes on its own
kinetic timescale rather than tracking the instantaneous concentration. A
quasi-steady-state comparator is emitted by script `01` as
`fig3_timecourse.png`.

---

## Supplementary figures

| figure | script | inputs | status |
|---|---|---|---|
| Fig. S1 — saturable clearance | `transport_model/14_michaelis_menten_figS1.py` | none | **R** |
| Fig. S2 — acyl-chain order | `membrane_analysis/plot_ws1_final.py` | `ws1_scd_profiles.npz` | **D** |
| Fig. S3 — structural parameters | `membrane_analysis/plot_ws1_final.py` | `ws1_values.csv` | **D** |
| Fig. S4 — lateral MSD | `membrane_analysis/plot_msd_S4.py` | **trajectories** | **M** |
| Fig. S5 — TOST equivalence | `membrane_analysis/tost_equivalence.py` | `ws1_values.csv` | **D** |
| (no figure) order-parameter definitions | `membrane_analysis/scd_definition_check.py` | `scd_definitions.csv` | **R** |
| Fig. S6 — clearance grounding (`figS6_clearance_grounding.png`) | `transport_model/09_clearance_grounding.py` | none | **R** |
| Fig. S7 — model selection (`figS7_model_selection.png`) | `transport_model/13_model_comparison.py` | `killcurve.csv` (via `_model.py`) | **R** |
| Fig. S8 — normal-cell anchor (`figS8_normal_anchor.png`) | `transport_model/08_normal_anchor_mcf10a.py` | `killcurve.csv` (via `_model.py`); the MCF10A datum is typed in the script | **R** |
| Fig. S9 — bootstrap | `transport_model/10_bootstrap_uncertainty.py` | `killcurve.csv` (via `_model.py`) | **R** |
| Fig. S13 — AQP8 ensemble radii | `aqp8_structure/plot_ensemble_figS13.py` | `results/aqp8_ensemble_240.csv` | **R** |
| Fig. S14 — pore profile by method | `aqp8_structure/plot_pore_methods_figS14.py` | `results/pore_profile_reference.csv`, `charmmgui_pore_profile.plo` | **R** |
| Fig. S10 — depletion | `transport_model/18_depletion_fixed_law.py` | none | **R** |
| Fig. S11 — equilibration and stationarity | `membrane_analysis/plot_convergence_figS11.py` | `box_series/` | **D** |
| trajectory provenance check | `membrane_analysis/check_trajectory_provenance.py` | any `.xtc` | **R** |
| order-parameter and thickness convergence | `membrane_analysis/ws1_convergence.py` | **trajectories** | **M** |
| AQP8 ensemble (input to Fig. S13) | `aqp8_structure/pore_radius_ensemble.py` | `ensemble/` (included) | **R** |
| pore profile of the reference structure (input to Fig. S14) | `aqp8_structure/pore_radius_single.py` | `reference_oriented.pdb` | **R** |
| Fig. S12 — attributed clearance (`figS12_attributed_clearance.png`) | `transport_model/17_attributed_clearance.py` | none | **R** |
| Fig. S15 — selectivity vs *h* (`figS15_selectivity_vs_hill.png`) | `transport_model/16_selectivity_vs_hill.py` (reads `bootstrap_h_ci.txt`, written by script 10) | none | **R** |

Fig. S14 plots two profiles, the connected-path probe radius and CHARMM-GUI's pore
profile. The unconstrained per-slice value (1.199 Å) is reported in
`aqp8_structure/README.md` but is not plotted and has no deposited data file.

---

## Not manuscript figures (exploratory / comparator scripts)

Run only with `RUN_LEGACY=1`; outputs go to `figures/legacy/` and are not deposited
as figures:

| script | output | why it is not a manuscript figure |
|---|---|---|
| `03_dose_survival_window.py` | `fig7_dose_survival_singlehit.png`, `fig8_therapeutic_window_singlehit.png` | single-hit law, rejected (ΔAICc = +15.1; Fig. S7); illustrative D_lethal |
| `05_measured_plip_coupling.py` | `fig_plip_ceiling.png` | P_lip sensitivity tool; the numbers in Sec. 4.4 come from script 19 |
| `06_calibrate_dlethal.py` | — | single-hit calibration, superseded by the Hill fit |
| `07_survival_hill_kurake.py` | `fig7b_survival_hill_kurake.png` | earlier Hill fit; same result as `03b` |
| `11_depletion_selfconsistent.py` | `fig11_depletion.png` | re-calibrated-law comparison only; not evidence of invariance (claim withdrawn, Sec. 4.8); the manuscript figure is S10 (script 18) |
| `12_robustness_map.py` | `fig12_robustness_map.png` | diagnostic map; Fig. 6 and Table S3 carry the reported robustness |

`fig3_timecourse.png` (quasi-steady-state gating) is written by script `01` as a
comparator for Fig. 3 and stays in `figures/`.

---

## Tables

| table | source | status |
|---|---|---|
| Table 1 — parameters | `transport_model/_model.py`, `sobol_bounds.csv` | **R** |
| Table S1 — lipid composition | CHARMM-GUI `topol.top` | **D** — counts in the top-level README; build archives deposited separately |
| Table S2 — per-replicate membrane values | `membrane_analysis/ws1_values.csv`, `scd_definitions.csv` | **D** |
| Table S3 — conditional robustness | `transport_model/02b_conditional_robustness.py` | **R** |
| Sec. 4.4 PMF (barrier ≈ 17 kJ/mol; P = 1.3–4.2 × 10⁻² cm s⁻¹) | `permeability/` | **M** — sampled umbrella windows not deposited |

---

## What is not in this deposit

### Production MD trajectories (Figs. S2–S4, convergence check)

The six production trajectories (3 astrocyte + 3 U87-MG, 200 ns each, ≈ 1.2 µs
aggregate) are omitted for size. The full derived output they feed is included:
`ws1_values.csv` (per replicate, per observable) and `ws1_scd_profiles.npz`
(per-segment order-parameter profiles), together with the extraction script
`extract_ws1.py` and the production control file `prod_npt.mdp`.

Figs. S2, S3, S5 and S11 therefore regenerate from the derived data deposited here. Fig. S4 and re-extraction of the derived files from scratch (extract_ws1.py, ws1_convergence.py) need the trajectories themselves, which are deposited
separately.

### Umbrella-sampling windows for the exploratory PMF

`permeability/` holds the complete workflow — topology generation, steered
pulling, umbrella windows, the ISD analysis — but not the sampled windows. That
calculation sets no model parameter (P_lip is anchored to experiment), but its
barrier and permeability are reported in Sec. 4.4 as a negative result, so those
numbers cannot be reproduced from this deposit (status **M**).
`permeability/FINDINGS.md` must agree with Sec. 4.4 (Orrico et al. 2022;
4.1 × 10⁻⁴ and 5.5 × 10⁻³ cm s⁻¹).

---

## Reference values

Run `bash run_all.sh` and compare against the following (the values are printed by the scripts and logged in `logs/`).

### Transport model, Table 1 parameterisation (gating exponent n = 1, Eq. 6 steady state)

```
Phi_astro = 0.080    C_in = 6.9 uM (gated) / 7.4 uM (ungated)
Phi_u87   = 2.000    C_in = 66.7 uM (ungated), 52.2 uM (gated)
S_dose    = 9.0 (ungated) -> 7.6 (gated)
D50 = 3.055e5 uM*s   h = 5.21   R2 = 0.995
100 uM / 3 h: astrocyte 99.9%, U87-MG 3.9%, kill selectivity 25.4x
therapeutic window (3 h): 67 - 350 uM; bootstrap 95% interval on the upper bound [288, 404]
cooperative sensitivity case (n = 2): S_dose 6.9, D50 3.150e5, h 5.68, selectivity 23.4x
```

### Sobol total-effect indices

```
P_AQP8,astro 0.341   k_astro 0.275   k ratio 0.229   P_lip 0.182
rho ratio    0.078   C_out   0.076   n 0.048         C_half 0.047
median S_dose 6.2  IQR [4.6, 8.6]   P(S>2) = 0.99   P(regime separation) = 0.92
```

### Coupled gating (script 15)

```
tau_transport = 67 ms ; tau_gate = 108 s (1.8 min) at k_ox = 100 M^-1 s^-1
3 h dose, coupled vs quasi-steady state: +0.3%
```

### Extracellular depletion (script 18)

```
C_out half-life 0.70 h (U87-MG), 0.55 h (astrocyte) at phi = 1.0e-4
dose ratio under depletion = 10.00 (the clearance ratio; membrane terms cancel)
survival law held at its constant-C_out calibration : U87 90.1%, selectivity 1.11x
survival law re-calibrated under depletion          : U87  3.8%, selectivity 26.4x
```

### Equilibration and stationarity (Fig. S11)

```
automated equilibration time (area): 24-40 ns in five of six replicates
trend over 80-200 ns, 10 ns blocks:  |t| <= 1.1 in five replicates
astrocyte replicate 3:               -0.82 +- 0.26 A^2 per 100 ns (t = -3.1)
window 140-200 ns: APL +2.22% (p = 0.003); area per total lipid -1.11% (p = 0.031)
```

### AQP8 ar/R filter, 240 models

```
median 0.041 A   95th percentile 0.628 A   maximum 0.864 A
sterically sealed (<= 0): 39.6%
models reaching the 1.0 A conduction threshold: 0 of 240
per depth (16:32, 32:64, 64:128), medians 0.051, 0.015, 0.089 A
```

### Membrane observables (`ws1_values.csv`)

```
                      astrocyte        U87-MG       Welch p
-S_CD (glycero)    0.249 +- 0.001   0.254 +- 0.003   0.106
APL (A^2/PL)      73.840 +- 0.092  75.337 +- 0.260   0.005
A per total lipid 44.275 +- 0.055  43.701 +- 0.151   0.014
P-P thickness(nm)  4.563 +- 0.006   4.581 +- 0.014   0.141
D_lat (um^2/s)     1.797 +- 0.422   1.721 +- 0.184   0.793
```

With n = 3 replicates per group a rank test cannot return p < 0.10, so none is
reported.

The order parameter is the time average of -S_CD with minimum-image C-H
vectors, over every acyl carbon of every glycerophospholipid molecule
(sphingomyelin and cholesterol excluded), 80-200 ns at 1 ns intervals. Without
the minimum image, the 1.2-1.4% of C-H pairs split across the periodic boundary
in each frame raise it by 0.0023-0.0028; weighting each lipid species equally
instead of each acyl carbon gives 0.247 / 0.248 (p = 0.39).
`membrane_analysis/scd_definition_check.py` prints all four combinations from
`scd_definitions.csv`. The difference is not significant under any of them, so
no conclusion rests on chain order.

---

## Conventions that affect the numbers

Three choices change the result and are therefore stated explicitly rather than
left to the reader to infer.

**Saturable clearance (Fig. S1).** Sweeping the Michaelis constant requires a
rule for V_max. Holding V_max = k_clear·K_m keeps the low-concentration rate
constant fixed at its first-order value, so the sweep isolates saturation; under
this convention selectivity and normal-cell sparing are preserved for any
K_m above ≈ 8 µM. Holding V_max fixed instead changes the low-concentration rate
constant itself and removes clearance capacity from both cells. Both are shown.

**Exposure window.** Cumulative dose scales linearly with the exposure window on
both the calibration and the prediction side, so the predicted selectivity is
invariant to the common value of that window — 25-fold at 30 min, 3 h and 24 h
alike. What is assumed is that the calibration assay and the modelled exposure
share one effective window.

**Calibration attribution (script 17).** The kill curve was measured under H₂O₂
alone. The clearance rate assigned to those cells when converting concentration
to dose changes the fitted (D₅₀, h), and hence what clearance ratio the model
reports as required: 6.6-fold if the calibration cells are taken to be in the
collapsed state, 1.4-fold if taken to be at basal clearance. Both fits describe
the five calibration points equally well (R² = 0.995 in both cases).

**Pore radius.** The ar/R radius depends strongly on whether the probe sphere is
constrained to a connected path. Unconstrained per-slice maximisation lets the
probe enter lateral cavities and returns 1.199 Å on the reference structure;
the connected-path ar/R value is 0.046 Å (rounded to 0.05 Å in the manuscript; the
minimum of the connected-path profile in the filter region quoted in the Fig. S14
caption, 0.018 Å at z = −2.24 Å, is a different quantity), and CHARMM-GUI's own pore
detection returns a fully occluded filter. The connected-path value is used throughout.
